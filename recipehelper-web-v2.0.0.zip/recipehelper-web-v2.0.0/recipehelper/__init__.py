"""Recipe Helper: recipes, batch planning and a bake log, as a self-hosted web app."""

__version__ = "2.0.0"
APP_NAME = "recipehelper"
