"""Baking calculations. Pure functions: no I/O, no database, no web.

Ported unchanged from releases 1-1/1-2 so every number matches the original
script. Known quirks are kept on purpose and listed in LOG.md (Q4, Q5).
"""

FLOUR_HINTS = ["flour"]
LIQUID_HINTS = ["water", "milk"]
INF = float("inf")


def detect_ingredient(keys, hints):
    """First key whose lower-cased name contains any hint (original order)."""
    for k in keys:
        for h in hints:
            if h in k.lower():
                return k
    return None


def apply_sdd(amounts, sdd):
    """Sourdough discard: take half of it off the first flour and half off the
    first water/milk ingredient, then add it as "sdd". Mutates and returns
    amounts, plus warnings."""
    flour = detect_ingredient(amounts.keys(), FLOUR_HINTS)
    liquid = detect_ingredient(amounts.keys(), LIQUID_HINTS)
    warnings = []

    flour_red = 0.5 * sdd
    liquid_red = 0.5 * sdd

    if flour:
        if flour_red > amounts[flour]:
            warnings.append("SDD exceeds flour; flour reduced to 0")
        amounts[flour] = max(0, amounts[flour] - flour_red)

    if liquid:
        if liquid_red > amounts[liquid]:
            warnings.append("SDD exceeds liquid; liquid reduced to 0")
        amounts[liquid] = max(0, amounts[liquid] - liquid_red)

    amounts["sdd"] = sdd
    return amounts, warnings


def hydration(amounts):
    """100 x (all water/milk ingredients) / (first flour ingredient), or None."""
    flour = detect_ingredient(amounts.keys(), FLOUR_HINTS)
    if flour and amounts.get(flour, 0) > 0:
        liquid_total = sum(
            v for k, v in amounts.items()
            if any(h in k.lower() for h in LIQUID_HINTS)
        )
        return 100 * liquid_total / amounts[flour]
    return None


def compute_plan(ratios, use_sdd=False, sdd=0, target_servings=None, available=None):
    """Scale a recipe ({ingredient: amount per serving}).

    target_servings given -> scale to that many servings.
    Otherwise maximize: the largest batch the `available` amounts allow
    ({ingredient: amount}, missing or inf = unlimited); 1 serving if nothing
    limits it. An ingredient used at 0 per serving never limits the batch.

    Returns (servings, amounts, warnings).
    """
    finite = {}
    if target_servings is not None:
        servings = target_servings
    else:
        available = available or {}
        finite = {k: available[k] for k in ratios if available.get(k, INF) != INF}
        limits = {k: v for k, v in finite.items() if ratios[k] > 0}
        servings = min(v / ratios[k] for k, v in limits.items()) if limits else 1.0

    amounts = {k: v * servings for k, v in ratios.items()}
    warnings = []
    if use_sdd:
        if target_servings is None and list(finite) == ["sdd"]:
            # Original behaviour when the only limit is an ingredient named "sdd".
            scale = sdd / max(1e-9, sdd)
            amounts = {k: v * scale for k, v in amounts.items()}
        amounts, warnings = apply_sdd(amounts, sdd)
    return servings, amounts, warnings


def limiting_ingredient(ratios, available, servings):
    """The ingredient that set the batch size in maximize mode, or None."""
    for k, v in (available or {}).items():
        if v == INF or k not in ratios or ratios[k] <= 0:
            continue
        if abs(v / ratios[k] - servings) < 1e-9 * max(1, servings):
            return k
    return None


def reference_amounts(attempt, ratios):
    """What a bake is compared against: the planned amounts if it came from a
    plan, otherwise the recipe scaled to the servings made (or to the flour
    actually used). Returns (amounts, label) or (None, None)."""
    if attempt.get("planned"):
        return attempt["planned"], "planned"
    s = attempt.get("servings")
    if not s:
        flour = detect_ingredient(attempt["amounts"].keys(), FLOUR_HINTS)
        if flour and ratios.get(flour, 0) > 0:
            s = attempt["amounts"][flour] / ratios[flour]
    if not s:
        return None, None
    return {k: v * s for k, v in ratios.items()}, f"recipe scaled to {s:.3g} servings"


def compare_attempt(attempt, ratios):
    """Returns (label, rows, skipped). Each row: name, actual, ref, diff, pct
    (None when there is nothing to compare) and extra (not in reference)."""
    ref, label = reference_amounts(attempt, ratios)
    rows = []
    for k, v in attempt["amounts"].items():
        row = {"name": k, "actual": v, "ref": None, "diff": None, "pct": None,
               "extra": False}
        if ref is not None:
            if k in ref and ref[k] > 0:
                diff = v - ref[k]
                row.update(ref=ref[k], diff=diff, pct=100 * diff / ref[k])
            elif k not in ref:
                row["extra"] = True
        rows.append(row)
    skipped = []
    if ref is not None:
        skipped = [k for k in ref if k not in attempt["amounts"] and ref[k] > 0]
    return label, rows, skipped


def bake_hydration(amounts):
    """Hydration stored with a bake: rounded to 1 decimal, as the original did."""
    h = hydration(amounts)
    return None if h is None else round(h, 1)


def rating_summary(attempts):
    """(average rating or None, 1-based position of the best bake or None),
    for bakes in date order. Ties go to the earliest, as in the original."""
    rated = [a["rating"] for a in attempts if a.get("rating")]
    if not rated:
        return None, None
    best = max(range(len(attempts)), key=lambda i: attempts[i].get("rating") or 0)
    return sum(rated) / len(rated), best + 1


def per_serving(totals, servings):
    """Batch totals -> amounts per serving (how recipes are stored)."""
    return {k: v / servings for k, v in totals.items()}


def bake_key(recipe_name, baked_on, amounts):
    """Duplicate key for imports: recipe (case-insensitive), date and amounts
    rounded to 0.01."""
    amt = tuple(sorted((k.strip().lower(), round(float(v), 2)) for k, v in amounts.items()))
    return (recipe_name.strip().lower(), baked_on, amt)


def describe_bake_key(key):
    name, d, amt = key
    parts = ", ".join(f"{k} {v:g}" for k, v in amt)
    return f"{name} · {d} · {parts}" if parts else f"{name} · {d}"


def fmt_amount(v):
    """Display format for amounts: 4 significant digits, like the terminal."""
    return "" if v is None else f"{v:.4g}"


def prefill(v):
    """Editable form value: up to 2 decimals, no trailing zeros."""
    return ("%.2f" % v).rstrip("0").rstrip(".")
