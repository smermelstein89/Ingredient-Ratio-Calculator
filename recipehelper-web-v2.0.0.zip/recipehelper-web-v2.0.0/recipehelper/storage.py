"""SQLite storage: one file (recipes.db) in the data folder.

* Schema version lives in PRAGMA user_version. 1-x databases (version 0) are
  upgraded in place after a "pre-migrate-v2" backup.
* Every change runs in one transaction (atomic), behind a daily backup.
* Every change is recorded in `changes` with before/after snapshots, which
  powers the history page and one-click undo.
* A file that isn't a readable SQLite database is never overwritten:
  DataError is raised and the web app shows where the backups are.
"""
import contextlib
import csv
import io
import json
import os
import re
import sqlite3

try:
    import fcntl
except ImportError:  # pragma: no cover - not on Linux
    fcntl = None

from . import __version__
from . import logic

SCHEMA_VERSION = 2
SQLITE_MAGIC = b"SQLite format 3\x00"
BACKUP_RE = re.compile(r"^recipes-(\d{8})-(\d{6})(?:-\d+)?-([a-z0-9-]+)\.db$")
# Backups that BACKUP_KEEP may prune. Manual, pre-update and pre-migrate
# backups are never deleted automatically.
PRUNABLE = {"daily", "pre-import", "pre-restore", "pre-undo"}

TABLES_V2 = """
CREATE TABLE IF NOT EXISTS recipes (
    id          INTEGER PRIMARY KEY,
    name        TEXT NOT NULL UNIQUE,
    servings    REAL NOT NULL CHECK (servings > 0),
    unit        TEXT NOT NULL DEFAULT 'g',
    notes       TEXT NOT NULL DEFAULT '',
    rev         INTEGER NOT NULL DEFAULT 1,
    created_at  TEXT NOT NULL DEFAULT '',
    updated_at  TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS recipe_ingredients (
    recipe_id    INTEGER NOT NULL REFERENCES recipes(id) ON DELETE CASCADE,
    position     INTEGER NOT NULL,
    name         TEXT NOT NULL,
    per_serving  REAL NOT NULL CHECK (per_serving >= 0),
    PRIMARY KEY (recipe_id, name)
);
CREATE TABLE IF NOT EXISTS attempts (
    id          INTEGER PRIMARY KEY,
    recipe_id   INTEGER NOT NULL REFERENCES recipes(id) ON DELETE CASCADE,
    baked_on    TEXT NOT NULL,
    servings    REAL,
    rating      INTEGER CHECK (rating BETWEEN 1 AND 5),
    notes       TEXT NOT NULL DEFAULT '',
    hydration   REAL,
    from_plan   INTEGER NOT NULL DEFAULT 0,
    rev         INTEGER NOT NULL DEFAULT 1,
    created_at  TEXT NOT NULL DEFAULT '',
    updated_at  TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS attempt_ingredients (
    attempt_id  INTEGER NOT NULL REFERENCES attempts(id) ON DELETE CASCADE,
    position    INTEGER NOT NULL,
    name        TEXT NOT NULL,
    actual      REAL,
    planned     REAL,
    PRIMARY KEY (attempt_id, name)
);
CREATE INDEX IF NOT EXISTS idx_attempts_recipe ON attempts(recipe_id, baked_on);
"""

TABLES_V2_EXTRA = """
CREATE TABLE IF NOT EXISTS settings (
    key    TEXT PRIMARY KEY,
    value  TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS changes (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    at         TEXT NOT NULL,
    who        TEXT NOT NULL,
    action     TEXT NOT NULL,
    entity     TEXT NOT NULL,
    entity_id  INTEGER,
    summary    TEXT NOT NULL,
    before     TEXT,
    after      TEXT,
    backup     TEXT,
    undone     INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_attempts_date ON attempts(baked_on);
"""

MIGRATE_1_TO_2 = [
    "ALTER TABLE recipes ADD COLUMN unit TEXT NOT NULL DEFAULT 'g'",
    "ALTER TABLE recipes ADD COLUMN notes TEXT NOT NULL DEFAULT ''",
    "ALTER TABLE recipes ADD COLUMN rev INTEGER NOT NULL DEFAULT 1",
    "ALTER TABLE recipes ADD COLUMN created_at TEXT NOT NULL DEFAULT ''",
    "ALTER TABLE recipes ADD COLUMN updated_at TEXT NOT NULL DEFAULT ''",
    "ALTER TABLE attempts ADD COLUMN rev INTEGER NOT NULL DEFAULT 1",
    "ALTER TABLE attempts ADD COLUMN created_at TEXT NOT NULL DEFAULT ''",
    "ALTER TABLE attempts ADD COLUMN updated_at TEXT NOT NULL DEFAULT ''",
]

DEFAULT_SETTINGS = {
    "recipes_sort": "name",
    "bakes_sort": "-date",
    "default_unit": "g",
}

RECIPE_SORTS = {
    "name": "r.name COLLATE NOCASE",
    "bakes": "n_bakes",
    "rating": "avg_rating",
    "hydration": "avg_hydration",
    "last": "last_baked",
    "servings": "r.servings",
}
BAKE_SORTS = {
    "date": "b.baked_on",
    "recipe": "b.recipe COLLATE NOCASE",
    "rating": "b.rating",
    "hydration": "b.hydration",
    "servings": "b.servings",
}


class DataError(Exception):
    """The database can't be read safely. Nothing will be written to it."""


class NotFound(Exception):
    pass


class Conflict(Exception):
    """Someone else changed the record since the form was opened."""

    def __init__(self, current):
        super().__init__("changed by someone else")
        self.current = current


class InvalidData(Exception):
    pass


def parse_sort(value, allowed, default):
    """'-date' -> ('date', True). Unknown keys fall back to the default."""
    for v in (value, default):
        v = (v or "").strip()
        key = v.lstrip("-")
        if key in allowed:
            return key, v.startswith("-")
    return next(iter(allowed)), False


def _like(q):
    return "%" + q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"


class Store:
    def __init__(self, cfg):
        self.cfg = cfg

    # ------------------------------------------------------------------ basics

    def open(self):
        conn = sqlite3.connect(self.cfg.db_path, timeout=15)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        conn.execute("PRAGMA busy_timeout = 15000")
        return conn

    @contextlib.contextmanager
    def conn(self):
        c = self.open()
        try:
            yield c
        finally:
            c.close()

    @contextlib.contextmanager
    def _lock(self):
        """Process-wide lock (several Gunicorn workers) for backups and setup."""
        os.makedirs(self.cfg.data_dir, exist_ok=True)
        path = os.path.join(self.cfg.data_dir, ".lock")
        with open(path, "a") as f:
            if fcntl:
                fcntl.flock(f, fcntl.LOCK_EX)
            try:
                yield
            finally:
                if fcntl:
                    fcntl.flock(f, fcntl.LOCK_UN)

    def now(self):
        return self.cfg.now().isoformat(timespec="seconds")

    def init(self):
        """Create a new database, or check and upgrade an existing one.
        Raises DataError (and changes nothing) if the file can't be trusted."""
        self.cfg.ensure_dirs()
        with self._lock():
            path = self.cfg.db_path
            if os.path.exists(path) and os.path.getsize(path) > 0:
                with open(path, "rb") as f:
                    if f.read(16) != SQLITE_MAGIC:
                        raise DataError(f"{path} is not a SQLite database.")
            try:
                with self.conn() as c:
                    if os.path.getsize(path) > 0:
                        res = c.execute("PRAGMA quick_check").fetchone()[0]
                        if res != "ok":
                            raise DataError(f"Integrity check failed: {res}")
                    version = c.execute("PRAGMA user_version").fetchone()[0]
                    tables = {r[0] for r in c.execute(
                        "SELECT name FROM sqlite_master WHERE type='table'")}
                if version > SCHEMA_VERSION:
                    raise DataError(
                        f"The database is from a newer version (schema {version}); "
                        f"this app understands up to {SCHEMA_VERSION}.")
                if version < SCHEMA_VERSION:
                    if "recipes" in tables:
                        self._backup_unlocked("pre-migrate-v2")
                    self._create_or_migrate("recipes" in tables)
                with self.conn() as c:
                    c.execute("PRAGMA journal_mode=WAL")
            except sqlite3.DatabaseError as e:
                raise DataError(str(e)) from e

    def _create_or_migrate(self, existing):
        c = self.open()
        c.isolation_level = None
        try:
            c.execute("BEGIN IMMEDIATE")
            if existing:
                cols = {r[1] for r in c.execute("PRAGMA table_info(recipes)")}
                acols = {r[1] for r in c.execute("PRAGMA table_info(attempts)")}
                for stmt in MIGRATE_1_TO_2:
                    table, col = stmt.split()[2], stmt.split()[5]
                    if col not in (cols if table == "recipes" else acols):
                        c.execute(stmt)
                now = self.now()
                c.execute("UPDATE recipes SET created_at=?, updated_at=? WHERE created_at=''",
                          (now, now))
                c.execute("UPDATE attempts SET created_at=?, updated_at=? WHERE created_at=''",
                          (now, now))
            else:
                for stmt in TABLES_V2.split(";"):
                    if stmt.strip():
                        c.execute(stmt)
            for stmt in TABLES_V2_EXTRA.split(";"):
                if stmt.strip():
                    c.execute(stmt)
            c.execute(f"PRAGMA user_version = {SCHEMA_VERSION}")
            c.execute("COMMIT")
        except Exception:
            c.execute("ROLLBACK")
            raise
        finally:
            c.close()

    @contextlib.contextmanager
    def tx(self):
        """A write transaction. Makes the day's first backup beforehand."""
        self.ensure_daily_backup()
        c = self.open()
        c.isolation_level = None
        try:
            c.execute("BEGIN IMMEDIATE")
            yield c
            c.execute("COMMIT")
        except Exception:
            c.execute("ROLLBACK")
            raise
        finally:
            c.close()

    def health(self):
        with self.conn() as c:
            return {
                "recipes": c.execute("SELECT COUNT(*) FROM recipes").fetchone()[0],
                "bakes": c.execute("SELECT COUNT(*) FROM attempts").fetchone()[0],
            }

    # ----------------------------------------------------------------- backups

    def _backup_unlocked(self, reason):
        os.makedirs(self.cfg.backup_dir, exist_ok=True)
        stamp = self.cfg.now().strftime("%Y%m%d-%H%M%S")
        name = f"recipes-{stamp}-{reason}.db"
        n = 2
        while os.path.exists(os.path.join(self.cfg.backup_dir, name)):
            name = f"recipes-{stamp}-{n}-{reason}.db"
            n += 1
        final = os.path.join(self.cfg.backup_dir, name)
        tmp = final + ".tmp"
        src = sqlite3.connect(self.cfg.db_path, timeout=15)
        dst = sqlite3.connect(tmp)
        try:
            src.backup(dst)
        finally:
            dst.close()
            src.close()
        with open(tmp, "rb") as f:
            os.fsync(f.fileno())
        os.replace(tmp, final)
        return name

    def backup(self, reason="manual"):
        if not re.fullmatch(r"[a-z0-9-]+", reason):
            raise ValueError("bad reason")
        with self._lock():
            name = self._backup_unlocked(reason)
        self.prune_backups()
        return name

    def ensure_daily_backup(self):
        if not os.path.exists(self.cfg.db_path):
            return None
        prefix = "recipes-" + self.cfg.today().strftime("%Y%m%d") + "-"
        if any(n.startswith(prefix) for n in self._backup_names()):
            return None
        with self._lock():
            if any(n.startswith(prefix) for n in self._backup_names()):
                return None
            name = self._backup_unlocked("daily")
        self.prune_backups()
        return name

    def _backup_names(self):
        try:
            return [n for n in os.listdir(self.cfg.backup_dir) if BACKUP_RE.match(n)]
        except FileNotFoundError:
            return []

    def list_backups(self):
        out = []
        for n in self._backup_names():
            m = BACKUP_RE.match(n)
            p = os.path.join(self.cfg.backup_dir, n)
            d, t, reason = m.group(1), m.group(2), m.group(3)
            out.append({
                "name": n,
                "reason": reason,
                "when": f"{d[:4]}-{d[4:6]}-{d[6:]} {t[:2]}:{t[2:4]}",
                "size": os.path.getsize(p),
            })
        out.sort(key=lambda b: b["name"], reverse=True)
        return out

    def backup_path(self, name):
        if not BACKUP_RE.match(name or ""):
            raise NotFound(name)
        p = os.path.join(self.cfg.backup_dir, name)
        if not os.path.isfile(p):
            raise NotFound(name)
        return p

    def prune_backups(self):
        keep = self.cfg.backup_keep
        if keep <= 0:
            return []
        auto = [b for b in self.list_backups() if b["reason"] in PRUNABLE]
        removed = []
        for b in auto[keep:]:
            os.remove(os.path.join(self.cfg.backup_dir, b["name"]))
            removed.append(b["name"])
        return removed

    def restore(self, name, who, log_action="restore", summary=None):
        """Replace the live data with a backup, after backing up the current
        state. Returns the name of that safety backup."""
        path = self.backup_path(name)
        try:
            with open(path, "rb") as f:
                if f.read(16) != SQLITE_MAGIC:
                    raise InvalidData("That backup isn't a SQLite database.")
            chk = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
            try:
                if chk.execute("PRAGMA quick_check").fetchone()[0] != "ok":
                    raise InvalidData("That backup failed its integrity check.")
            finally:
                chk.close()
        except sqlite3.DatabaseError as e:
            raise InvalidData(f"That backup can't be read: {e}") from e
        safety = self.backup("pre-restore")
        with self._lock():
            src = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
            dst = self.open()
            try:
                src.backup(dst)
            finally:
                src.close()
                dst.close()
        self.init()  # a backup from 1-x is upgraded again
        with self.tx() as c:
            self._log(c, who, log_action, "data", None,
                      summary or f"Restored backup {name}", None, None, backup=safety)
        return safety

    # ---------------------------------------------------------------- settings

    def settings(self):
        out = dict(DEFAULT_SETTINGS)
        with self.conn() as c:
            for r in c.execute("SELECT key, value FROM settings"):
                out[r["key"]] = r["value"]
        return out

    def set_settings(self, values, who):
        with self.tx() as c:
            before = {r["key"]: r["value"] for r in c.execute("SELECT key, value FROM settings")}
            for k, v in values.items():
                if k in DEFAULT_SETTINGS:
                    c.execute("INSERT INTO settings (key, value) VALUES (?, ?) "
                              "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (k, v))
            self._log(c, who, "update", "settings", None, "Changed settings",
                      before, values)

    # ------------------------------------------------------------------ history

    def _log(self, c, who, action, entity, entity_id, summary, before, after, backup=None):
        c.execute(
            "INSERT INTO changes (at, who, action, entity, entity_id, summary, before, after, backup) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (self.now(), who or "local", action, entity, entity_id, summary,
             None if before is None else json.dumps(before),
             None if after is None else json.dumps(after), backup))

    def history(self, limit=100):
        with self.conn() as c:
            return [dict(r) for r in c.execute(
                "SELECT id, at, who, action, entity, entity_id, summary, undone, backup "
                "FROM changes ORDER BY id DESC LIMIT ?", (limit,))]

    def last_undoable(self):
        with self.conn() as c:
            r = c.execute("SELECT * FROM changes WHERE undone = 0 AND action != 'undo' "
                          "ORDER BY id DESC LIMIT 1").fetchone()
            return dict(r) if r else None

    def undo_last(self, who):
        ch = self.last_undoable()
        if ch is None:
            raise NotFound("nothing to undo")
        before = json.loads(ch["before"]) if ch["before"] else None
        after = json.loads(ch["after"]) if ch["after"] else None
        if ch["action"] in ("import", "restore"):
            self.restore(ch["backup"], who, log_action="undo",
                         summary=f"Undid: {ch['summary']}")
            return ch
        with self.tx() as c:
            ent, act = ch["entity"], ch["action"]
            if ent == "settings":
                c.execute("DELETE FROM settings")
                for k, v in (before or {}).items():
                    c.execute("INSERT INTO settings (key, value) VALUES (?, ?)", (k, v))
            elif ent in ("recipe", "bake"):
                table = "recipes" if ent == "recipe" else "attempts"
                eid = ch["entity_id"]
                if act == "create":
                    c.execute(f"DELETE FROM {table} WHERE id = ?", (eid,))
                elif act == "update":
                    # Restore the old values in place (deleting the row would
                    # also delete a recipe's bakes).
                    if c.execute(f"SELECT 1 FROM {table} WHERE id = ?", (eid,)).fetchone() is None:
                        raise InvalidData("Can't undo: that record no longer exists.")
                    if ent == "recipe":
                        self._update_recipe_rows(c, eid, before["name"], before["servings"],
                                                 dict(before["ingredients"]), before["unit"],
                                                 before["notes"])
                    else:
                        cur = self._attempt_snap(c, eid)
                        self._update_attempt_rows(c, eid, {
                            "date": before["baked_on"], "servings": before["servings"],
                            "rating": before["rating"], "notes": before["notes"],
                            "amounts": {n: a for n, a, _ in before["ingredients"] if a is not None},
                            "planned": ({n: p for n, _, p in before["ingredients"] if p is not None}
                                        if before["from_plan"] else {}),
                        }, cur)
                        c.execute("UPDATE attempts SET hydration = ? WHERE id = ?",
                                  (before["hydration"], eid))
                elif act == "delete":
                    try:
                        if ent == "recipe":
                            self._insert_recipe_snap(c, before, bump=True)
                        else:
                            self._insert_attempt_snap(c, before, bump=True)
                    except sqlite3.IntegrityError as e:
                        raise InvalidData(
                            "Can't undo: the record clashes with newer data.") from e
                del after
            c.execute("UPDATE changes SET undone = 1 WHERE id = ?", (ch["id"],))
            self._log(c, who, "undo", ch["entity"], ch["entity_id"],
                      f"Undid: {ch['summary']}", None, None)
        return ch

    # -------------------------------------------------------------- snapshots

    def _recipe_snap(self, c, rid, with_bakes=False):
        r = c.execute("SELECT * FROM recipes WHERE id = ?", (rid,)).fetchone()
        if r is None:
            raise NotFound(rid)
        snap = {k: r[k] for k in r.keys()}
        snap["ingredients"] = [[x["name"], x["per_serving"]] for x in c.execute(
            "SELECT name, per_serving FROM recipe_ingredients WHERE recipe_id = ? "
            "ORDER BY position", (rid,))]
        if with_bakes:
            snap["bakes"] = [self._attempt_snap(c, x["id"]) for x in c.execute(
                "SELECT id FROM attempts WHERE recipe_id = ? ORDER BY baked_on, id", (rid,))]
        return snap

    def _attempt_snap(self, c, aid):
        a = c.execute("SELECT * FROM attempts WHERE id = ?", (aid,)).fetchone()
        if a is None:
            raise NotFound(aid)
        snap = {k: a[k] for k in a.keys()}
        snap["ingredients"] = [[x["name"], x["actual"], x["planned"]] for x in c.execute(
            "SELECT name, actual, planned FROM attempt_ingredients WHERE attempt_id = ? "
            "ORDER BY position", (aid,))]
        return snap

    def _insert_recipe_snap(self, c, s, bump=False):
        rev = s["rev"] + 1 if bump else s["rev"]
        c.execute("INSERT INTO recipes (id, name, servings, unit, notes, rev, created_at, updated_at) "
                  "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                  (s["id"], s["name"], s["servings"], s["unit"], s["notes"], rev,
                   s["created_at"], self.now() if bump else s["updated_at"]))
        c.executemany("INSERT INTO recipe_ingredients (recipe_id, position, name, per_serving) "
                      "VALUES (?, ?, ?, ?)",
                      [(s["id"], i, n, v) for i, (n, v) in enumerate(s["ingredients"])])
        for b in s.get("bakes", []):
            self._insert_attempt_snap(c, b)

    def _insert_attempt_snap(self, c, s, bump=False):
        rev = s["rev"] + 1 if bump else s["rev"]
        c.execute("INSERT INTO attempts (id, recipe_id, baked_on, servings, rating, notes, "
                  "hydration, from_plan, rev, created_at, updated_at) "
                  "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                  (s["id"], s["recipe_id"], s["baked_on"], s["servings"], s["rating"],
                   s["notes"], s["hydration"], s["from_plan"], rev, s["created_at"],
                   self.now() if bump else s["updated_at"]))
        c.executemany("INSERT INTO attempt_ingredients (attempt_id, position, name, actual, planned) "
                      "VALUES (?, ?, ?, ?, ?)",
                      [(s["id"], i, n, a, p) for i, (n, a, p) in enumerate(s["ingredients"])])

    # ----------------------------------------------------------------- recipes

    def recipe_names(self):
        with self.conn() as c:
            return [r["name"] for r in c.execute("SELECT name FROM recipes ORDER BY id")]

    def recipe_index(self):
        """{lower-cased name: id} for matching imports and checking duplicates."""
        with self.conn() as c:
            return {r["name"].strip().lower(): r["id"]
                    for r in c.execute("SELECT id, name FROM recipes")}

    def find_recipe_id(self, name, exclude_id=None):
        with self.conn() as c:
            r = c.execute("SELECT id FROM recipes WHERE lower(trim(name)) = lower(trim(?)) "
                          "AND id IS NOT ?", (name, exclude_id)).fetchone()
            return r["id"] if r else None

    def recipe(self, rid):
        with self.conn() as c:
            r = c.execute("SELECT * FROM recipes WHERE id = ?", (rid,)).fetchone()
            if r is None:
                return None
            ings = c.execute("SELECT name, per_serving FROM recipe_ingredients "
                             "WHERE recipe_id = ? ORDER BY position", (rid,))
            out = {k: r[k] for k in r.keys()}
            out["ingredients"] = {x["name"]: x["per_serving"] for x in ings}
            out["attempt_count"] = c.execute(
                "SELECT COUNT(*) FROM attempts WHERE recipe_id = ?", (rid,)).fetchone()[0]
            return out

    def recipe_by_name(self, name):
        rid = self.find_recipe_id(name)
        return self.recipe(rid) if rid else None

    def create_recipe(self, name, servings, ingredients, who, unit="g", notes=""):
        """ingredients: {name: amount per serving}, in display order."""
        name = name.strip()
        if not name:
            raise InvalidData("Give the recipe a name.")
        if self.find_recipe_id(name):
            raise InvalidData(f"There's already a recipe called “{name}”.")
        with self.tx() as c:
            rid = self._insert_recipe(c, name, servings, ingredients, unit, notes)
            snap = self._recipe_snap(c, rid)
            self._log(c, who, "create", "recipe", rid, f"Added recipe “{name}”", None, snap)
        return rid

    def _insert_recipe(self, c, name, servings, ingredients, unit="g", notes=""):
        now = self.now()
        rid = c.execute("INSERT INTO recipes (name, servings, unit, notes, rev, created_at, updated_at) "
                        "VALUES (?, ?, ?, ?, 1, ?, ?)",
                        (name, servings, unit or "", notes or "", now, now)).lastrowid
        c.executemany("INSERT INTO recipe_ingredients (recipe_id, position, name, per_serving) "
                      "VALUES (?, ?, ?, ?)",
                      [(rid, i, k, v) for i, (k, v) in enumerate(ingredients.items())])
        return rid

    def update_recipe(self, rid, name, servings, ingredients, who, expected_rev=None,
                      force=False, unit="g", notes=""):
        name = name.strip()
        if not name:
            raise InvalidData("Give the recipe a name.")
        if self.find_recipe_id(name, exclude_id=rid):
            raise InvalidData(f"There's already a recipe called “{name}”.")
        with self.tx() as c:
            before = self._recipe_snap(c, rid)
            if not force and expected_rev is not None and before["rev"] != expected_rev:
                raise Conflict(before)
            self._update_recipe_rows(c, rid, name, servings, ingredients, unit, notes)
            after = self._recipe_snap(c, rid)
            self._log(c, who, "update", "recipe", rid, f"Edited recipe “{name}”", before, after)

    def _update_recipe_rows(self, c, rid, name, servings, ingredients, unit, notes):
        c.execute("UPDATE recipes SET name=?, servings=?, unit=?, notes=?, rev=rev+1, updated_at=? "
                  "WHERE id=?", (name, servings, unit or "", notes or "", self.now(), rid))
        c.execute("DELETE FROM recipe_ingredients WHERE recipe_id = ?", (rid,))
        c.executemany("INSERT INTO recipe_ingredients (recipe_id, position, name, per_serving) "
                      "VALUES (?, ?, ?, ?)",
                      [(rid, i, k, v) for i, (k, v) in enumerate(ingredients.items())])

    def delete_recipe(self, rid, who):
        with self.tx() as c:
            before = self._recipe_snap(c, rid, with_bakes=True)
            c.execute("DELETE FROM recipes WHERE id = ?", (rid,))
            n = len(before["bakes"])
            extra = f" and its {n} bake{'s' if n != 1 else ''}" if n else ""
            self._log(c, who, "delete", "recipe", rid,
                      f"Deleted recipe “{before['name']}”{extra}", before, None)
        return before

    # ------------------------------------------------------------------- bakes

    def attempts_for_recipe(self, rid):
        """Bakes oldest-first, in the shape the original script used."""
        with self.conn() as c:
            rows = c.execute("SELECT * FROM attempts WHERE recipe_id = ? ORDER BY baked_on, id",
                             (rid,)).fetchall()
            return [self._attempt_dict(c, row) for row in rows]

    def _attempt_dict(self, c, row):
        ings = c.execute("SELECT name, actual, planned FROM attempt_ingredients "
                         "WHERE attempt_id = ? ORDER BY position", (row["id"],)).fetchall()
        a = {
            "id": row["id"],
            "recipe_id": row["recipe_id"],
            "date": row["baked_on"],
            "servings": row["servings"],
            "rating": row["rating"],
            "notes": row["notes"],
            "hydration": row["hydration"],
            "rev": row["rev"],
            "created_at": row["created_at"],
            "updated_at": row["updated_at"],
            "amounts": {r["name"]: r["actual"] for r in ings if r["actual"] is not None},
        }
        if row["from_plan"]:
            a["planned"] = {r["name"]: r["planned"] for r in ings if r["planned"] is not None}
        return a

    def attempt(self, aid):
        with self.conn() as c:
            row = c.execute("SELECT * FROM attempts WHERE id = ?", (aid,)).fetchone()
            return self._attempt_dict(c, row) if row else None

    def attempt_position(self, rid, baked_on, aid):
        with self.conn() as c:
            return c.execute(
                "SELECT COUNT(*) FROM attempts WHERE recipe_id = ? "
                "AND (baked_on < ? OR (baked_on = ? AND id <= ?))",
                (rid, baked_on, baked_on, aid)).fetchone()[0]

    def create_attempt(self, rid, a, who):
        """a: {"date", "amounts", "servings", "rating", "notes", optional
        "planned", optional "hydration"} -- the original script's shape."""
        with self.tx() as c:
            if c.execute("SELECT 1 FROM recipes WHERE id = ?", (rid,)).fetchone() is None:
                raise NotFound(rid)
            aid = self._insert_attempt(c, rid, a)
            snap = self._attempt_snap(c, aid)
            name = c.execute("SELECT name FROM recipes WHERE id = ?", (rid,)).fetchone()[0]
            self._log(c, who, "create", "bake", aid,
                      f"Logged a bake of “{name}” on {a['date']}", None, snap)
        return aid

    def _insert_attempt(self, c, rid, a):
        amounts = a.get("amounts") or {}
        planned = a.get("planned") or {}
        hyd = a["hydration"] if "hydration" in a else logic.bake_hydration(amounts)
        now = self.now()
        aid = c.execute(
            "INSERT INTO attempts (recipe_id, baked_on, servings, rating, notes, hydration, "
            "from_plan, rev, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?, ?)",
            (rid, a["date"], a.get("servings"), a.get("rating"), a.get("notes") or "",
             hyd, 1 if planned else 0, now, now)).lastrowid
        names = list(amounts) + [k for k in planned if k not in amounts]
        c.executemany("INSERT INTO attempt_ingredients (attempt_id, position, name, actual, planned) "
                      "VALUES (?, ?, ?, ?, ?)",
                      [(aid, i, k, amounts.get(k), planned.get(k)) for i, k in enumerate(names)])
        return aid

    def update_attempt(self, aid, a, who, expected_rev=None, force=False):
        with self.tx() as c:
            before = self._attempt_snap(c, aid)
            if not force and expected_rev is not None and before["rev"] != expected_rev:
                raise Conflict(before)
            self._update_attempt_rows(c, aid, a, before)
            after = self._attempt_snap(c, aid)
            name = c.execute("SELECT name FROM recipes WHERE id = ?",
                             (before["recipe_id"],)).fetchone()[0]
            self._log(c, who, "update", "bake", aid,
                      f"Edited the bake of “{name}” on {a['date']}", before, after)

    def _update_attempt_rows(self, c, aid, a, before):
        amounts = a.get("amounts") or {}
        if "planned" in a:
            planned = a["planned"] or {}
        else:
            planned = {n: p for n, _, p in before["ingredients"] if p is not None} \
                if before["from_plan"] else {}
        c.execute("UPDATE attempts SET baked_on=?, servings=?, rating=?, notes=?, hydration=?, "
                  "from_plan=?, rev=rev+1, updated_at=? WHERE id=?",
                  (a["date"], a.get("servings"), a.get("rating"), a.get("notes") or "",
                   logic.bake_hydration(amounts), 1 if planned else 0, self.now(), aid))
        c.execute("DELETE FROM attempt_ingredients WHERE attempt_id = ?", (aid,))
        names = list(amounts) + [k for k in planned if k not in amounts]
        c.executemany("INSERT INTO attempt_ingredients (attempt_id, position, name, actual, planned) "
                      "VALUES (?, ?, ?, ?, ?)",
                      [(aid, i, k, amounts.get(k), planned.get(k)) for i, k in enumerate(names)])

    def delete_attempt(self, aid, who):
        with self.tx() as c:
            before = self._attempt_snap(c, aid)
            name = c.execute("SELECT name FROM recipes WHERE id = ?",
                             (before["recipe_id"],)).fetchone()[0]
            c.execute("DELETE FROM attempts WHERE id = ?", (aid,))
            self._log(c, who, "delete", "bake", aid,
                      f"Deleted the bake of “{name}” on {before['baked_on']}", before, None)
        return before

    # ------------------------------------------------------------ lists/stats

    def recipe_list(self, q="", sort="name", desc=False, page=1, per_page=25):
        col = RECIPE_SORTS.get(sort, RECIPE_SORTS["name"])
        where, params = "", []
        if q:
            where = "WHERE r.name LIKE ? ESCAPE '\\' OR r.notes LIKE ? ESCAPE '\\'"
            params = [_like(q), _like(q)]
        base = (
            "SELECT r.id, r.name, r.servings, r.unit, COUNT(a.id) AS n_bakes, "
            "AVG(a.rating) AS avg_rating, AVG(a.hydration) AS avg_hydration, "
            "MAX(a.baked_on) AS last_baked "
            f"FROM recipes r LEFT JOIN attempts a ON a.recipe_id = r.id {where} GROUP BY r.id")
        order = f"({col}) IS NULL, {col} {'DESC' if desc else 'ASC'}, r.name COLLATE NOCASE, r.id"
        with self.conn() as c:
            total = c.execute(f"SELECT COUNT(*) FROM ({base})", params).fetchone()[0]
            rows = c.execute(f"{base} ORDER BY {order} LIMIT ? OFFSET ?",
                             params + [per_page, (page - 1) * per_page]).fetchall()
        return [dict(r) for r in rows], total

    def bake_list(self, q="", recipe_id=None, min_rating=None, date_from=None, date_to=None,
                  unrated=False, sort="date", desc=True, page=1, per_page=25):
        col = BAKE_SORTS.get(sort, BAKE_SORTS["date"])
        conds, params = [], []
        if q:
            conds.append("(b.recipe LIKE ? ESCAPE '\\' OR b.notes LIKE ? ESCAPE '\\')")
            params += [_like(q), _like(q)]
        if recipe_id:
            conds.append("b.recipe_id = ?")
            params.append(recipe_id)
        if min_rating:
            conds.append("b.rating >= ?")
            params.append(min_rating)
        if unrated:
            conds.append("b.rating IS NULL")
        if date_from:
            conds.append("b.baked_on >= ?")
            params.append(date_from)
        if date_to:
            conds.append("b.baked_on <= ?")
            params.append(date_to)
        where = ("WHERE " + " AND ".join(conds)) if conds else ""
        inner = (
            "SELECT a.id, a.recipe_id, r.name AS recipe, r.unit, a.baked_on, a.rating, "
            "a.servings, a.hydration, a.notes, "
            "ROW_NUMBER() OVER (PARTITION BY a.recipe_id ORDER BY a.baked_on, a.id) AS num "
            "FROM attempts a JOIN recipes r ON r.id = a.recipe_id")
        base = f"SELECT * FROM ({inner}) AS b {where}"
        order = f"({col}) IS NULL, {col} {'DESC' if desc else 'ASC'}, b.baked_on DESC, b.id DESC"
        with self.conn() as c:
            total = c.execute(f"SELECT COUNT(*) FROM ({base})", params).fetchone()[0]
            rows = c.execute(f"{base} ORDER BY {order} LIMIT ? OFFSET ?",
                             params + [per_page, (page - 1) * per_page]).fetchall()
        return [dict(r) for r in rows], total

    def overview(self):
        today = self.cfg.today()
        month_start = today.replace(day=1).isoformat()
        with self.conn() as c:
            one = lambda sql, *p: c.execute(sql, p).fetchone()[0]
            last10 = [r[0] for r in c.execute(
                "SELECT rating FROM attempts WHERE rating IS NOT NULL "
                "ORDER BY baked_on DESC, id DESC LIMIT 10")]
            return {
                "recipes": one("SELECT COUNT(*) FROM recipes"),
                "bakes": one("SELECT COUNT(*) FROM attempts"),
                "bakes_this_month": one("SELECT COUNT(*) FROM attempts WHERE baked_on >= ?",
                                        month_start),
                "avg_last10": (sum(last10) / len(last10)) if last10 else None,
                "n_last10": len(last10),
                "unrated": one("SELECT COUNT(*) FROM attempts WHERE rating IS NULL"),
                "never_baked": [dict(r) for r in c.execute(
                    "SELECT r.id, r.name FROM recipes r WHERE NOT EXISTS "
                    "(SELECT 1 FROM attempts a WHERE a.recipe_id = r.id) ORDER BY r.name COLLATE NOCASE")],
                "recent": [dict(r) for r in c.execute(
                    "SELECT a.id, a.baked_on, a.rating, a.hydration, a.notes, r.name AS recipe, "
                    "a.recipe_id FROM attempts a JOIN recipes r ON r.id = a.recipe_id "
                    "ORDER BY a.baked_on DESC, a.id DESC LIMIT 5")],
            }

    def recipe_report(self):
        with self.conn() as c:
            return [dict(r) for r in c.execute(
                "SELECT r.id, r.name, COUNT(a.id) AS n_bakes, AVG(a.rating) AS avg_rating, "
                "MAX(a.rating) AS best_rating, AVG(a.hydration) AS avg_hydration, "
                "MIN(a.baked_on) AS first_baked, MAX(a.baked_on) AS last_baked "
                "FROM recipes r LEFT JOIN attempts a ON a.recipe_id = r.id "
                "GROUP BY r.id ORDER BY r.name COLLATE NOCASE")]

    def chart_points(self, recipe_id=None):
        sql = ("SELECT a.baked_on, a.rating, a.hydration, r.name AS recipe FROM attempts a "
               "JOIN recipes r ON r.id = a.recipe_id ")
        params = []
        if recipe_id:
            sql += "WHERE a.recipe_id = ? "
            params.append(recipe_id)
        with self.conn() as c:
            return [dict(r) for r in c.execute(sql + "ORDER BY a.baked_on, a.id", params)]

    def ingredient_names(self):
        with self.conn() as c:
            names = [r[0] for r in c.execute(
                "SELECT name FROM recipe_ingredients UNION SELECT name FROM attempt_ingredients "
                "ORDER BY 1 COLLATE NOCASE")]
        return [n for n in names if n != "sdd"]

    # ----------------------------------------------------------------- export

    def export_data(self):
        with self.conn() as c:
            recipes = []
            for r in c.execute("SELECT id FROM recipes ORDER BY id").fetchall():
                snap = self._recipe_snap(c, r["id"])
                bakes = []
                for row in c.execute("SELECT * FROM attempts WHERE recipe_id = ? "
                                     "ORDER BY baked_on, id", (r["id"],)).fetchall():
                    a = self._attempt_dict(c, row)
                    bakes.append({
                        "id": a["id"], "date": a["date"], "servings": a["servings"],
                        "rating": a["rating"], "notes": a["notes"], "hydration": a["hydration"],
                        "amounts": a["amounts"], "planned": a.get("planned"),
                        "created_at": a["created_at"], "updated_at": a["updated_at"],
                    })
                recipes.append({
                    "id": snap["id"], "name": snap["name"], "servings": snap["servings"],
                    "unit": snap["unit"], "notes": snap["notes"],
                    "ingredients": [{"name": n, "per_serving": v} for n, v in snap["ingredients"]],
                    "created_at": snap["created_at"], "updated_at": snap["updated_at"],
                    "bakes": bakes,
                })
        return {"app": "recipehelper", "schema_version": SCHEMA_VERSION,
                "app_version": __version__, "exported_at": self.now(), "recipes": recipes}

    def export_bakes_csv(self):
        data = self.export_data()
        ing_cols, plan_cols = [], []
        for r in data["recipes"]:
            for b in r["bakes"]:
                for k in b["amounts"]:
                    if k not in ing_cols:
                        ing_cols.append(k)
                for k in (b["planned"] or {}):
                    if k not in plan_cols:
                        plan_cols.append(k)
        out = io.StringIO()
        w = csv.writer(out)
        w.writerow(["id", "date", "recipe", "rating", "servings", "hydration", "notes"]
                   + ing_cols + [f"planned: {k}" for k in plan_cols])
        for r in data["recipes"]:
            for b in r["bakes"]:
                w.writerow([b["id"], b["date"], r["name"], b["rating"] or "",
                            _num(b["servings"]), _num(b["hydration"]), b["notes"]]
                           + [_num(b["amounts"].get(k)) for k in ing_cols]
                           + [_num((b["planned"] or {}).get(k)) for k in plan_cols])
        return out.getvalue()

    def export_recipes_csv(self):
        data = self.export_data()
        out = io.StringIO()
        w = csv.writer(out)
        w.writerow(["recipe", "servings", "unit", "ingredient", "amount", "per serving", "notes"])
        for r in data["recipes"]:
            for i, ing in enumerate(r["ingredients"]):
                w.writerow([r["name"], _num(r["servings"]), r["unit"], ing["name"],
                            _num(ing["per_serving"] * r["servings"]), _num(ing["per_serving"]),
                            r["notes"] if i == 0 else ""])
            if not r["ingredients"]:
                w.writerow([r["name"], _num(r["servings"]), r["unit"], "", "", "", r["notes"]])
        return out.getvalue()

    # ----------------------------------------------------------------- import

    def bake_keys(self):
        """{duplicate key: bake id} for all bakes."""
        out = {}
        with self.conn() as c:
            for row in c.execute("SELECT a.*, r.name AS recipe FROM attempts a "
                                 "JOIN recipes r ON r.id = a.recipe_id").fetchall():
                a = self._attempt_dict(c, row)
                out.setdefault(logic.bake_key(row["recipe"], a["date"], a["amounts"]), a["id"])
        return out

    def apply_import(self, actions, who, source):
        """Run a confirmed import plan in one transaction, after a backup.
        actions: dicts with op (add/update), type (recipe/bake) and data."""
        safety = self.backup("pre-import")
        counts = {"recipes added": 0, "recipes updated": 0, "bakes added": 0, "bakes updated": 0}
        with self.tx() as c:
            def rid_for(name):
                r = c.execute("SELECT id FROM recipes WHERE lower(trim(name)) = lower(trim(?))",
                              (name,)).fetchone()
                return r["id"] if r else None
            renamed = {}  # recipes added "anyway" under a new name
            for act in actions:
                d = act["data"]
                if act["type"] == "recipe":
                    if act["op"] == "update" and rid_for(d["name"]):
                        rid = rid_for(d["name"])
                        cur = c.execute("SELECT name FROM recipes WHERE id = ?", (rid,)).fetchone()[0]
                        self._update_recipe_rows(c, rid, cur, d["servings"], d["ingredients"],
                                                 d.get("unit", "g"), d.get("notes", ""))
                        counts["recipes updated"] += 1
                    else:
                        name = d["name"]
                        n = 2
                        while rid_for(name):
                            name = f"{d['name']} ({n})"
                            n += 1
                        self._insert_recipe(c, name, d["servings"], d["ingredients"],
                                            d.get("unit", "g"), d.get("notes", ""))
                        renamed[d["name"].strip().lower()] = name
                        counts["recipes added"] += 1
                else:
                    target = d["recipe"]
                    if d.get("follow_copy"):
                        target = renamed.get(target.strip().lower(), target)
                    rid = rid_for(target)
                    if rid is None:
                        continue
                    if act["op"] == "update" and act.get("target_id"):
                        before = self._attempt_snap(c, act["target_id"])
                        self._update_attempt_rows(c, act["target_id"], d, before)
                        counts["bakes updated"] += 1
                    else:
                        self._insert_attempt(c, rid, d)
                        counts["bakes added"] += 1
            summary = "Imported from " + source + ": " + ", ".join(
                f"{v} {k}" for k, v in counts.items() if v) if any(counts.values()) \
                else f"Imported from {source}: nothing changed"
            self._log(c, who, "import", "data", None, summary, None, counts, backup=safety)
        return counts, safety


def _num(v):
    if v is None:
        return ""
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return repr(v) if isinstance(v, float) else str(v)
