"""Settings, read from environment variables (and an optional .env file).

Production: systemd loads /etc/recipehelper/recipehelper.env.
Development: a .env file in the working directory, or nothing at all.
"""
import os
import secrets
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta

try:
    from zoneinfo import ZoneInfo
except ImportError:  # pragma: no cover - Python < 3.9
    ZoneInfo = None


def _bool(v, default=False):
    if v is None or v == "":
        return default
    return v.strip().lower() in ("1", "true", "yes", "on")


def _int(v, default):
    try:
        return int(v)
    except (TypeError, ValueError):
        return default


@dataclass
class Config:
    data_dir: str = "data"
    db_name: str = "recipes.db"
    secret_key: str = ""
    timezone: str = ""
    secure_cookies: bool = False
    allowed_users: list = field(default_factory=list)
    backup_keep: int = 0          # 0 = never delete backups automatically
    page_size: int = 25
    us_dates: bool = True         # 05/11/2026 = May 11 when importing

    @property
    def db_path(self):
        return os.path.join(self.data_dir, self.db_name)

    @property
    def backup_dir(self):
        return os.path.join(self.data_dir, "backups")

    @property
    def import_dir(self):
        return os.path.join(self.data_dir, "imports")

    def tzinfo(self):
        if self.timezone and ZoneInfo is not None:
            try:
                return ZoneInfo(self.timezone)
            except Exception:
                pass
        return datetime.now().astimezone().tzinfo

    def now(self):
        return datetime.now(self.tzinfo())

    def today(self):
        return self.now().date()

    def yesterday(self):
        return self.today() - timedelta(days=1)

    @classmethod
    def from_env(cls, env=None, load_dotenv_file=True):
        if env is None:
            if load_dotenv_file:
                try:
                    from dotenv import load_dotenv
                    load_dotenv(os.environ.get("RECIPEHELPER_ENV_FILE", ".env"))
                except ImportError:
                    pass
            env = os.environ
        cfg = cls(
            data_dir=env.get("DATA_DIR") or env.get("RECIPEHELPER_DATA_DIR") or "data",
            secret_key=env.get("SECRET_KEY", ""),
            timezone=env.get("TIMEZONE") or env.get("TZ") or "",
            secure_cookies=_bool(env.get("SECURE_COOKIES")),
            allowed_users=[u.strip().lower() for u in env.get("ALLOWED_USERS", "").split(",")
                           if u.strip()],
            backup_keep=max(0, _int(env.get("BACKUP_KEEP"), 0)),
            page_size=min(200, max(5, _int(env.get("PAGE_SIZE"), 25))),
            us_dates=_bool(env.get("US_DATES"), True),
        )
        return cfg

    def ensure_dirs(self):
        for d in (self.data_dir, self.backup_dir, self.import_dir):
            os.makedirs(d, exist_ok=True)

    def resolve_secret_key(self):
        """SECRET_KEY from the environment, else one stored in the data folder
        (created once), so every worker process shares the same key."""
        if self.secret_key:
            return self.secret_key
        path = os.path.join(self.data_dir, ".secret_key")
        try:
            with open(path, encoding="utf-8") as f:
                key = f.read().strip()
            if key:
                self.secret_key = key
                return key
        except OSError:
            pass
        key = secrets.token_hex(32)
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "w") as f:
            f.write(key)
        self.secret_key = key
        return key


def today_iso(cfg):
    return cfg.today().isoformat()


def parse_iso_date(s):
    try:
        return date.fromisoformat((s or "").strip())
    except ValueError:
        return None
