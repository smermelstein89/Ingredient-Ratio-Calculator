"""Importing: pasted tables (Google Sheets, Excel, Numbers), CSV files and
JSON files. Nothing is written here: build_preview() works out what would
happen, the person confirms, then storage.Store.apply_import() runs it.

Two table shapes are understood:

* Bakes  - one row per bake: date, recipe, rating, servings, notes, and one
           column per ingredient amount ("planned: <ingredient>" columns hold
           the planned amounts).
* Recipes - one row per ingredient: recipe, servings, unit, ingredient,
           amount (for the whole batch) or per serving, notes.
"""
import csv
import io
import json
import os
import re
import secrets
import time
from datetime import date, datetime, timedelta

from . import logic

MAX_TEXT = 2 * 1024 * 1024
TOKEN_RE = re.compile(r"^[A-Za-z0-9_-]{16,64}$")

BAKE_FIELDS = {
    "date": "Date",
    "recipe": "Recipe",
    "rating": "Rating",
    "servings": "Servings made",
    "notes": "Notes",
    "ingredient": "Ingredient amount",
    "planned": "Planned amount",
    "ignore": "Ignore",
}
RECIPE_FIELDS = {
    "recipe": "Recipe",
    "servings": "Servings (batch)",
    "unit": "Unit",
    "ingredient": "Ingredient",
    "amount": "Amount (whole batch)",
    "per_serving": "Amount per serving",
    "notes": "Notes",
    "ignore": "Ignore",
}
BAKE_ALIASES = {
    "date": ["date", "baked", "baked on", "bake date", "day", "when", "date baked"],
    "recipe": ["recipe", "recipe name", "bread", "name", "bake", "what"],
    "rating": ["rating", "stars", "score", "rate", "rating 1 5", "rating out of 5", "rating 5"],
    "servings": ["servings", "servings made", "yield", "made", "loaves", "pieces", "qty made"],
    "notes": ["notes", "note", "comments", "comment", "remarks", "notes comments"],
}
IGNORED_BAKE_ALIASES = {
    "hydration": "calculated by the app",
    "hydration %": "calculated by the app",
    "hyd": "calculated by the app",
    "id": "not needed",
    "bake id": "not needed",
    "num": "not needed",
    "#": "not needed",
}
RECIPE_ALIASES = {
    "recipe": ["recipe", "recipe name", "bread", "name"],
    "servings": ["servings", "batch servings", "yield", "makes", "serves"],
    "unit": ["unit", "units", "uom"],
    "ingredient": ["ingredient", "ingredients", "item", "ingredient name"],
    "amount": ["amount", "total", "quantity", "qty", "batch amount", "weight", "grams", "amount batch"],
    "per_serving": ["per serving", "amount per serving", "per portion"],
    "notes": ["notes", "note", "comments", "comment"],
}
SUMMARY_RE = re.compile(r"^(grand total|total|totals|sum|average|avg|mean|median|count)\b")
MONTHS = {m: i for i, m in enumerate(
    ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], 1)}


# --------------------------------------------------------------- value parsing

def normalize_header(h):
    h = (h or "").replace(" ", " ").lower()
    h = re.sub(r"[^a-z0-9%#]+", " ", h)
    return re.sub(r"\s+", " ", h).strip()


def clean_name(h):
    """Header -> ingredient name: one line, without a trailing '(g)' unit."""
    h = re.sub(r"\s+", " ", (h or "").replace(" ", " ")).strip()
    h = re.sub(r"\s*\((g|kg|grams?|ml|l|oz|lb|%|tsp|tbsp|cups?)\)\s*$", "", h, flags=re.I)
    return h.strip()


def parse_duration(s):
    """'8:34:29' -> seconds; '34:29' -> seconds (minutes:seconds)."""
    m = re.fullmatch(r"\s*(\d+):(\d{2})(?::(\d{2}))?\s*", s or "")
    if not m:
        raise ValueError(f"“{s}” isn't a duration")
    a, b, c = m.groups()
    if c is None:
        return int(a) * 60 + int(b)
    return int(a) * 3600 + int(b) * 60 + int(c)


def parse_number(s, decimal_comma=False):
    """Numbers as people type them in spreadsheets: '1,234.5', '1.234,5',
    '$12', '75%', ' 980 g'. Blank -> None. Raises ValueError otherwise."""
    s = (s or "").replace(" ", " ").replace(" ", " ").strip()
    if s == "":
        return None
    if re.fullmatch(r"-?\d+:\d{2}(:\d{2})?", s):
        raise ValueError(f"“{s}” looks like a time, not an amount")
    neg = s.startswith("(") and s.endswith(")")
    if neg:
        s = s[1:-1]
    s = re.sub(r"(?i)[$€£¥₹]|\b(usd|eur|gbp|cad|aud)\b", "", s).strip()
    s = re.sub(r"(?i)\s*(g|kg|grams?|ml|oz|lb)$", "", s).strip()
    s = s.rstrip("%").strip()
    s = s.replace(" ", "").replace("'", "")
    if "," in s and "." in s:
        if s.rfind(",") > s.rfind("."):
            s = s.replace(".", "").replace(",", ".")
        else:
            s = s.replace(",", "")
    elif "," in s:
        if not decimal_comma and re.fullmatch(r"-?\d{1,3}(,\d{3})+", s):
            s = s.replace(",", "")
        else:
            s = s.replace(",", ".")
    try:
        v = float(s)
    except ValueError:
        raise ValueError(f"“{s}” isn't a number") from None
    if v != v or v in (float("inf"), float("-inf")):
        raise ValueError(f"“{s}” isn't a number")
    return -v if neg else v


def parse_rating(s):
    s = (s or "").strip()
    if not s or s in ("-", "–"):
        return None
    if "★" in s or "*" in s:
        n = s.count("★") + s.count("*")
    else:
        m = re.fullmatch(r"(\d+(?:[.,]0+)?)\s*(?:/\s*5|stars?|out of 5)?", s, flags=re.I)
        if not m:
            raise ValueError(f"rating “{s}” should be a whole number from 1 to 5")
        n = int(float(m.group(1).replace(",", ".")))
    if not 1 <= n <= 5:
        raise ValueError(f"rating “{s}” should be from 1 to 5")
    return n


def parse_date(s, us=True):
    """Common spreadsheet date formats -> date. Raises ValueError."""
    raw = s
    s = (s or "").strip()
    if not s:
        raise ValueError("the date is missing")
    s = re.sub(r"[T ]\d{1,2}:\d{2}(:\d{2})?(\.\d+)?\s*(am|pm)?([+-]\d{2}:?\d{2}|Z)?$", "", s, flags=re.I)
    s = re.sub(r"^(mon|tue|wed|thu|fri|sat|sun)[a-z]*,?\s+", "", s, flags=re.I).strip()
    try:
        if re.fullmatch(r"\d{4}[-/.]\d{1,2}[-/.]\d{1,2}", s):
            y, m, d = map(int, re.split(r"[-/.]", s))
            return date(y, m, d)
        m = re.fullmatch(r"(\d{1,2})([/.-])(\d{1,2})\2(\d{2}|\d{4})", s)
        if m:
            a, sep, b, y = int(m.group(1)), m.group(2), int(m.group(3)), int(m.group(4))
            if y < 100:
                y += 2000
            day_first = (sep == ".") or not us
            if a > 12:
                day_first = True
            elif b > 12:
                day_first = False
            return date(y, b, a) if day_first else date(y, a, b)
        if re.fullmatch(r"\d{5}(\.\d+)?", s):
            n = float(s)
            if 20000 <= n <= 80000:  # spreadsheet serial day number
                return date(1899, 12, 30) + timedelta(days=int(n))
        t = re.sub(r"[,]", " ", s.lower())
        t = re.sub(r"(\d)(st|nd|rd|th)\b", r"\1", t)
        parts = [p for p in re.split(r"[\s\-/]+", t) if p]
        if len(parts) == 3:
            mon = [p for p in parts if p[:3] in MONTHS and not p.isdigit()]
            nums = [p for p in parts if p.isdigit()]
            if len(mon) == 1 and len(nums) == 2:
                month = MONTHS[mon[0][:3]]
                yi = [n for n in nums if len(n) == 4]
                year = int(yi[0]) if yi else int(nums[1]) + 2000
                day = int([n for n in nums if n != (yi[0] if yi else nums[1])][0]) if yi else int(nums[0])
                return date(year, month, day)
    except ValueError:
        pass
    raise ValueError(f"couldn't read the date “{raw}”")


# ---------------------------------------------------------------- table reader

def detect_delimiter(text):
    lines = [ln for ln in text.splitlines() if ln.strip()][:10]
    if not lines:
        return ","
    best, best_score = ",", -1
    for d in ("\t", ",", ";"):
        try:
            rows = list(csv.reader(io.StringIO("\n".join(lines)), delimiter=d))
        except csv.Error:
            continue
        counts = [len(r) for r in rows if any(c.strip() for c in r)]
        if not counts or max(counts) < 2:
            continue
        mode = max(set(counts), key=counts.count)
        score = counts.count(mode) * 10 + mode + (5 if d == "\t" else 0)
        if score > best_score:
            best, best_score = d, score
    return best


def read_table(text, delimiter=None):
    """-> (delimiter, headers, [(line_number, cells)]). Blank rows dropped."""
    text = text.lstrip("﻿")
    d = delimiter or detect_delimiter(text)
    reader = csv.reader(io.StringIO(text), delimiter=d)
    headers, rows = None, []
    for cells in reader:
        line = reader.line_num
        if not any((c or "").strip() for c in cells):
            continue
        if headers is None:
            headers = [re.sub(r"\s+", " ", c).strip() for c in cells]
            continue
        rows.append((line, [c.strip() for c in cells]))
    return d, headers or [], rows


def is_summary_row(cells):
    first = [c for c in cells if c.strip()][:2]
    return any(SUMMARY_RE.match(normalize_header(c)) for c in first)


def _match(header, aliases):
    n = normalize_header(header)
    for field, names in aliases.items():
        if n in names:
            return field
    return None


def _looks_numeric(values, decimal_comma):
    vals = [v for v in values if v.strip()]
    if not vals:
        return False
    ok = 0
    for v in vals:
        try:
            parse_number(v, decimal_comma)
            ok += 1
        except ValueError:
            pass
    return ok >= max(1, len(vals) // 2)


def guess_kind(headers):
    fields = {_match(h, RECIPE_ALIASES) for h in headers}
    if "ingredient" in fields and ({"amount", "per_serving"} & fields):
        return "recipes"
    return "bakes"


def default_mapping(kind, headers, rows, decimal_comma):
    mapping, notes = [], []
    used = set()
    for i, h in enumerate(headers):
        col = [cells[i] if i < len(cells) else "" for _, cells in rows]
        norm = normalize_header(h)
        if not norm:
            mapping.append("ignore")
            notes.append("empty header")
            continue
        if kind == "recipes":
            f = _match(h, RECIPE_ALIASES)
            if f and f not in used:
                mapping.append(f)
                used.add(f)
                notes.append("")
            else:
                mapping.append("ignore")
                notes.append("not recognised" if not f else "already used by another column")
            continue
        if norm.startswith("planned"):
            mapping.append("planned")
            notes.append("")
            continue
        if norm in IGNORED_BAKE_ALIASES:
            mapping.append("ignore")
            notes.append(IGNORED_BAKE_ALIASES[norm])
            continue
        f = _match(h, BAKE_ALIASES)
        if f and f not in used:
            mapping.append(f)
            used.add(f)
            notes.append("")
        elif _looks_numeric(col, decimal_comma):
            mapping.append("ingredient")
            notes.append("")
        else:
            mapping.append("ignore")
            notes.append("not recognised")
    return mapping, notes


def ingredient_from_header(h):
    name = clean_name(h)
    if normalize_header(name).startswith("planned"):
        name = re.sub(r"(?i)^planned\s*[:\-]?\s*", "", name).strip()
    return name


# ------------------------------------------------------------------- previews

def new_job(cfg, kind, source, text=None, data=None, us_dates=True):
    os.makedirs(cfg.import_dir, exist_ok=True)
    _cleanup(cfg)
    token = secrets.token_urlsafe(18)
    job = {"token": token, "kind": kind, "source": source, "created": time.time(),
           "text": text, "data": data, "mapping": None, "mode": "skip",
           "default_recipe": "", "us_dates": us_dates}
    save_job(cfg, job)
    return job


def _job_path(cfg, token):
    if not TOKEN_RE.match(token or ""):
        raise KeyError(token)
    return os.path.join(cfg.import_dir, token + ".json")


def save_job(cfg, job):
    path = _job_path(cfg, job["token"])
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(job, f)
    os.replace(tmp, path)


def load_job(cfg, token):
    try:
        with open(_job_path(cfg, token), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        raise KeyError(token) from None


def drop_job(cfg, token):
    try:
        os.remove(_job_path(cfg, token))
    except (OSError, KeyError):
        pass


def _cleanup(cfg, max_age=86400):
    """Remove unfinished import previews older than a day (temporary files,
    not backups)."""
    try:
        for n in os.listdir(cfg.import_dir):
            p = os.path.join(cfg.import_dir, n)
            if n.endswith(".json") and time.time() - os.path.getmtime(p) > max_age:
                os.remove(p)
    except OSError:
        pass


def build_preview(store, job):
    if job["kind"] == "json":
        return _preview_json(store, job)
    d, headers, rows = read_table(job["text"] or "")
    decimal_comma = d == ";"
    kind = job["kind"] if job["kind"] in ("bakes", "recipes") else guess_kind(headers)
    fields = RECIPE_FIELDS if kind == "recipes" else BAKE_FIELDS
    auto_map, notes = default_mapping(kind, headers, rows, decimal_comma)
    mapping = job.get("mapping") or auto_map
    if len(mapping) != len(headers):
        mapping = auto_map
    mapping = [m if m in fields else "ignore" for m in mapping]
    columns = [{"index": i, "header": h, "field": mapping[i], "auto": auto_map[i],
                "note": notes[i] if mapping[i] == auto_map[i] else "changed by you"}
               for i, h in enumerate(headers)]
    pv = {"kind": kind, "delimiter": {"\t": "tab", ",": "comma", ";": "semicolon"}[d],
          "columns": columns, "fields": fields, "rows": [], "errors": [],
          "unknown": [c["header"] for c in columns if c["note"] == "not recognised"],
          "mode": job.get("mode", "skip"), "actions": []}
    if not headers:
        pv["errors"].append("No header row found. Paste the table including its first row of column names.")
        return _finish(pv)
    if kind == "recipes":
        _preview_recipe_rows(store, job, pv, rows, mapping, decimal_comma)
    else:
        _preview_bake_rows(store, job, pv, headers, rows, mapping, decimal_comma)
    return _finish(pv)


def _finish(pv):
    counts = {"add": 0, "update": 0, "skip": 0, "error": 0}
    for r in pv["rows"]:
        counts[r["status"]] = counts.get(r["status"], 0) + 1
    pv["counts"] = counts
    pv["can_import"] = not pv["errors"] and (counts["add"] + counts["update"]) > 0
    return pv


def _cell(cells, i):
    return cells[i] if i is not None and i < len(cells) else ""


def _preview_bake_rows(store, job, pv, headers, rows, mapping, decimal_comma):
    col = {f: mapping.index(f) if f in mapping else None
           for f in ("date", "recipe", "rating", "servings", "notes")}
    ing_cols = [(i, ingredient_from_header(headers[i])) for i, m in enumerate(mapping) if m == "ingredient"]
    plan_cols = [(i, ingredient_from_header(headers[i])) for i, m in enumerate(mapping) if m == "planned"]
    pv["key_desc"] = "same recipe, date and amounts"
    if col["date"] is None:
        pv["errors"].append("No column is set as Date. Pick one in the column list.")
    if col["recipe"] is None and not job.get("default_recipe"):
        pv["errors"].append("No column is set as Recipe. Pick one, or choose a recipe for every row.")
    if not ing_cols:
        pv["errors"].append("No ingredient amount columns. Set at least one column to “Ingredient amount”.")
    if pv["errors"]:
        return
    recipes = {}
    for name in store.recipe_names():
        r = store.recipe_by_name(name)
        recipes[name.strip().lower()] = r
    existing = store.bake_keys()
    seen = {}
    mode = job.get("mode", "skip")
    for line, cells in rows:
        row = {"line": line, "status": "add", "reason": "", "summary": "", "key": ""}
        pv["rows"].append(row)
        if is_summary_row(cells):
            row.update(status="skip", reason="summary row (total / average)")
            continue
        errs = []
        try:
            d = parse_date(_cell(cells, col["date"]), us=job.get("us_dates", True)).isoformat()
        except ValueError as e:
            errs.append(str(e))
            d = None
        rname = _cell(cells, col["recipe"]) or job.get("default_recipe", "")
        recipe = recipes.get(rname.strip().lower())
        if not rname:
            errs.append("no recipe")
        elif recipe is None:
            errs.append(f"no recipe called “{rname}” — add it or import recipes first")
        canon = {k.lower(): k for k in (recipe["ingredients"] if recipe else {})}
        amounts, planned = {}, {}
        for target, cols in ((amounts, ing_cols), (planned, plan_cols)):
            for i, name in cols:
                try:
                    v = parse_number(_cell(cells, i), decimal_comma)
                except ValueError as e:
                    errs.append(f"{name}: {e}")
                    continue
                if v is None:
                    continue
                if v < 0:
                    errs.append(f"{name}: can't be negative")
                    continue
                target[canon.get(name.lower(), name)] = v
        rating = servings = None
        try:
            rating = parse_rating(_cell(cells, col["rating"]))
        except ValueError as e:
            errs.append(str(e))
        try:
            servings = parse_number(_cell(cells, col["servings"]), decimal_comma)
            if servings is not None and servings < 0:
                errs.append("servings can't be negative")
        except ValueError as e:
            errs.append(f"servings: {e}")
        if not amounts and not errs:
            errs.append("no ingredient amounts in this row")
        if errs:
            row.update(status="error", reason="; ".join(errs))
            continue
        data = {"recipe": recipe["name"], "date": d, "amounts": amounts, "servings": servings,
                "rating": rating, "notes": _cell(cells, col["notes"])}
        if planned:
            data["planned"] = planned
        key = logic.bake_key(recipe["name"], d, amounts)
        row["key"] = logic.describe_bake_key(key)
        row["summary"] = f"{recipe['name']} · {d}" + (f" · {rating}★" if rating else "")
        dup_id = existing.get(key)
        dup_line = seen.get(key)
        seen.setdefault(key, line)
        if dup_line is not None and mode != "add":
            row.update(status="skip", reason=f"same as line {dup_line} of this import")
            continue
        if dup_id is not None:
            if mode == "skip":
                row.update(status="skip", reason="already in your bake log")
                continue
            if mode == "update":
                row.update(status="update", reason="will update the matching bake")
                pv["actions"].append({"op": "update", "type": "bake", "target_id": dup_id, "data": data})
                continue
            row["reason"] = "duplicate, added anyway"
        pv["actions"].append({"op": "add", "type": "bake", "data": data})


def _preview_recipe_rows(store, job, pv, rows, mapping, decimal_comma):
    col = {f: mapping.index(f) if f in mapping else None for f in RECIPE_FIELDS}
    pv["key_desc"] = "same recipe name (capitals ignored)"
    if col["recipe"] is None:
        pv["errors"].append("No column is set as Recipe.")
    if col["ingredient"] is None:
        pv["errors"].append("No column is set as Ingredient.")
    if col["amount"] is None and col["per_serving"] is None:
        pv["errors"].append("No column is set as Amount (whole batch) or Amount per serving.")
    if pv["errors"]:
        return
    groups = {}
    order = []
    errors_by_line = {}
    current = None
    for line, cells in rows:
        if is_summary_row(cells):
            pv["rows"].append({"line": line, "status": "skip", "reason": "summary row (total / average)",
                               "summary": "", "key": ""})
            continue
        name = _cell(cells, col["recipe"]) or (current or "")
        if not name:
            errors_by_line[line] = "no recipe name"
            continue
        current = name
        k = name.strip().lower()
        if k not in groups:
            groups[k] = {"name": name.strip(), "lines": [], "servings": None, "unit": "",
                         "notes": "", "items": [], "errors": []}
            order.append(k)
        g = groups[k]
        g["lines"].append(line)
        try:
            s = parse_number(_cell(cells, col["servings"]), decimal_comma)
            if s is not None:
                if s <= 0:
                    g["errors"].append(f"line {line}: servings must be more than 0")
                elif g["servings"] is None:
                    g["servings"] = s
        except ValueError as e:
            g["errors"].append(f"line {line}: servings: {e}")
        g["unit"] = g["unit"] or _cell(cells, col["unit"])
        g["notes"] = g["notes"] or _cell(cells, col["notes"])
        ing = _cell(cells, col["ingredient"])
        try:
            amt = parse_number(_cell(cells, col["amount"]), decimal_comma)
            per = parse_number(_cell(cells, col["per_serving"]), decimal_comma)
        except ValueError as e:
            g["errors"].append(f"line {line}: {e}")
            continue
        if not ing:
            if amt is not None or per is not None:
                g["errors"].append(f"line {line}: amount without an ingredient name")
            continue
        if amt is None and per is None:
            g["errors"].append(f"line {line}: {ing} has no amount")
            continue
        if (amt is not None and amt < 0) or (per is not None and per < 0):
            g["errors"].append(f"line {line}: {ing} can't be negative")
            continue
        g["items"].append((line, ing.strip(), amt, per))
    for line, msg in errors_by_line.items():
        pv["rows"].append({"line": line, "status": "error", "reason": msg, "summary": "", "key": ""})
    index = store.recipe_index()
    mode = job.get("mode", "skip")
    for k in order:
        g = groups[k]
        first = g["lines"][0]
        row = {"line": first, "status": "add", "reason": "", "key": g["name"].lower(),
               "summary": f"{g['name']} · {len(g['items'])} ingredient(s)"}
        pv["rows"].append(row)
        errs = list(g["errors"])
        if g["servings"] is None:
            errs.append(f"line {first}: servings missing for {g['name']}")
        ingredients = {}
        for line, ing, amt, per in g["items"]:
            if ing.lower() in {x.lower() for x in ingredients}:
                errs.append(f"line {line}: {ing} is listed twice")
                continue
            if g["servings"]:
                ingredients[ing] = amt / g["servings"] if amt is not None else per
        if errs:
            row.update(status="error", reason="; ".join(errs))
            continue
        data = {"name": g["name"], "servings": g["servings"], "unit": g["unit"] or "g",
                "notes": g["notes"], "ingredients": ingredients}
        if k in index:
            if mode == "skip":
                row.update(status="skip", reason="you already have this recipe")
                continue
            if mode == "update":
                row.update(status="update", reason="will replace its servings and ingredients")
                pv["actions"].append({"op": "update", "type": "recipe", "data": data})
                continue
            row["reason"] = "duplicate name, added as a copy"
        pv["actions"].append({"op": "add", "type": "recipe", "data": data})
    pv["rows"].sort(key=lambda r: r["line"])


# ------------------------------------------------------------------------ JSON

def parse_json_text(text):
    """-> (format description, [recipe dicts]). Raises ValueError."""
    try:
        data = json.loads(text)
    except ValueError as e:
        raise ValueError(f"That isn't valid JSON ({e}).") from None
    if isinstance(data, dict) and isinstance(data.get("recipes"), list):
        ver = data.get("schema_version")
        if not isinstance(ver, int) or ver > 2:
            raise ValueError(f"Unknown export version {ver!r}; this app reads versions 1–2.")
        recipes = []
        for r in data["recipes"]:
            if not isinstance(r, dict):
                raise ValueError("A recipe entry isn't an object.")
            ings = r.get("ingredients") or []
            if isinstance(ings, dict):
                ings = [{"name": k, "per_serving": v} for k, v in ings.items()]
            recipes.append({
                "name": r.get("name"), "servings": r.get("servings"),
                "unit": r.get("unit") or "g", "notes": r.get("notes") or "",
                "ingredients": [(i.get("name"), i.get("per_serving")) for i in ings
                                if isinstance(i, dict)],
                "bakes": r.get("bakes") or r.get("attempts") or [],
            })
        return f"Recipe Helper export (schema {ver})", recipes
    if isinstance(data, dict) and data and all(
            isinstance(v, dict) and "ingredients" in v for v in data.values()):
        recipes = []
        for name, r in data.items():
            ings = r.get("ingredients") or {}
            recipes.append({
                "name": name, "servings": r.get("servings"), "unit": "g", "notes": "",
                "ingredients": list(ings.items()) if isinstance(ings, dict) else [],
                "bakes": r.get("attempts") or [],
            })
        return "original script’s recipes.json", recipes
    raise ValueError("This JSON isn't a Recipe Helper file (no recipes found).")


def _num(v, what, errs, allow_none=True, positive=False):
    if v is None or v == "":
        if not allow_none:
            errs.append(f"{what} is missing")
        return None
    if isinstance(v, bool) or not isinstance(v, (int, float, str)):
        errs.append(f"{what} isn't a number")
        return None
    try:
        x = float(v) if not isinstance(v, str) else parse_number(v)
    except ValueError:
        errs.append(f"{what} isn't a number")
        return None
    if x is None:
        return None
    if x < 0 or (positive and x <= 0):
        errs.append(f"{what} must be {'more than 0' if positive else 'at least 0'}")
        return None
    return x


def _preview_json(store, job):
    pv = {"kind": "json", "columns": [], "fields": {}, "rows": [], "errors": [], "unknown": [],
          "mode": job.get("mode", "skip"), "actions": [], "delimiter": None,
          "key_desc": "recipes: same name · bakes: same recipe, date and amounts"}
    try:
        fmt, recipes = parse_json_text(job["data"] or "")
    except ValueError as e:
        pv["errors"].append(str(e))
        return _finish(pv)
    pv["format"] = fmt
    index = store.recipe_index()
    existing = store.bake_keys()
    mode = job.get("mode", "skip")
    seen = set()
    n = 0
    for r in recipes:
        n += 1
        errs = []
        name = (r["name"] or "").strip() if isinstance(r["name"], str) else ""
        if not name:
            errs.append("recipe has no name")
        servings = _num(r["servings"], "servings", errs, allow_none=False, positive=True)
        ingredients = {}
        for iname, val in r["ingredients"]:
            if not isinstance(iname, str) or not iname.strip():
                errs.append("an ingredient has no name")
                continue
            v = _num(val, iname, errs, allow_none=False)
            if v is not None:
                ingredients[iname] = v
        row = {"line": f"recipe {n}", "status": "add", "reason": "", "key": name.lower(),
               "summary": f"Recipe: {name or '?'}"}
        pv["rows"].append(row)
        if errs:
            row.update(status="error", reason="; ".join(errs))
            continue
        data = {"name": name, "servings": servings, "unit": r["unit"], "notes": r["notes"],
                "ingredients": ingredients}
        target_name = name
        if name.lower() in index:
            if mode == "skip":
                row.update(status="skip", reason="you already have this recipe (its bakes are still checked)")
            elif mode == "update":
                row.update(status="update", reason="will replace its servings and ingredients")
                pv["actions"].append({"op": "update", "type": "recipe", "data": data})
            else:
                row["reason"] = "duplicate name, added as a copy (its bakes go with the copy)"
                pv["actions"].append({"op": "add", "type": "recipe", "data": data})
                target_name = None  # bakes follow the copy
        else:
            pv["actions"].append({"op": "add", "type": "recipe", "data": data})
        for j, b in enumerate(r["bakes"], 1):
            brow = {"line": f"recipe {n}, bake {j}", "status": "add", "reason": "", "key": "",
                    "summary": ""}
            pv["rows"].append(brow)
            berrs = []
            if not isinstance(b, dict):
                brow.update(status="error", reason="bake entry isn't an object")
                continue
            try:
                d = parse_date(str(b.get("date", "")), us=job.get("us_dates", True)).isoformat()
            except ValueError as e:
                berrs.append(str(e))
                d = None
            amounts = {}
            for k, v in (b.get("amounts") or {}).items():
                x = _num(v, k, berrs, allow_none=True)
                if x is not None:
                    amounts[k] = x
            planned = {}
            for k, v in (b.get("planned") or {}).items():
                x = _num(v, f"planned {k}", berrs, allow_none=True)
                if x is not None:
                    planned[k] = x
            rating = None
            if b.get("rating") not in (None, ""):
                try:
                    rating = parse_rating(str(b.get("rating")))
                except ValueError as e:
                    berrs.append(str(e))
            bserv = _num(b.get("servings"), "servings", berrs)
            hyd = b.get("hydration")
            if berrs:
                brow.update(status="error", reason="; ".join(berrs))
                continue
            bdata = {"recipe": name, "date": d, "amounts": amounts, "servings": bserv,
                     "rating": rating, "notes": str(b.get("notes") or "")}
            if planned:
                bdata["planned"] = planned
            if isinstance(hyd, (int, float)) and not isinstance(hyd, bool):
                bdata["hydration"] = float(hyd)
            if target_name is None:
                bdata["follow_copy"] = True
            key = logic.bake_key(name, d, amounts)
            brow["key"] = logic.describe_bake_key(key)
            brow["summary"] = f"{name} · {d}"
            if key in seen and mode != "add":
                brow.update(status="skip", reason="repeated in this file")
                continue
            seen.add(key)
            dup = existing.get(key)
            if dup is not None and target_name is not None:
                if mode == "skip":
                    brow.update(status="skip", reason="already in your bake log")
                    continue
                if mode == "update":
                    brow.update(status="update", reason="will update the matching bake")
                    pv["actions"].append({"op": "update", "type": "bake", "target_id": dup,
                                          "data": bdata})
                    continue
                brow["reason"] = "duplicate, added anyway"
            pv["actions"].append({"op": "add", "type": "bake", "data": bdata})
    pv["actions"].sort(key=lambda a: 0 if a["type"] == "recipe" else 1)
    return _finish(pv)


def decode_upload(raw):
    if len(raw) > MAX_TEXT:
        raise ValueError("That file is too big (over 2 MB).")
    for enc in ("utf-8-sig", "cp1252", "latin-1"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    raise ValueError("Couldn't read the file's text.")
