"""Flask routes. Business rules live in logic.py, data in storage.py."""
import json
import math
import secrets
from datetime import date, timedelta

from flask import (Flask, Response, abort, flash, g, jsonify, redirect, render_template,
                   request, send_file, session, url_for)

from . import __version__, charts, importer, logic
from .config import Config
from .storage import (BAKE_SORTS, RECIPE_SORTS, Conflict, DataError, InvalidData, NotFound,
                      Store, parse_sort)

LOCAL_ADDRS = {"127.0.0.1", "::1", "::ffff:127.0.0.1"}
UNITS = ["g", "kg", "oz", "lb", "ml", "l", "cups", "%"]
NO_AUTH_ENDPOINTS = {"healthz", "static", "manifest"}


# -------------------------------------------------------------- form helpers

def num(raw, label, errors, key, min_value=0.0, required=False, blank=None, gt=False):
    s = (raw or "").strip()
    if s == "":
        if required:
            errors[key] = f"Enter {label.lower()}."
        return blank
    try:
        v = importer.parse_number(s)
    except ValueError:
        errors[key] = f"“{s}” isn't a number."
        return blank
    if v is None:
        return blank
    if gt and v <= min_value:
        errors[key] = f"{label} must be more than {min_value:g}."
        return blank
    if v < min_value:
        errors[key] = f"{label} can't be negative." if min_value == 0 else \
            f"{label} must be at least {min_value:g}."
        return blank
    return v


def edit_value(v):
    """Form value that round-trips exactly for normal amounts."""
    return "" if v is None else format(v, ".10g")


def parse_planned(raw):
    try:
        data = json.loads(raw or "{}")
    except ValueError:
        return {}
    if not isinstance(data, dict):
        return {}
    return {k: float(v) for k, v in data.items()
            if isinstance(k, str) and isinstance(v, (int, float)) and not isinstance(v, bool)}


def page_arg():
    try:
        return max(1, int(request.args.get("page", 1)))
    except ValueError:
        return 1


def create_app(cfg=None):
    cfg = cfg or Config.from_env()
    cfg.ensure_dirs()
    app = Flask(__name__)
    app.config.update(
        SECRET_KEY=cfg.resolve_secret_key(),
        SESSION_COOKIE_NAME="recipehelper_session",
        SESSION_COOKIE_SECURE=cfg.secure_cookies,
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        PERMANENT_SESSION_LIFETIME=timedelta(days=60),
        MAX_CONTENT_LENGTH=4 * 1024 * 1024,
        SEND_FILE_MAX_AGE_DEFAULT=86400,
    )
    store = Store(cfg)
    state = {"error": None}
    try:
        store.init()
    except DataError as e:
        state["error"] = str(e)
    app.extensions["recipehelper"] = {"cfg": cfg, "store": store, "state": state}

    # ------------------------------------------------------------ request hooks

    def current_user():
        if request.remote_addr in LOCAL_ADDRS:
            login = request.headers.get("Tailscale-User-Login", "").strip().lower()
            return login or None
        return None

    def who():
        return g.get("user") or "local"

    @app.before_request
    def guard():
        g.user = current_user()
        g.user_name = request.headers.get("Tailscale-User-Name", "") if g.user else ""
        if request.endpoint in NO_AUTH_ENDPOINTS:
            return None
        if cfg.allowed_users and (g.user or "") not in cfg.allowed_users:
            return render_template("message.html", title="Not allowed",
                                   message=(f"{g.user} isn't on this app's allowed list."
                                            if g.user else
                                            "Open this app through Tailscale (https://…ts.net) "
                                            "while signed in to an allowed account.")), 403
        if state["error"] and request.endpoint not in ("help_page",):
            return render_template("data_error.html", error=state["error"],
                                   backup_dir=cfg.backup_dir, db_path=cfg.db_path), 503
        if request.method == "POST":
            site = request.headers.get("Sec-Fetch-Site")
            if site and site not in ("same-origin", "none"):
                abort(403)
            token = session.get("csrf")
            if not token or not secrets.compare_digest(token, request.form.get("csrf_token", "")):
                return render_template("message.html", title="This form expired",
                                       message="Go back, reload the page and try again. If this keeps "
                                               "happening, cookies aren't being saved: on plain http:// "
                                               "SECURE_COOKIES must be false."), 400
        return None

    @app.after_request
    def headers(resp):
        resp.headers.setdefault(
            "Content-Security-Policy",
            "default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; "
            "font-src 'self'; connect-src 'self'; manifest-src 'self'; object-src 'none'; "
            "base-uri 'none'; frame-ancestors 'none'; form-action 'self'")
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        resp.headers.setdefault("X-Frame-Options", "DENY")
        resp.headers.setdefault("Referrer-Policy", "same-origin")
        resp.headers.setdefault("Cross-Origin-Opener-Policy", "same-origin")
        resp.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        if resp.mimetype == "text/html":
            resp.headers.setdefault("Cache-Control", "no-store")
        return resp

    # ------------------------------------------------------------ template glue

    def csrf_token():
        if "csrf" not in session:
            session["csrf"] = secrets.token_urlsafe(32)
            session.permanent = True
        return session["csrf"]

    def form_id():
        return secrets.token_urlsafe(12)

    def already_sent():
        fid = request.form.get("form_id", "")
        return bool(fid) and fid in session.get("sent_forms", [])

    def mark_sent():
        fid = request.form.get("form_id", "")
        if fid:
            sent = session.get("sent_forms", [])[-49:]
            sent.append(fid)
            session["sent_forms"] = sent

    def url_with(**changes):
        args = request.args.to_dict()
        args.update({k: v for k, v in changes.items()})
        args = {k: v for k, v in args.items() if v not in (None, "")}
        return url_for(request.endpoint, **(request.view_args or {}), **args)

    def sort_link(key, current, desc, default_desc=False):
        if key == current:
            new = key if desc else "-" + key
        else:
            new = "-" + key if default_desc else key
        return url_with(sort=new, page=None)

    @app.context_processor
    def inject():
        return {
            "version": __version__,
            "user": g.get("user"),
            "user_name": g.get("user_name"),
            "csrf_token": csrf_token,
            "form_id": form_id,
            "today": cfg.today().isoformat(),
            "yesterday": cfg.yesterday().isoformat(),
            "url_with": url_with,
            "sort_link": sort_link,
            "static_v": lambda f: url_for("static", filename=f, v=__version__),
        }

    app.jinja_env.filters["fmt"] = logic.fmt_amount
    app.jinja_env.filters["ev"] = edit_value
    app.jinja_env.filters["kb"] = lambda n: f"{n / 1024:.0f} KB" if n < 1024 * 1024 else f"{n / 1048576:.1f} MB"

    def saved(msg):
        flash(msg, "undo")

    def recipe_or_404(rid):
        r = store.recipe(rid)
        if r is None:
            abort(404)
        return r

    def bake_or_404(aid):
        a = store.attempt(aid)
        if a is None:
            abort(404)
        return a

    # ----------------------------------------------------------------- basics

    @app.get("/healthz")
    def healthz():
        if state["error"]:
            return jsonify(status="error", version=__version__, error=state["error"]), 503
        try:
            h = store.health()
        except Exception as e:  # noqa: BLE001 - report, don't crash
            return jsonify(status="error", version=__version__, error=str(e)), 503
        return jsonify(status="ok", version=__version__, recipes=h["recipes"],
                       bakes=h["bakes"], records=h["recipes"] + h["bakes"])

    @app.get("/manifest.webmanifest")
    def manifest():
        body = {
            "name": "Recipe Helper", "short_name": "Recipes", "start_url": "/",
            "scope": "/", "display": "standalone", "background_color": "#faf6f0",
            "theme_color": "#b4561f", "description": "Plan bakes and keep a bake log.",
            "icons": [
                {"src": url_for("static", filename="icon-192.png"), "sizes": "192x192", "type": "image/png"},
                {"src": url_for("static", filename="icon-512.png"), "sizes": "512x512", "type": "image/png"},
                {"src": url_for("static", filename="icon.svg"), "sizes": "any", "type": "image/svg+xml"},
            ],
        }
        return Response(json.dumps(body), mimetype="application/manifest+json")

    @app.get("/")
    def home():
        ov = store.overview()
        recipes, _ = store.recipe_list(sort="last", desc=True, per_page=8)
        return render_template("home.html", ov=ov, recipes=recipes, tab="home")

    @app.get("/help")
    def help_page():
        return render_template("help.html", tab="more")

    # ------------------------------------------------------------------ lists

    @app.get("/list")
    def list_page():
        settings = store.settings()
        view = "bakes" if request.args.get("view") == "bakes" else "recipes"
        q = request.args.get("q", "").strip()
        page = page_arg()
        if view == "recipes":
            sort, desc = parse_sort(request.args.get("sort"), RECIPE_SORTS, settings["recipes_sort"])
            rows, total = store.recipe_list(q=q, sort=sort, desc=desc, page=page,
                                            per_page=cfg.page_size)
            filters = {}
        else:
            sort, desc = parse_sort(request.args.get("sort"), BAKE_SORTS, settings["bakes_sort"])
            try:
                recipe_id = int(request.args.get("recipe") or 0) or None
            except ValueError:
                recipe_id = None
            try:
                min_rating = int(request.args.get("min_rating") or 0) or None
            except ValueError:
                min_rating = None
            dfrom = request.args.get("from") or None
            dto = request.args.get("to") or None
            dfrom = dfrom if dfrom and _iso(dfrom) else None
            dto = dto if dto and _iso(dto) else None
            unrated = request.args.get("unrated") == "1"
            rows, total = store.bake_list(q=q, recipe_id=recipe_id, min_rating=min_rating,
                                          date_from=dfrom, date_to=dto, unrated=unrated,
                                          sort=sort, desc=desc, page=page, per_page=cfg.page_size)
            filters = {"recipe": recipe_id, "min_rating": min_rating, "from": dfrom, "to": dto,
                       "unrated": unrated}
        pages = max(1, math.ceil(total / cfg.page_size))
        all_recipes = [(r["id"], r["name"]) for r in store.recipe_list(per_page=10000)[0]] \
            if view == "bakes" else []
        return render_template("list.html", view=view, rows=rows, total=total, page=page,
                               pages=pages, sort=sort, desc=desc, q=q, filters=filters,
                               all_recipes=all_recipes, tab="list")

    @app.get("/add")
    def add():
        recipes, _ = store.recipe_list(sort="last", desc=True, per_page=10000)
        return render_template("add.html", recipes=recipes, tab="add")

    # ---------------------------------------------------------------- recipes

    def recipe_form_rows():
        names = request.form.getlist("ing_name")
        amts = request.form.getlist("ing_amount")
        return list(zip(names, amts))

    def read_recipe_form(original=None):
        """-> (values, errors). values: name, servings, unit, notes, ingredients
        (per serving), rows (for re-display)."""
        f = request.form
        errors = {}
        name = f.get("name", "").strip()
        if not name:
            errors["name"] = "Give the recipe a name."
        servings = num(f.get("servings"), "Servings", errors, "servings", min_value=0,
                       required=True, gt=True)
        unit = f.get("unit", "").strip()[:12]
        notes = f.get("notes", "").strip()
        rows = recipe_form_rows()
        totals = {}
        for i, (n, a) in enumerate(rows):
            n = n.strip()
            if not n and not a.strip():
                continue
            if not n:
                errors[f"ing_{i}"] = "Add the ingredient's name."
                continue
            if n.lower() in {k.lower() for k in totals}:
                errors[f"ing_{i}"] = f"{n} is listed twice."
                continue
            v = num(a, n, errors, f"ing_{i}", required=True)
            if v is not None:
                totals[n] = v
        if not totals and not errors:
            errors["ingredients"] = "Add at least one ingredient."
        ingredients = {}
        if servings:
            orig = original or {}
            for n, total in totals.items():
                per = total / servings
                # An untouched amount keeps its exact stored value.
                if (orig.get("servings") == servings and n in orig.get("ingredients", {})
                        and edit_value(orig["ingredients"][n] * servings) == edit_value(total)):
                    per = orig["ingredients"][n]
                ingredients[n] = per
        return {"name": name, "servings": servings, "unit": unit, "notes": notes,
                "ingredients": ingredients, "rows": rows}, errors

    @app.route("/recipes/new", methods=["GET", "POST"])
    def recipe_new():
        errors, values = {}, {"name": "", "servings": "", "unit": store.settings()["default_unit"],
                              "notes": "", "rows": []}
        if request.method == "POST":
            if already_sent():
                flash("That was already saved (the form was sent twice).")
                return redirect(url_for("list_page"))
            values, errors = read_recipe_form()
            if not errors:
                try:
                    rid = store.create_recipe(values["name"], values["servings"],
                                              values["ingredients"], who(),
                                              unit=values["unit"], notes=values["notes"])
                except InvalidData as e:
                    errors["name"] = str(e)
                else:
                    mark_sent()
                    saved(f"Saved “{values['name']}”.")
                    return redirect(url_for("recipe_page", rid=rid))
        rows = values["rows"] + [("", "")] * max(0, 4 - len(values["rows"]))
        return render_template("recipe_form.html", values=values, rows=rows, errors=errors,
                               editing=None, units=UNITS, ing_names=store.ingredient_names(),
                               tab="add"), (400 if errors else 200)

    @app.route("/recipes/<int:rid>/edit", methods=["GET", "POST"])
    def recipe_edit(rid):
        r = recipe_or_404(rid)
        errors, conflict = {}, None
        values = {"name": r["name"], "servings": edit_value(r["servings"]), "unit": r["unit"],
                  "notes": r["notes"],
                  "rows": [(k, edit_value(v * r["servings"])) for k, v in r["ingredients"].items()]}
        if request.method == "POST":
            if already_sent():
                flash("That was already saved (the form was sent twice).")
                return redirect(url_for("recipe_page", rid=rid))
            values, errors = read_recipe_form(original=r)
            if not errors:
                try:
                    store.update_recipe(rid, values["name"], values["servings"],
                                        values["ingredients"], who(),
                                        expected_rev=int(request.form.get("rev", 0) or 0),
                                        force=request.form.get("force") == "1",
                                        unit=values["unit"], notes=values["notes"])
                except InvalidData as e:
                    errors["name"] = str(e)
                except Conflict as e:
                    conflict = e.current
                else:
                    mark_sent()
                    saved(f"Saved changes to “{values['name']}”.")
                    return redirect(url_for("recipe_page", rid=rid))
        rows = values["rows"] + [("", "")] * max(0, 2 - len(values["rows"]))
        return render_template("recipe_form.html", values=values, rows=rows, errors=errors,
                               editing=r, conflict=conflict, units=UNITS,
                               ing_names=store.ingredient_names(), tab="list"), \
            (409 if conflict else 400 if errors else 200)

    @app.get("/recipes/<int:rid>")
    def recipe_page(rid):
        r = recipe_or_404(rid)
        attempts = store.attempts_for_recipe(rid)
        avg, best = logic.rating_summary(attempts)
        numbered = list(enumerate(attempts, 1))[::-1]
        return render_template("recipe.html", r=r, attempts=numbered, avg=avg, best=best,
                               tab="list")

    @app.route("/recipes/<int:rid>/delete", methods=["GET", "POST"])
    def recipe_delete(rid):
        r = recipe_or_404(rid)
        if request.method == "POST":
            store.delete_recipe(rid, who())
            saved(f"Deleted “{r['name']}”.")
            return redirect(url_for("list_page"))
        return render_template("confirm.html", title=f"Delete “{r['name']}”?",
                               message=(f"This also deletes its {r['attempt_count']} logged "
                                        f"bake{'s' if r['attempt_count'] != 1 else ''}. "
                                        "You can undo it from History."
                                        if r["attempt_count"] else
                                        "You can undo it from History."),
                               action=url_for("recipe_delete", rid=rid), button="Delete recipe",
                               back=url_for("recipe_page", rid=rid), tab="list")

    @app.get("/recipes/<int:rid>/plan")
    def plan(rid):
        r = recipe_or_404(rid)
        ratios = r["ingredients"]
        args = request.args
        mode = "target" if args.get("mode") == "target" else "max"
        errors, result = {}, None
        if args.get("go"):
            use_sdd = bool(args.get("use_sdd"))
            sdd = num(args.get("sdd"), "Discard amount", errors, "sdd", required=True, blank=0) \
                if use_sdd else 0
            target = available = None
            if mode == "target":
                target = num(args.get("target"), "Servings", errors, "target", required=True,
                             min_value=0.0001)
            else:
                available = {}
                for i, ing in enumerate(ratios):
                    available[ing] = num(args.get(f"have_{i}"), ing, errors, f"have_{i}",
                                         blank=float("inf"))
            if not errors:
                servings, amounts, warnings = logic.compute_plan(
                    ratios, use_sdd, sdd, target_servings=target, available=available)
                result = {
                    "servings": servings, "amounts": amounts, "warnings": warnings,
                    "hydration": logic.hydration(amounts),
                    "limiting": logic.limiting_ingredient(ratios, available, servings)
                    if mode == "max" else None,
                    "planned": json.dumps(amounts), "target": target,
                }
        return render_template("plan.html", r=r, args=args, mode=mode, errors=errors,
                               result=result, tab="list")

    # ------------------------------------------------------------------ bakes

    def read_bake_form(order, planned, ratios, original_amounts=None):
        f = request.form
        errors = {}
        d = _iso(f.get("date", ""))
        if not d:
            errors["date"] = "Pick the date you baked."
        actual = {}
        for i, ing in enumerate(order):
            raw = f.get(f"amt_{i}", "")
            if ing in planned and raw.strip() == logic.prefill(planned[ing]):
                actual[ing] = planned[ing]   # untouched: keep the exact planned amount
                continue
            if original_amounts and ing in original_amounts and \
                    raw.strip() == edit_value(original_amounts[ing]):
                actual[ing] = original_amounts[ing]
                continue
            v = num(raw, ing, errors, f"amt_{i}")
            if v is not None:
                actual[ing] = v
        extras = list(zip(f.getlist("extra_name"), f.getlist("extra_amount")))
        for i, (n, a) in enumerate(extras):
            n = n.strip()
            if not n and not a.strip():
                continue
            if not n:
                errors[f"extra_{i}"] = "Add the ingredient's name."
                continue
            if n in actual:
                errors[f"extra_{i}"] = f"{n} is already listed above."
                continue
            v = num(a, n, errors, f"extra_{i}", required=True)
            if v is not None:
                actual[n] = v
        servings = num(f.get("servings"), "Servings made", errors, "servings")
        rating = f.get("rating", "")
        rating = int(rating) if rating in ("1", "2", "3", "4", "5") else None
        notes = f.get("notes", "").strip()
        if not actual and not errors:
            errors["amounts"] = "Enter at least one amount you used."
        return {"date": d, "amounts": actual, "servings": servings, "rating": rating,
                "notes": notes}, errors, extras

    def bake_fields(order, planned, ratios, values):
        return [{"i": i, "name": ing, "value": values[i], "planned": planned.get(ing),
                 "label": "Sourdough discard (sdd)" if ing == "sdd" and ing not in ratios else ing}
                for i, ing in enumerate(order)]

    @app.route("/bakes/new", methods=["GET", "POST"])
    def bake_new():
        src = request.form if request.method == "POST" else request.args
        try:
            rid = int(src.get("recipe") or 0)
        except ValueError:
            rid = 0
        if not rid:
            return redirect(url_for("add"))
        r = recipe_or_404(rid)
        ratios = r["ingredients"]
        planned = parse_planned(src.get("planned"))
        order = list(ratios) + [k for k in planned if k not in ratios]
        errors, extras = {}, []
        if request.method == "POST":
            if already_sent():
                flash("That bake was already saved (the form was sent twice).")
                return redirect(url_for("recipe_page", rid=rid))
            a, errors, extras = read_bake_form(order, planned, ratios)
            if not errors:
                if planned:
                    a["planned"] = planned
                aid = store.create_attempt(rid, a, who())
                mark_sent()
                saved("Bake logged.")
                return redirect(url_for("bake_page", aid=aid))
            values = [request.form.get(f"amt_{i}", "") for i in range(len(order))]
        else:
            values = [logic.prefill(planned[ing]) if ing in planned else "" for ing in order]
        while len(extras) < 2:
            extras.append(("", ""))
        return render_template("bake_form.html", r=r, fields=bake_fields(order, planned, ratios, values),
                               extras=extras, errors=errors, form=request.form, editing=None,
                               planned_json=json.dumps(planned) if planned else "",
                               ing_names=store.ingredient_names(), tab="add"), \
            (400 if errors else 200)

    @app.route("/bakes/<int:aid>/edit", methods=["GET", "POST"])
    def bake_edit(aid):
        a = bake_or_404(aid)
        r = recipe_or_404(a["recipe_id"])
        ratios = r["ingredients"]
        planned = a.get("planned") or {}
        order = list(ratios) + [k for k in planned if k not in ratios]
        errors, conflict = {}, None
        if request.method == "POST":
            if already_sent():
                flash("That was already saved (the form was sent twice).")
                return redirect(url_for("bake_page", aid=aid))
            vals, errors, extras = read_bake_form(order, {}, ratios, original_amounts=a["amounts"])
            if not errors:
                try:
                    store.update_attempt(aid, vals, who(),
                                         expected_rev=int(request.form.get("rev", 0) or 0),
                                         force=request.form.get("force") == "1")
                except Conflict as e:
                    conflict = e.current
                else:
                    mark_sent()
                    saved("Saved changes to the bake.")
                    return redirect(url_for("bake_page", aid=aid))
            values = [request.form.get(f"amt_{i}", "") for i in range(len(order))]
            form = request.form
        else:
            values = [edit_value(a["amounts"].get(ing)) for ing in order]
            extras = [(k, edit_value(v)) for k, v in a["amounts"].items() if k not in order]
            form = {"date": a["date"], "rating": str(a["rating"] or ""),
                    "servings": edit_value(a["servings"]), "notes": a["notes"]}
        while len(extras) < 1:
            extras.append(("", ""))
        return render_template("bake_form.html", r=r, fields=bake_fields(order, planned, ratios, values),
                               extras=extras, errors=errors, form=form, editing=a,
                               conflict=conflict, planned_json="",
                               ing_names=store.ingredient_names(), tab="list"), \
            (409 if conflict else 400 if errors else 200)

    @app.get("/bakes/<int:aid>")
    def bake_page(aid):
        a = bake_or_404(aid)
        r = recipe_or_404(a["recipe_id"])
        idx = store.attempt_position(r["id"], a["date"], aid)
        label, rows, skipped = logic.compare_attempt(a, r["ingredients"])
        return render_template("bake.html", r=r, a=a, idx=idx, label=label, rows=rows,
                               skipped=skipped, total=r["attempt_count"], tab="list")

    @app.route("/bakes/<int:aid>/delete", methods=["GET", "POST"])
    def bake_delete(aid):
        a = bake_or_404(aid)
        r = recipe_or_404(a["recipe_id"])
        if request.method == "POST":
            store.delete_attempt(aid, who())
            saved(f"Deleted the bake from {a['date']}.")
            return redirect(url_for("recipe_page", rid=r["id"]))
        return render_template("confirm.html", title="Delete this bake?",
                               message=f"{r['name']}, baked {a['date']}. You can undo it from History.",
                               action=url_for("bake_delete", aid=aid), button="Delete bake",
                               back=url_for("bake_page", aid=aid), tab="list")

    # ---------------------------------------------------------------- reports

    @app.get("/reports")
    def reports():
        try:
            rid = int(request.args.get("recipe") or 0) or None
        except ValueError:
            rid = None
        rows = store.recipe_report()
        cols = {"name": lambda x: x["name"].lower(), "bakes": lambda x: x["n_bakes"],
                "rating": lambda x: x["avg_rating"], "best": lambda x: x["best_rating"],
                "hydration": lambda x: x["avg_hydration"], "last": lambda x: x["last_baked"]}
        sort, desc = parse_sort(request.args.get("sort"), cols, "name")
        present = [x for x in rows if cols[sort](x) is not None]
        missing = [x for x in rows if cols[sort](x) is None]
        present.sort(key=cols[sort], reverse=desc)
        rows = present + missing
        points = store.chart_points(rid)
        return render_template("reports.html", rows=rows, sort=sort, desc=desc, rid=rid,
                               recipes=[(x["id"], x["name"]) for x in store.recipe_report()],
                               points=points,
                               chart_time=charts.rating_over_time(points),
                               chart_scatter=charts.hydration_vs_rating(points), tab="reports")

    # ------------------------------------------------------------ more/settings

    @app.get("/more")
    def more():
        return render_template("more.html", tab="more", undo=store.last_undoable())

    @app.route("/settings", methods=["GET", "POST"])
    def settings_page():
        settings = store.settings()
        if request.method == "POST":
            new = {}
            rs = request.form.get("recipes_sort", "")
            bs = request.form.get("bakes_sort", "")
            if rs.lstrip("-") in RECIPE_SORTS:
                new["recipes_sort"] = rs
            if bs.lstrip("-") in BAKE_SORTS:
                new["bakes_sort"] = bs
            unit = request.form.get("default_unit", "").strip()[:12]
            new["default_unit"] = unit or "g"
            store.set_settings(new, who())
            saved("Settings saved.")
            return redirect(url_for("settings_page"))
        return render_template("settings.html", settings=settings, backups=store.list_backups(),
                               cfg=cfg, units=UNITS, tab="more")

    @app.post("/backups/new")
    def backup_new():
        name = store.backup("manual")
        flash(f"Backup made: {name}")
        return redirect(url_for("settings_page") + "#backups")

    @app.get("/backups/<name>")
    def backup_download(name):
        try:
            path = store.backup_path(name)
        except NotFound:
            abort(404)
        return send_file(path, as_attachment=True, download_name=name,
                         mimetype="application/vnd.sqlite3", max_age=0)

    @app.route("/backups/<name>/restore", methods=["GET", "POST"])
    def backup_restore(name):
        try:
            store.backup_path(name)
        except NotFound:
            abort(404)
        if request.method == "POST":
            try:
                safety = store.restore(name, who())
            except InvalidData as e:
                flash(str(e))
                return redirect(url_for("settings_page") + "#backups")
            saved(f"Restored {name}. Your data from just before is saved as {safety}.")
            return redirect(url_for("home"))
        return render_template("confirm.html", title="Restore this backup?",
                               message=(f"Your recipes and bakes will go back to {name}. "
                                        "The current data is backed up first, so you can undo this."),
                               action=url_for("backup_restore", name=name), button="Restore",
                               back=url_for("settings_page"), tab="more")

    def _download(body, filename, mimetype):
        resp = Response(body, mimetype=mimetype)
        resp.headers["Content-Disposition"] = f'attachment; filename="{filename}"'
        return resp

    @app.get("/export/recipehelper.json")
    def export_json():
        return _download(json.dumps(store.export_data(), indent=2, ensure_ascii=False),
                         f"recipehelper-{cfg.today().isoformat()}.json", "application/json")

    @app.get("/export/bakes.csv")
    def export_bakes():
        return _download("﻿" + store.export_bakes_csv(),
                         f"recipehelper-bakes-{cfg.today().isoformat()}.csv", "text/csv")

    @app.get("/export/recipes.csv")
    def export_recipes():
        return _download("﻿" + store.export_recipes_csv(),
                         f"recipehelper-recipes-{cfg.today().isoformat()}.csv", "text/csv")

    # ---------------------------------------------------------------- history

    @app.get("/history")
    def history():
        return render_template("history.html", changes=store.history(200),
                               undo=store.last_undoable(), tab="more")

    @app.post("/history/undo")
    def undo():
        if already_sent():
            flash("That undo was already done.")
            return redirect(url_for("history"))
        try:
            ch = store.undo_last(who())
        except NotFound:
            flash("There's nothing to undo.")
        except InvalidData as e:
            flash(str(e))
        else:
            mark_sent()
            flash(f"Undone: {ch['summary']}")
        return redirect(request.form.get("next") or url_for("history"))

    # ----------------------------------------------------------------- import

    @app.route("/import", methods=["GET", "POST"])
    def import_start():
        errors = {}
        if request.method == "POST":
            how = request.form.get("how", "paste")
            kind = request.form.get("kind", "auto")
            if kind not in ("auto", "bakes", "recipes"):
                kind = "auto"
            try:
                if how == "paste":
                    text = request.form.get("text", "")
                    if not text.strip():
                        raise ValueError("Paste a table first, including its header row.")
                    if len(text) > importer.MAX_TEXT:
                        raise ValueError("That's too much text (over 2 MB).")
                    job = importer.new_job(cfg, kind, "pasted table", text=text, us_dates=cfg.us_dates)
                else:
                    up = request.files.get("file")
                    if up is None or not up.filename:
                        raise ValueError("Choose a file first.")
                    raw = up.read()
                    text = importer.decode_upload(raw)
                    fname = up.filename.rsplit("/", 1)[-1][:80]
                    if how == "json" or fname.lower().endswith(".json") or text.lstrip().startswith(("{", "[")):
                        job = importer.new_job(cfg, "json", fname, data=text, us_dates=cfg.us_dates)
                    else:
                        job = importer.new_job(cfg, kind, fname, text=text, us_dates=cfg.us_dates)
            except ValueError as e:
                errors["import"] = str(e)
            else:
                return redirect(url_for("import_preview", token=job["token"]))
        return render_template("import.html", errors=errors, form=request.form, tab="more"), \
            (400 if errors else 200)

    @app.route("/import/<token>", methods=["GET", "POST"])
    def import_preview(token):
        try:
            job = importer.load_job(cfg, token)
        except KeyError:
            flash("That import has expired or was already done. Start again.")
            return redirect(url_for("import_start"))
        if request.method == "POST":
            f = request.form
            if f.get("mode") in ("skip", "update", "add"):
                job["mode"] = f["mode"]
            if f.get("dates") in ("us", "eu"):
                job["us_dates"] = f["dates"] == "us"
            if f.get("kind") in ("bakes", "recipes") and job["kind"] != "json":
                if f["kind"] != job["kind"]:
                    job["mapping"] = None
                    job["kind"] = f["kind"]
                else:
                    maps = [f.get(f"map_{i}", "ignore") for i in range(int(f.get("ncols", 0) or 0))]
                    if maps:
                        job["mapping"] = maps
            job["default_recipe"] = f.get("default_recipe", "")
            importer.save_job(cfg, job)
            if f.get("action") == "cancel":
                importer.drop_job(cfg, token)
                flash("Import cancelled. Nothing was changed.")
                return redirect(url_for("import_start"))
            if f.get("action") == "confirm":
                if already_sent():
                    flash("That import was already done.")
                    return redirect(url_for("history"))
                pv = importer.build_preview(store, job)
                if not pv["can_import"]:
                    flash("Nothing to import yet: fix the problems shown below.")
                    return redirect(url_for("import_preview", token=token))
                counts, safety = store.apply_import(pv["actions"], who(), job["source"])
                importer.drop_job(cfg, token)
                mark_sent()
                done = ", ".join(f"{v} {k}" for k, v in counts.items() if v) or "nothing changed"
                saved(f"Imported: {done}. A backup from just before is saved as {safety}.")
                return redirect(url_for("history"))
            return redirect(url_for("import_preview", token=token))
        if job["kind"] == "auto":
            _, headers, _ = importer.read_table(job["text"] or "")
            job["kind"] = importer.guess_kind(headers)
            importer.save_job(cfg, job)
        pv = importer.build_preview(store, job)
        return render_template("import_preview.html", job=job, pv=pv,
                               recipe_names=store.recipe_names(), tab="more")

    # ----------------------------------------------------------------- errors

    @app.errorhandler(404)
    def not_found(e):
        return render_template("message.html", title="Not found",
                               message="That page doesn't exist (or was deleted)."), 404

    @app.errorhandler(403)
    def forbidden(e):
        return render_template("message.html", title="Blocked",
                               message="That request came from another website, so it was refused."), 403

    @app.errorhandler(413)
    def too_big(e):
        return render_template("message.html", title="Too big",
                               message="That upload is over 4 MB."), 413

    return app


def _iso(s):
    try:
        return date.fromisoformat((s or "").strip()).isoformat()
    except ValueError:
        return None
