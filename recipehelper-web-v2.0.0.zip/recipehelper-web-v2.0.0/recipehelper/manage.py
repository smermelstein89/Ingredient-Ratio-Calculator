"""Admin commands, used by the installer and update script.

    python -m recipehelper.manage version
    python -m recipehelper.manage check            # create/upgrade the data file, print counts
    python -m recipehelper.manage backup [reason]  # make a backup, print its file name
    python -m recipehelper.manage import FILE [--mode skip|update|add]

Settings come from the same environment as the web app (DATA_DIR, ...).
"""
import argparse
import json
import sys

from . import __version__, importer
from .config import Config
from .storage import DataError, Store


def import_file(store, path, mode="skip", who="admin", quiet=False):
    """Import a JSON or CSV/TSV file without the preview screen. Rows with
    problems are reported and left out. Returns the counts."""
    with open(path, "rb") as f:
        text = importer.decode_upload(f.read())
    if path.lower().endswith(".json") or text.lstrip().startswith(("{", "[")):
        job = {"kind": "json", "data": text, "text": None, "mode": mode, "us_dates": True,
               "mapping": None, "default_recipe": ""}
    else:
        _, headers, _ = importer.read_table(text)
        job = {"kind": importer.guess_kind(headers), "text": text, "data": None, "mode": mode,
               "us_dates": store.cfg.us_dates, "mapping": None, "default_recipe": ""}
    pv = importer.build_preview(store, job)
    if pv["errors"]:
        raise ValueError("; ".join(pv["errors"]))
    if not quiet:
        for r in pv["rows"]:
            if r["status"] == "error":
                print(f"  skipped {r['line']}: {r['reason']}", file=sys.stderr)
    if not pv["actions"]:
        return {"recipes added": 0, "recipes updated": 0, "bakes added": 0, "bakes updated": 0}
    counts, _ = store.apply_import(pv["actions"], who, path.rsplit("/", 1)[-1])
    return counts


def main(argv=None):
    p = argparse.ArgumentParser(description="Recipe Helper admin commands.")
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("version")
    sub.add_parser("check")
    b = sub.add_parser("backup")
    b.add_argument("reason", nargs="?", default="manual")
    i = sub.add_parser("import")
    i.add_argument("file")
    i.add_argument("--mode", choices=["skip", "update", "add"], default="skip")
    args = p.parse_args(argv)

    if args.cmd == "version":
        print(__version__)
        return 0
    cfg = Config.from_env()
    store = Store(cfg)
    try:
        store.init()
    except DataError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1
    if args.cmd == "check":
        print(json.dumps({"status": "ok", "version": __version__, "db": cfg.db_path,
                          **store.health()}))
    elif args.cmd == "backup":
        print(store.backup(args.reason))
    elif args.cmd == "import":
        try:
            counts = import_file(store, args.file, args.mode)
        except (OSError, ValueError) as e:
            print(f"ERROR: {e}", file=sys.stderr)
            return 1
        print(", ".join(f"{v} {k}" for k, v in counts.items()))
    return 0


if __name__ == "__main__":
    sys.exit(main())
