// Small conveniences only. Every page works without this file.
(function () {
  document.documentElement.classList.add("js");

  // Confirm before destructive buttons: <button data-confirm="...">.
  document.addEventListener("submit", function (e) {
    var form = e.target;
    var btn = e.submitter || form.querySelector("[type=submit]");
    var msg = (btn && btn.getAttribute("data-confirm")) || form.getAttribute("data-confirm");
    if (msg && !window.confirm(msg)) { e.preventDefault(); return; }
    // Block double-submits: disable the button for a few seconds.
    if (form.method && form.method.toLowerCase() === "post" && btn) {
      if (form.dataset.sending === "1") { e.preventDefault(); return; }
      form.dataset.sending = "1";
      setTimeout(function () { btn.disabled = true; }, 0);
      setTimeout(function () { form.dataset.sending = ""; btn.disabled = false; }, 8000);
    }
  });

  document.addEventListener("click", function (e) {
    var t = e.target.closest("[data-set-date]");
    if (t) {
      var input = document.getElementById(t.getAttribute("data-target"));
      if (input) { input.value = t.getAttribute("data-set-date"); input.dispatchEvent(new Event("change")); }
      return;
    }
    var add = e.target.closest("[data-add-row]");
    if (add) {
      var list = document.getElementById(add.getAttribute("data-add-row"));
      var tpl = document.getElementById(add.getAttribute("data-add-row") + "-tpl");
      if (list && tpl) {
        list.appendChild(tpl.content.cloneNode(true));
        var inputs = list.lastElementChild.querySelectorAll("input");
        if (inputs.length) inputs[0].focus();
      }
      return;
    }
    var rm = e.target.closest("[data-remove-row]");
    if (rm) {
      var row = rm.closest(".ing-row"), parent = row.parentNode;
      if (parent.children.length > 1) row.remove();
      else row.querySelectorAll("input").forEach(function (i) { i.value = ""; });
      return;
    }
    // Whole table rows open their record (the first link in the row).
    var tr = e.target.closest("tr.rowlink");
    if (tr && !e.target.closest("a, button, input, select")) {
      var a = tr.querySelector("a[href]");
      if (a) window.location = a.href;
    }
  });

  // Selects that apply immediately (sort dropdowns).
  document.addEventListener("change", function (e) {
    if (e.target.matches("select[data-autosubmit]")) e.target.form.submit();
  });

  // Plan page: show only the fields for the chosen mode.
  var plan = document.getElementById("planform");
  if (plan) {
    var sync = function () {
      var target = document.getElementById("m-target").checked;
      document.getElementById("sec-target").hidden = !target;
      document.getElementById("sec-max").hidden = target;
      document.getElementById("sec-sdd").hidden = !document.getElementById("use_sdd").checked;
    };
    plan.addEventListener("change", sync);
    sync();
    var res = document.getElementById("result");
    if (res && window.innerWidth < 760) res.scrollIntoView({ block: "start" });
  }

  // Live total on the recipe form: the batch weight as you type.
  var total = document.getElementById("batch-total");
  if (total) {
    var calc = function () {
      var sum = 0;
      document.querySelectorAll("input[name=ing_amount]").forEach(function (i) {
        var v = parseFloat((i.value || "").replace(",", "."));
        if (!isNaN(v)) sum += v;
      });
      total.textContent = sum ? (Math.round(sum * 100) / 100).toString() : "–";
    };
    document.addEventListener("input", function (e) { if (e.target.name === "ing_amount") calc(); });
    calc();
  }
})();
