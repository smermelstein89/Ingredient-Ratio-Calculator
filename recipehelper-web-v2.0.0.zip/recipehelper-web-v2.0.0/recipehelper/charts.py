"""Charts drawn on the server as inline SVG. No JavaScript, nothing from a
CDN. Colours come from CSS classes (see static/app.css) so light and dark mode
both work. Each chart has one series, so its title names it (no legend), and
the page also offers the same data as a table.
"""
from datetime import date
from html import escape


W, H = 360, 230
PAD_L, PAD_R, PAD_T, PAD_B = 34, 14, 14, 40


def _svg_open(label, desc):
    return (f'<svg class="chart" viewBox="0 0 {W} {H}" role="img" '
            f'aria-label="{escape(label)}" preserveAspectRatio="xMidYMid meet">'
            f"<title>{escape(label)}</title><desc>{escape(desc)}</desc>")


def _empty(label, msg):
    return (_svg_open(label, msg)
            + f'<text class="chart-empty" x="{W / 2}" y="{H / 2}" text-anchor="middle">{escape(msg)}</text>'
            + "</svg>")


def _short(d):
    return d.strftime("%b %-d") if hasattr(d, "strftime") else str(d)


def rating_over_time(points):
    """points: dicts with baked_on (ISO), rating (1-5 or None), recipe."""
    label = "Rating over time"
    pts = [(date.fromisoformat(p["baked_on"]), p["rating"], p["recipe"])
           for p in points if p.get("rating")]
    if not pts:
        return _empty(label, "No rated bakes yet")
    d0, d1 = pts[0][0], pts[-1][0]
    span = max(1, (d1 - d0).days)
    pw, ph = W - PAD_L - PAD_R, H - PAD_T - PAD_B

    def x(d):
        return PAD_L + (pw * (d - d0).days / span if d1 != d0 else pw / 2)

    def y(r):
        return PAD_T + ph * (5 - r) / 4

    out = [_svg_open(label, f"{len(pts)} rated bakes from {d0} to {d1}, rating 1 to 5")]
    for r in range(1, 6):
        out.append(f'<line class="grid" x1="{PAD_L}" x2="{W - PAD_R}" y1="{y(r):.1f}" y2="{y(r):.1f}"/>')
        out.append(f'<text class="tick" x="{PAD_L - 8}" y="{y(r) + 4:.1f}" text-anchor="end">{r}★</text>')
    out.append(f'<line class="axis" x1="{PAD_L}" x2="{W - PAD_R}" y1="{H - PAD_B}" y2="{H - PAD_B}"/>')
    labels = [(d0, "start")] if d0 == d1 else [(d0, "start"), (d1, "end")]
    if span > 60 and d0 != d1:
        mid = d0 + (d1 - d0) / 2
        labels.insert(1, (mid, "middle"))
    for d, anchor in labels:
        out.append(f'<text class="tick" x="{x(d):.1f}" y="{H - PAD_B + 18}" text-anchor="{anchor}">'
                   f'{escape(_short(d))}{" " + str(d.year) if anchor != "middle" else ""}</text>')
    if len(pts) > 1:
        path = " ".join(f"{'M' if i == 0 else 'L'}{x(d):.1f},{y(r):.1f}" for i, (d, r, _) in enumerate(pts))
        out.append(f'<path class="series-line" d="{path}"/>')
    for d, r, name in pts:
        tip = f"{name} · {d.isoformat()} · {r}★"
        out.append(f'<g class="pt"><title>{escape(tip)}</title>'
                   f'<circle class="hit" cx="{x(d):.1f}" cy="{y(r):.1f}" r="11"/>'
                   f'<circle class="series-dot" cx="{x(d):.1f}" cy="{y(r):.1f}" r="4.5"/></g>')
    out.append("</svg>")
    return "".join(out)


def hydration_vs_rating(points):
    """Scatter: hydration % (x) against rating (y)."""
    label = "Hydration vs rating"
    pts = [(p["hydration"], p["rating"], p["recipe"], p["baked_on"]) for p in points
           if p.get("rating") and p.get("hydration") is not None]
    if not pts:
        return _empty(label, "Needs bakes with both a rating and hydration")
    h0 = min(p[0] for p in pts)
    h1 = max(p[0] for p in pts)
    lo = int(h0 // 5 * 5)
    hi = int(-(-h1 // 5) * 5)
    if hi - lo < 10:
        lo, hi = lo - 5, hi + 5
    pw, ph = W - PAD_L - PAD_R, H - PAD_T - PAD_B

    def x(h):
        return PAD_L + pw * (h - lo) / (hi - lo)

    def y(r):
        return PAD_T + ph * (5 - r) / 4

    out = [_svg_open(label, f"{len(pts)} bakes; hydration {h0:.1f}% to {h1:.1f}% against rating")]
    for r in range(1, 6):
        out.append(f'<line class="grid" x1="{PAD_L}" x2="{W - PAD_R}" y1="{y(r):.1f}" y2="{y(r):.1f}"/>')
        out.append(f'<text class="tick" x="{PAD_L - 8}" y="{y(r) + 4:.1f}" text-anchor="end">{r}★</text>')
    out.append(f'<line class="axis" x1="{PAD_L}" x2="{W - PAD_R}" y1="{H - PAD_B}" y2="{H - PAD_B}"/>')
    step = 5 if hi - lo <= 30 else 10
    for t in range(lo, hi + 1, step):
        out.append(f'<text class="tick" x="{x(t):.1f}" y="{H - PAD_B + 18}" text-anchor="middle">{t}%</text>')
    out.append(f'<text class="axis-title" x="{PAD_L + pw / 2:.1f}" y="{H - 4}" text-anchor="middle">Hydration</text>')
    # Same hydration and rating stack up: nudge repeats sideways so each shows.
    seen = {}
    for h, r, name, d in pts:
        k = (round(h, 1), r)
        n = seen.get(k, 0)
        seen[k] = n + 1
        cx = x(h) + (n * 6 if n % 2 else -n * 6) / 2
        tip = f"{name} · {d} · {h:.1f}% · {r}★"
        out.append(f'<g class="pt"><title>{escape(tip)}</title>'
                   f'<circle class="hit" cx="{cx:.1f}" cy="{y(r):.1f}" r="11"/>'
                   f'<circle class="series-dot ringed" cx="{cx:.1f}" cy="{y(r):.1f}" r="4.5"/></g>')
    out.append("</svg>")
    return "".join(out)
