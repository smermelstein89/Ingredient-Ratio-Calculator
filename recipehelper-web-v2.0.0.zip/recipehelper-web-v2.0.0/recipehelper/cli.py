"""The original terminal menu (releases 1-1/1-2), unchanged for the person
using it, now running on the shared storage layer, so terminal and web
changes appear in the same history and backups.

    python -m recipehelper.cli [--db /path/recipes.db]
On the server: recipehelper-cli
"""
import argparse
import os
import string
import sys
from datetime import date

from . import __version__, logic
from .config import Config
from .storage import DataError, Store

WHO = "terminal"


def get_float(prompt, allow_blank=False, blank_value=None, min_value=0):
    while True:
        s = input(prompt).strip()
        if allow_blank and s == "":
            return blank_value
        try:
            v = float(s)
            if v < min_value:
                print("Value too small.")
                continue
            return v
        except ValueError:
            print("Invalid number, try again.")


def get_date():
    today = date.today().isoformat()
    while True:
        s = input(f"Date [{today}]: ").strip() or today
        try:
            return date.fromisoformat(s).isoformat()
        except ValueError:
            print("Use the format YYYY-MM-DD.")


def get_rating():
    while True:
        s = input("Rating 1-5 (ENTER = skip): ").strip()
        if not s:
            return None
        if s in ("1", "2", "3", "4", "5"):
            return int(s)
        print("Enter a number from 1 to 5.")


def print_recipe(name, recipe):
    print(f"\n=== {name} ===")
    print(f"Base servings: {recipe['servings']:g}")
    for ing, amt in recipe["ingredients"].items():
        print(f"  - {ing}: {amt:.4g} per serving")
    if recipe.get("attempt_count"):
        print(f"Logged attempts: {recipe['attempt_count']}")
    print()


def recipe_menu(names):
    print("\nRecipes:")
    if not names:
        print("  (none)")
        return {}
    mapping = {}
    for l, name in zip(string.ascii_uppercase, names):
        print(f"  {l}) {name}")
        mapping[l] = name
    return mapping


def create_recipe(store):
    name = input("Recipe name: ").strip()
    if not name or store.find_recipe_id(name):
        print("Invalid or duplicate name.")
        return

    servings = get_float("Servings: ", min_value=0.0001)
    ingredients = {}

    print("Add ingredients (ENTER to finish)")
    while True:
        ing = input("Ingredient name: ").strip()
        if not ing:
            break
        if ing in ingredients:
            print("Already added.")
            continue
        amt = get_float(f"Total amount of {ing}: ")
        ingredients[ing] = amt / servings

    store.create_recipe(name, servings, ingredients, WHO,
                        unit=store.settings()["default_unit"])
    print("Saved.")
    print_recipe(name, store.recipe_by_name(name))


def print_attempt(idx, attempt, ratios):
    print(f"\n--- Attempt #{idx} ({attempt['date']}) ---")
    if attempt.get("servings"):
        print(f"Servings made: {attempt['servings']:.4g}")
    r = attempt.get("rating")
    if r:
        print(f"Rating: {'*' * r}{'.' * (5 - r)} ({r}/5)")

    label, rows, skipped = logic.compare_attempt(attempt, ratios)
    print("Actual amounts" + (f" (vs {label})" if label else "") + ":")
    for row in rows:
        line = f"  - {row['name']}: {row['actual']:.4g}"
        if row["diff"] is not None:
            line += f"  ({row['diff']:+.4g}, {row['pct']:+.1f}%)"
        elif row["extra"]:
            line += "  (extra)"
        print(line)
    if skipped:
        print("  Not used: " + ", ".join(skipped))

    if attempt.get("hydration") is not None:
        print(f"Hydration: {attempt['hydration']:.1f}%")
    if attempt.get("notes"):
        print(f"Notes: {attempt['notes']}")
    print()


def log_attempt(store, name, planned=None):
    recipe = store.recipe_by_name(name)
    ratios = recipe["ingredients"]
    planned = planned or {}

    print(f"\nLogging bake attempt for {name}")
    d = get_date()

    if planned:
        print("Enter actual amounts used (ENTER = planned amount, 0 = not used)")
    else:
        print("Enter actual amounts used (ENTER = skip)")

    actual = {}
    order = list(ratios.keys()) + [k for k in planned if k not in ratios]
    for ing in order:
        if ing in planned:
            v = get_float(f"  {ing} [{planned[ing]:.4g}]: ",
                          allow_blank=True, blank_value=planned[ing])
        else:
            v = get_float(f"  {ing}: ", allow_blank=True, blank_value=None)
        if v is not None:
            actual[ing] = v

    print("Extra ingredients not in the recipe (ENTER to finish)")
    while True:
        ing = input("  Ingredient name: ").strip()
        if not ing:
            break
        if ing in actual:
            print("  Already logged.")
            continue
        actual[ing] = get_float(f"  Amount of {ing}: ")

    servings = get_float("Servings actually made (ENTER = skip): ",
                         allow_blank=True, blank_value=None)
    rating = get_rating()
    notes = input("Notes (crumb, rise, bake time, oven temp...): ").strip()

    attempt = {
        "date": d,
        "amounts": actual,
        "servings": servings,
        "rating": rating,
        "notes": notes,
    }
    if planned:
        attempt["planned"] = planned
    h = logic.hydration(actual)
    if h is not None:
        attempt["hydration"] = round(h, 1)
    else:
        attempt["hydration"] = None

    aid = store.create_attempt(recipe["id"], attempt, WHO)
    if attempt["hydration"] is None:
        del attempt["hydration"]

    print("Attempt logged.")
    print_attempt(store.attempt_position(recipe["id"], d, aid), attempt, ratios)


def view_attempts(store, name):
    recipe = store.recipe_by_name(name)
    attempts = store.attempts_for_recipe(recipe["id"])
    if not attempts:
        print(f"\nNo attempts logged for {name}.")
        return

    avg, best = logic.rating_summary(attempts)
    while True:
        print(f"\nAttempts for {name}:")
        for i, a in enumerate(attempts, 1):
            r = f"{a['rating']}/5" if a.get("rating") else "-"
            h = f"{a['hydration']:.1f}%" if a.get("hydration") is not None else "-"
            note = (a.get("notes") or "")[:40]
            print(f"  {i:>2}) {a['date']}  rating {r:<4} hydration {h:<7} {note}")

        if avg is not None:
            print(f"Average rating: {avg:.1f}/5 (best: #{best})")

        s = input("Attempt number to view (ENTER = back): ").strip()
        if not s:
            return
        if s.isdigit() and 1 <= int(s) <= len(attempts):
            print_attempt(int(s), attempts[int(s) - 1], recipe["ingredients"])
        else:
            print("Invalid.")


def offer_log(store, name, amounts):
    if input("\nLog a bake attempt using these amounts? [y/N]: ").strip().lower() == "y":
        log_attempt(store, name, dict(amounts))


def optimize_recipe(store, name):
    recipe = store.recipe_by_name(name)
    ratios = recipe["ingredients"]

    print_recipe(name, recipe)

    print("1) Maximize")
    print("2) Target servings")
    mode = input("Choose [1]: ").strip() or "1"

    use_sdd = input("Use SDD? [y/N]: ").strip().lower() == "y"
    sdd = get_float("SDD amount: ", min_value=0) if use_sdd else 0

    if mode == "2":
        target = get_float("Target servings: ", min_value=0.0001)
        _, amounts, warnings = logic.compute_plan(ratios, use_sdd, sdd, target_servings=target)

        print("Amounts:")
        for k, v in amounts.items():
            print(f"  - {k}: {v:.4g}")
        h = logic.hydration(amounts)
        if h:
            print(f"Hydration: {h:.1f}%")
        for w in warnings:
            print("Warning:", w)
        offer_log(store, name, amounts)
        return

    available = {}
    for ing in ratios:
        available[ing] = get_float(
            f"{ing} you have (ENTER = inf): ",
            allow_blank=True,
            blank_value=float("inf"),
        )

    servings, amounts, warnings = logic.compute_plan(ratios, use_sdd, sdd, available=available)

    print("\nResult:")
    print(f"Servings: {servings:.4g}")
    print("Amounts:")
    for k, v in amounts.items():
        print(f"  - {k}: {v:.4g}")
    h = logic.hydration(amounts)
    if h:
        print(f"Hydration: {h:.1f}%")
    for w in warnings:
        print("Warning:", w)
    offer_log(store, name, amounts)


def pick_recipe(m):
    if not m:
        print("No recipes.")
        return None
    r = input("Recipe letter: ").strip().upper()
    if r in m:
        return m[r]
    print("Invalid.")
    return None


def menu(store):
    while True:
        m = recipe_menu(store.recipe_names())
        print("\n1) Create recipe\n2) Optimize recipe\n3) Log bake attempt"
              "\n4) View bake attempts\n5) Exit")
        c = input("Choose: ").strip().upper()
        if c in m:
            print_recipe(m[c], store.recipe_by_name(m[c]))
        elif c == "1":
            create_recipe(store)
        elif c == "2":
            name = pick_recipe(m)
            if name:
                optimize_recipe(store, name)
        elif c == "3":
            name = pick_recipe(m)
            if name:
                log_attempt(store, name)
        elif c == "4":
            name = pick_recipe(m)
            if name:
                view_attempts(store, name)
        elif c == "5":
            break
        else:
            print("Invalid.")


def config_for(db_path):
    cfg = Config.from_env()
    if db_path:
        cfg.data_dir = os.path.dirname(os.path.abspath(db_path))
        cfg.db_name = os.path.basename(db_path)
    return cfg


def open_store(cfg):
    """Open (and create/upgrade) the database. On a brand-new database, an
    old recipes.json next to it is imported, as the original script did."""
    from .manage import import_file
    is_new = not os.path.exists(cfg.db_path)
    store = Store(cfg)
    store.init()
    legacy = os.path.join(cfg.data_dir, "recipes.json")
    if is_new and os.path.exists(legacy):
        counts = import_file(store, legacy, who=WHO, quiet=True)
        print(f"Imported {counts['recipes added']} recipe(s) and {counts['bakes added']} "
              f"attempt(s) from {legacy} into {cfg.db_path}.")
    return store


def main(argv=None):
    p = argparse.ArgumentParser(description="Recipe Helper terminal menu.")
    p.add_argument("--db", help="SQLite database file (default: $DATA_DIR/recipes.db)")
    p.add_argument("--version", action="version", version=f"Recipe Helper {__version__}")
    args = p.parse_args(argv)
    try:
        store = open_store(config_for(args.db))
    except DataError as e:
        sys.exit(f"Can't open the data file: {e}")
    try:
        menu(store)
    except (KeyboardInterrupt, EOFError):
        print()


if __name__ == "__main__":
    main()
