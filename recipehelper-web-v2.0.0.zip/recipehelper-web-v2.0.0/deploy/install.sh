#!/usr/bin/env bash
# Recipe Helper installer for a Debian 12/13 or Ubuntu 24.04 container.
#
#   sudo ./deploy/install.sh                      # fresh install
#   sudo ./deploy/install.sh /root/recipes.db     # ...and bring an existing data file
#   sudo ./deploy/install.sh /root/recipes.json   # ...or import an old JSON / CSV file
#
# Also upgrades a 1-x install (single recipehelper.py) in place, keeping its data.
# Run it from the unzipped release folder.
set -euo pipefail

APP=recipehelper
SRC="$(cd "$(dirname "$0")/.." && pwd)"
# RH_* variables exist only so the scripts can be tested outside a real container.
PREFIX="${RH_PREFIX:-}"
OPT="$PREFIX/opt/$APP"
ETC="$PREFIX/etc/$APP"
DATA="$PREFIX/var/lib/$APP"
UNIT_DIR="$PREFIX/etc/systemd/system"
SBIN="$PREFIX/usr/local/sbin"
BIN="$PREFIX/usr/local/bin"
SYSTEMCTL="${RH_SYSTEMCTL:-systemctl}"
DATA_FILE="${1:-}"

say()  { printf '\033[1m==> %s\033[0m\n' "$*"; }
warn() { printf '\033[33mWARNING: %s\033[0m\n' "$*" >&2; }
die()  { printf '\033[31mERROR: %s\033[0m\n' "$*" >&2; exit 1; }

if [ -z "$PREFIX" ] && [ "$(id -u)" -ne 0 ]; then die "Run as root: sudo $0 $*"; fi
[ -f "$SRC/recipehelper/__init__.py" ] || die "Run this from the unzipped release folder."
VERSION="$(sed -n 's/^__version__ = "\(.*\)"/\1/p' "$SRC/recipehelper/__init__.py")"
if [ -n "$DATA_FILE" ] && [ ! -f "$DATA_FILE" ]; then die "No such file: $DATA_FILE"; fi

own()    { if [ -z "$PREFIX" ]; then chown "$@"; fi; }
as_app() {  # run a command as the app user, with the app's settings
  ( set -a; . "$ETC/$APP.env"; set +a
    cd "$OPT/app"
    if [ -z "$PREFIX" ]; then runuser -u "$APP" -- "$@"; else "$@"; fi )
}
stamp() { date +%Y%m%d-%H%M%S; }

if [ -d "$OPT/app" ]; then
  OLD="$(sed -n 's/^__version__ = "\(.*\)"/\1/p' "$OPT/app/recipehelper/__init__.py" 2>/dev/null || echo '?')"
  die "Recipe Helper v$OLD is already installed. To update, run: sudo $APP-update <zip>"
fi

say "Installing Recipe Helper v$VERSION"

# ---- packages -------------------------------------------------------------
if [ -z "${RH_SKIP_APT:-}" ]; then
  say "Installing python3, python3-venv and curl"
  export DEBIAN_FRONTEND=noninteractive
  apt-get update -qq
  apt-get install -y -qq python3 python3-venv curl ca-certificates >/dev/null
fi

# ---- user -----------------------------------------------------------------
if [ -z "$PREFIX" ] && ! id "$APP" >/dev/null 2>&1; then
  say "Creating system user '$APP' (no login shell)"
  useradd --system --home-dir "$DATA" --no-create-home --shell /usr/sbin/nologin "$APP"
fi

# ---- an older 1-x install at the same paths --------------------------------
if [ -f "$OPT/recipehelper.py" ]; then
  say "Found a 1-x install: archiving it before upgrading"
  "$SYSTEMCTL" stop "$APP" 2>/dev/null || true
  install -d -m 755 "$OPT/rollback"
  TS="$(stamp)"
  mv "$OPT/recipehelper.py" "$OPT/rollback/recipehelper-1x-$TS.py"
  if [ -f "$UNIT_DIR/$APP.service" ]; then cp "$UNIT_DIR/$APP.service" "$OPT/rollback/$APP-1x-$TS.service"; fi
fi

# ---- code + virtual environment ---------------------------------------------
say "Copying the app to $OPT/app"
install -d -m 755 "$OPT"
rm -rf "$OPT/app.new"
mkdir -p "$OPT/app.new"
cp -r "$SRC/recipehelper" "$SRC/wsgi.py" "$SRC/requirements.txt" "$OPT/app.new/"
for f in README.md LOG.md; do if [ -f "$SRC/$f" ]; then cp "$SRC/$f" "$OPT/app.new/"; fi; done
find "$OPT/app.new" -name '__pycache__' -prune -exec rm -rf {} +
own -R root:root "$OPT/app.new"
chmod -R u=rwX,go=rX "$OPT/app.new"
mv "$OPT/app.new" "$OPT/app"

say "Creating the Python environment in $OPT/venv"
# shellcheck disable=SC2086
python3 -m venv ${RH_VENV_ARGS:-} "$OPT/venv"
if [ -z "${RH_SKIP_PIP:-}" ]; then
  "$OPT/venv/bin/pip" install -q --upgrade pip
  "$OPT/venv/bin/pip" install -q -r "$OPT/app/requirements.txt"
fi
own -R root:root "$OPT/venv"

# ---- settings ---------------------------------------------------------------
install -d -m 750 "$ETC"
own root:"$APP" "$ETC"
if [ ! -f "$ETC/$APP.env" ]; then
  say "Writing settings to $ETC/$APP.env"
  TZNAME="$(cat /etc/timezone 2>/dev/null || timedatectl show -p Timezone --value 2>/dev/null || echo UTC)"
  SECRET="$(python3 -c 'import secrets; print(secrets.token_hex(32))')"
  sed -e "s|^SECRET_KEY=.*|SECRET_KEY=$SECRET|" \
      -e "s|^DATA_DIR=.*|DATA_DIR=$DATA|" \
      -e "s|^TIMEZONE=.*|TIMEZONE=$TZNAME|" \
      -e "s|^BIND=.*|BIND=${RH_BIND:-127.0.0.1:8080}|" \
      "$SRC/.env.example" > "$ETC/$APP.env"
else
  say "Keeping the existing settings in $ETC/$APP.env"
fi
chmod 640 "$ETC/$APP.env"
own root:"$APP" "$ETC/$APP.env"
BIND="$(sed -n 's/^BIND=//p' "$ETC/$APP.env")"
PORT="${BIND##*:}"

# ---- data -----------------------------------------------------------------
install -d -m 750 "$DATA" "$DATA/backups"
own "$APP":"$APP" "$DATA" "$DATA/backups"
if [ -f "$DATA/recipes.db" ]; then
  ARCHIVE="$DATA/backups/recipes-$(stamp)-pre-update.db"
  say "Existing data found: archiving it to $ARCHIVE"
  cp -p "$DATA/recipes.db" "$ARCHIVE"
  own "$APP":"$APP" "$ARCHIVE"
fi
if [ -n "$DATA_FILE" ]; then
  case "$DATA_FILE" in
    *.db|*.sqlite|*.sqlite3)
      if [ -f "$DATA/recipes.db" ]; then
        die "There is already a data file at $DATA/recipes.db (archived above). Not replacing it. Move it aside first if you really want to use $DATA_FILE."
      fi
      say "Using $DATA_FILE as the data file"
      cp "$DATA_FILE" "$DATA/recipes.db"
      own "$APP":"$APP" "$DATA/recipes.db"
      chmod 640 "$DATA/recipes.db"
      ;;
  esac
fi
say "Checking the data file"
as_app "$OPT/venv/bin/python" -m recipehelper.manage check
if [ -n "$DATA_FILE" ]; then
  case "$DATA_FILE" in
    *.db|*.sqlite|*.sqlite3) ;;
    *)
      say "Importing $DATA_FILE (rows already there are skipped)"
      install -d -m 750 "$DATA/imports"
      own "$APP":"$APP" "$DATA/imports"
      IMP="$DATA/imports/install-$(basename "$DATA_FILE")"
      cp "$DATA_FILE" "$IMP"
      own "$APP":"$APP" "$IMP"
      as_app "$OPT/venv/bin/python" -m recipehelper.manage import "$IMP"
      rm -f "$IMP"
      ;;
  esac
fi

# ---- commands + service ---------------------------------------------------
install -d -m 755 "$SBIN" "$BIN"
install -m 755 "$SRC/deploy/$APP-update" "$SBIN/$APP-update"
cat > "$BIN/$APP-cli" <<EOF
#!/bin/sh
# The Recipe Helper terminal menu, on the same data as the web app.
set -a; . "$ETC/$APP.env"; set +a
cd "$OPT/app" || exit 1
if [ "\$(id -u)" = 0 ]; then exec runuser -u $APP -- "$OPT/venv/bin/python" -m recipehelper.cli "\$@"; fi
exec "$OPT/venv/bin/python" -m recipehelper.cli "\$@"
EOF
chmod 755 "$BIN/$APP-cli"
install -m 644 "$SRC/deploy/nftables-$APP.nft" "$ETC/nftables-$APP.nft"

say "Installing and starting the service"
install -d -m 755 "$UNIT_DIR"
install -m 644 "$SRC/deploy/$APP.service" "$UNIT_DIR/$APP.service"
"$SYSTEMCTL" daemon-reload
"$SYSTEMCTL" enable "$APP" >/dev/null 2>&1 || true
"$SYSTEMCTL" restart "$APP"

say "Waiting for http://127.0.0.1:$PORT/healthz"
OK=""
for _ in $(seq 1 40); do
  if BODY="$(curl -fsS "http://127.0.0.1:$PORT/healthz" 2>/dev/null)"; then OK=1; break; fi
  sleep 1
done
if [ -z "$OK" ]; then
  "$SYSTEMCTL" status "$APP" --no-pager 2>/dev/null | tail -20 || true
  die "The app didn't answer. See: journalctl -u $APP -n 50"
fi
echo "$BODY"

HOSTNAME_TS="$(tailscale status --json 2>/dev/null | python3 -c 'import json,sys; print(json.load(sys.stdin)["Self"]["DNSName"].rstrip("."))' 2>/dev/null || true)"
URL="${HOSTNAME_TS:+https://$HOSTNAME_TS}"
echo
say "Recipe Helper v$VERSION is installed and running."
echo "Paste this into the container's Notes in Proxmox:"
echo "  Recipe Helper v$VERSION — installed $(date +%Y-%m-%d)${URL:+ — $URL} — update: sudo $APP-update <zip>"
echo
echo "Next steps:"
echo "  1. Publish it on your tailnet with HTTPS:   tailscale serve --bg $PORT"
echo "     then open ${URL:-https://<this-host>.<your-tailnet>.ts.net} on your phone."
echo "  2. Settings: $ETC/$APP.env   (restart after changes: systemctl restart $APP)"
echo "  3. Terminal menu: $APP-cli    Logs: journalctl -u $APP -f"
