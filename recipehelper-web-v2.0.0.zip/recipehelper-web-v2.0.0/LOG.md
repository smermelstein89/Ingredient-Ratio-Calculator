# Recipe Helper — Log

Last updated: 2026-11-22 · Current version: **v2.0.0** (`releases/recipehelper-web-v2.0.0.zip`)

## Open questions

Each has a default the app uses until you answer.

- **Q1 — Deleting old backups.** The template says "keep the newest 30". The Project rules say backups are
  never deleted automatically. *Default:* keep all (`BACKUP_KEEP=0`). Setting `BACKUP_KEEP=30` prunes
  daily, pre-import, pre-restore and pre-undo backups only. Manual, pre-update and pre-migrate backups
  are never pruned.
- **Q2 — Pasted dates like `05/11/2026`.** *Default:* US order, month first (May 11). It can be changed
  per import in the preview, or for good with `US_DATES=false`. Dates that only make sense one way (e.g.
  `25/11/2026`) and dotted dates (`5.11.2026`) are always read day-first.
- **Q3 — What counts as a duplicate bake when importing.** *Default:* the same recipe (capitals ignored),
  date and amounts (to 0.01). Two different bakes of the same recipe on the same day are therefore both
  kept.
- **Q4 — Two kinds of flour** (`logic.py` `detect_ingredient`, from 1-1). Hydration divides by the *first*
  ingredient containing "flour" only, and SDD takes its flour share from that one too. Bread flour 400 +
  rye flour 100 + water 350 shows 87.5%, not 70%. *Default:* kept exactly as 1-x. Should all flours
  count?
- **Q5 — Water inside the discard** (`apply_sdd`/`hydration`, from 1-1). After adding discard, hydration
  ignores the discard's own flour and water, so it reads a little low (3 servings + 100 g discard: 69.0%,
  not 70.0%). *Default:* kept as 1-x.
- **Q6 — Units.** *Default:* each recipe has a unit label, `g` for new and upgraded recipes. It's shown
  next to amounts and doesn't convert anything.
- **Q7 — Who can use it.** *Default:* anyone on your tailnet. `ALLOWED_USERS` limits it to particular
  Tailscale logins.
- **Q8 — Importing bakes for a recipe that doesn't exist yet.** *Default:* the row is listed as a
  problem ("add it or import recipes first"). Nothing is created automatically. Should a recipe be
  created from the bake instead?
- **Q9 — Recipe names that differ only in capitals.** 1-x allowed both "Bread" and "bread". *Default:*
  names must be unique ignoring capitals and surrounding spaces (existing data isn't changed).
- **Q10 — Half-star ratings.** 1-x allowed whole numbers 1–5 only. *Default:* kept, so an import with
  `4.5` is reported as a problem.

## Answered

- **2026-11-22 — Use the full "self-hosted web app" template?** → Yes: rebuilt as v2.0.0 to the full
  spec (package with tests, Gunicorn, installer, update/rollback, import/export, backups, Help).
- **2026-11-22 — Spec vs Project rules?** → The spec wins, but storage stays SQLite. This supersedes the
  2026-11-18 decisions on a single source file, Waitress and NOTES.md. The proposed new Project
  instructions are in `docs/PROJECT-RULES.md`.
- **2026-11-18 — Access control?** → Tailscale only, with no login of its own. Still the default (Q7).

## Decisions

- **D1 — SQLite, not JSON.** Recipes and bakes are linked records, and 1-x data is already SQLite. The
  template allows SQLite where it fits. The schema version is `PRAGMA user_version` (2), and the JSON
  export carries `schema_version`.
- **D2 — Undo replays the change history** (before/after snapshots of the record). It doesn't restore the
  latest backup, which would undo a whole day of changes. Undoing an import or restore restores the
  backup made just before it.
- **D3 — Backups use SQLite's online-backup API** under a file lock (temp file, fsync, rename), so
  they're consistent even while the app is running.
- **D4 — The terminal menu stays** (the Project rule to keep working features), as `recipehelper-cli`.
  Its output is byte-for-byte the same as 1-2 for the same keystrokes.
- **D5 — Version 2.0.0** continues on from 1-2 (template: script v5 → web v6.0).
- **D6 — Tab bar: Home · List · + Add · Reports · More.** List switches between Recipes and Bakes.
  Import, export, backups, history, settings and help are under More.
- **D7 — Charts:** one series each, so no legend (the title names it). Inline SVG with hover tooltips and
  bigger hit areas, a "show as table" view, and colours from the theme so dark mode works.
- **D8 — Gunicorn on 127.0.0.1:8080 behind `tailscale serve`.** `Tailscale-User-Login` is trusted only
  from localhost.
- **D9 — Form safety:** a CSRF token on every form plus a `Sec-Fetch-Site` check. Each form carries a
  one-time id so a double-tap saves once, and the button is also disabled while sending.
- **D10 — Content-Security-Policy has no outside sources and no inline script or style.** Every page
  works without JavaScript; JS only adds conveniences (Today/Yesterday, add-row, confirm, auto-sort,
  live batch total).
- **D11 — Exact amounts survive forms.** A planned or existing amount left untouched in a form is stored
  exactly, not rounded to what the form displayed (as in 1-2).
- **D12 — Template section 9:** no long-running work (imports run in well under a second at this size),
  no scheduled jobs and no outside APIs. Those parts don't apply.
- **D13 — Release files are `recipehelper-web-vX.Y.Z.zip`** and are kept in the Project's `releases/`,
  after `recipehelper-1-1.py` and `recipehelper-1-2.py`.

## Changes

### v2.0.0 — 2026-11-22
- Rebuilt as a multi-file Flask app (`recipehelper/` package) served by Gunicorn, following the
  self-hosted web app template.
- New: edit and delete for recipes and bakes, a unit per recipe and recipe notes.
- New: List page with sortable columns, search, filters (recipe, rating, dates, unrated) and pages.
  The sort and filters live in the URL, and default sorts are set in Settings.
- New: Reports (stats per recipe, rating over time, hydration vs rating), with a print stylesheet.
- New: import from pasted tables, CSV and JSON (the original `recipes.json` and this app's export),
  with a preview, column mapping, duplicate handling and row-numbered problems.
- New: JSON and CSV export, backups (daily / pre-import / pre-restore / pre-update) with download and
  restore, change history with who/when, one-click undo, and warnings when two people edit the same
  record.
- New: Help page, Home with key numbers and "needs attention", bottom tab bar, Today/Yesterday
  buttons, autocomplete, a sticky Save button and a home-screen manifest and icons.
- New: `/healthz`, `deploy/install.sh`, the systemd unit, `recipehelper-update` with automatic rollback,
  an nftables rule and `.env.example`.
- Kept: all 1-x calculations, with results identical to 1-2 (tested), and the terminal menu.
- 1-x data files upgrade in place after a backup. A 1-x install is upgraded by `install.sh`.
- Tests: 319 pytest checks, plus a terminal-output diff against 1-2 and a sandboxed install → update →
  broken update → automatic rollback run.

### 1-2 — 2026-11-18
- Single-file web app (Flask + Waitress) alongside the terminal menu. Docs for Proxmox + Tailscale.
- Fix: an ingredient at 0 per serving no longer crashes *maximize*.

### 1-1 — 2026-11-06
- Terminal app on SQLite (`recipes.db`), with automatic import of the older `recipes.json`.

## Suggestions (not built — pick any)

- **S1 — Bake time and oven temperature as their own fields.** The importer already reads durations like
  `0:45:00`. That would allow charts like "bake time vs rating".
- **S2 — A photo per bake** (crumb shots), stored next to the data and included in backups.
- **S3 — Baker's percentages** on the recipe page (each ingredient as % of flour).
- **S4 — Recipe versions**, so bakes are compared with the recipe as it was on that day.
- **S5 — Count all flours and liquids** in hydration and SDD (see Q4/Q5).
- **S6 — Works offline in the kitchen**: a small service worker so the last-viewed recipe opens without
  a connection.
- **S7 — Timers and reminders** for stretch-and-folds and proofing, from the bake page.
