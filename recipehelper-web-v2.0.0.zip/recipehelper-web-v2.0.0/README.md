# Recipe Helper

Keep your baking recipes, plan a batch from what you have, and log every bake
with what you actually used. A small self-hosted web app for your phone and
computer, running in a Proxmox container and reached over Tailscale.

**Version 2.0.0** · Python 3.9+ · Flask + Gunicorn · one SQLite file · no internet needed at run time

---

## What it does

* **Recipes** with the amounts for one batch, kept per serving so any size scales. A unit per recipe, plus notes.
* **Plan a bake.** *Use what I have* finds the biggest batch your stock allows and names the limiting
  ingredient. *Make a set amount* scales to any number of servings. Optional sourdough-discard (SDD)
  adjustment and hydration.
* **Bake log**: date, actual amounts, extras, servings made, 1–5 rating and notes. Each bake is
  compared with its plan, or with the recipe scaled to it.
* **Lists** of recipes and bakes. Click any column heading to sort, then search, filter and page
  through. The address bar keeps the view, so it can be bookmarked. On a phone, tables become cards
  with a sort menu.
* **Reports**: stats per recipe, plus charts of rating over time and hydration vs rating. Prints cleanly.
* **Import** by pasting from Google Sheets / Excel / Numbers, or uploading CSV or JSON, with a
  preview → confirm step. **Export** to JSON and CSV.
* **Safety nets**: automatic backups, one-click undo, change history (who changed what, when), a warning
  when two people edit the same thing, and confirmation before deleting.
* **The original terminal menu** still works on the same data: `recipehelper-cli`.

## Project layout

```
recipehelper/
  __init__.py      version
  config.py        settings from the environment / .env
  logic.py         the baking calculations (pure functions, no I/O)
  storage.py       SQLite: schema & upgrades, changes, history/undo, backups, export
  importer.py      paste / CSV / JSON parsing and import previews
  charts.py        server-drawn SVG charts
  web.py           Flask routes
  cli.py           the original terminal menu
  manage.py        admin commands (check, backup, import) used by the scripts
  templates/  static/
wsgi.py            WSGI entry point (gunicorn wsgi:app)
deploy/            install.sh, recipehelper.service, recipehelper-update, nftables rule
tests/             pytest suite
.env.example       every setting, explained
LOG.md             open questions, decisions, changes, suggestions
```

## Run it locally (development)

```sh
python3 -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt pytest
cp .env.example .env          # then set: DATA_DIR=data  SECURE_COOKIES=false
python wsgi.py                # http://127.0.0.1:8080
pytest -q                     # the test suite
python -m recipehelper.cli    # the terminal menu
```

---

## Deploy: Proxmox LXC + systemd + Tailscale

Commands marked **host** run in the Proxmox host shell. Commands marked **CT** run inside the
container as root.

### 1. Create the container (host)

Proxmox web UI → **Create CT**:

| Setting | Value |
|---|---|
| Hostname | `recipehelper` |
| Template | Debian 12 / 13 or Ubuntu 24.04 |
| Unprivileged | ✔ (default) |
| CPU / Memory / Disk | 1 core / 512 MB / 4 GB |
| Network | DHCP is fine |

After creating it, open **Options → Features** and tick **nesting** (the service's sandboxing needs it).
Don't start the container yet.

### 2. TUN device for Tailscale (host, container stopped)

```sh
cat >> /etc/pve/lxc/<CTID>.conf <<'EOF'
lxc.cgroup2.devices.allow: c 10:200 rwm
lxc.mount.entry: /dev/net/tun dev/net/tun none bind,create=file
EOF
pct start <CTID>
```

### 3. Tailscale (CT)

```sh
pct enter <CTID>                                     # from the host
apt update && apt install -y curl unzip
curl -fsSL https://tailscale.com/install.sh | sh
tailscale up --hostname=recipehelper
```

Approve the device with the link it prints. In the Tailscale admin console, turn on **MagicDNS** and
**HTTPS Certificates** (DNS page). Consider disabling key expiry for this machine.

### 4. Install the app (host → CT)

```sh
# host: copy the release (and, if you have one, your existing data file) into the container
pct push <CTID> recipehelper-web-v2.0.0.zip /root/recipehelper-web-v2.0.0.zip
pct push <CTID> recipes.db /root/recipes.db                         # optional

# CT
cd /root && unzip recipehelper-web-v2.0.0.zip && cd recipehelper-web-v2.0.0
./deploy/install.sh                    # or: ./deploy/install.sh /root/recipes.db  (or a .json / .csv)
```

`install.sh`:
* installs python3 + python3-venv
* creates the `recipehelper` system user (no login shell)
* copies the code to `/opt/recipehelper/app` (owned by root, read-only to the service)
* creates `/opt/recipehelper/venv` and installs the requirements
* writes `/etc/recipehelper/recipehelper.env` with a random `SECRET_KEY` (mode 640, root:recipehelper)
* keeps data in `/var/lib/recipehelper` (owner recipehelper, 750), with `backups/` inside
* brings your data file: a `.db` is used as the data file and a `.json`/`.csv` is imported
* installs, enables and starts the service, then polls `/healthz` until it answers
* prints the installed version and a line to paste into the container's **Notes** in Proxmox

**Coming from 1-x?** (the single `recipehelper.py` from docs/DEPLOY.md) Run the same command. It
archives the old script and service file in `/opt/recipehelper/rollback/`, makes a dated copy of
`recipes.db` in `backups/`, and then upgrades the data in place. Your recipes and bakes carry over.

### 5. The service

`deploy/recipehelper.service` runs Gunicorn on `127.0.0.1:8080` (the `BIND` setting) and restarts it on
failure and at boot. It is sandboxed with `ProtectSystem=strict`, `ReadWritePaths=/var/lib/recipehelper`,
`NoNewPrivileges`, `PrivateTmp`, `PrivateDevices`, no capabilities, and more.

### 6. Access: HTTPS over Tailscale (recommended)

```sh
tailscale serve --bg 8080
tailscale serve status         # shows https://recipehelper.<your-tailnet>.ts.net
```

`SECURE_COOKIES=true` is already set by the installer for this setup. Open the address on your phone,
then in Safari: Share → **Add to Home Screen**.

**Optional lock-down to particular people:** in `/etc/recipehelper/recipehelper.env` set
`ALLOWED_USERS=you@example.com,partner@example.com`, then `systemctl restart recipehelper`. The app
checks the `Tailscale-User-Login` header that `tailscale serve` adds. It trusts that header **only** on
connections from localhost, so nobody can fake it from the network. Everyone else gets "Not allowed".
The footer shows who is signed in. (Tagged devices have no user login, so they're refused.)

### 7. Access: plain http (simple)

In the env file set `BIND=0.0.0.0:8080` and `SECURE_COOKIES=false`, then restart. Open
`http://recipehelper:8080` from your tailnet. To stop the rest of your LAN reaching it, drop port
8080 everywhere except Tailscale and loopback:

```sh
nft -f /etc/recipehelper/nftables-recipehelper.nft
echo 'include "/etc/recipehelper/nftables-recipehelper.nft"' >> /etc/nftables.conf
systemctl enable nftables
```

`ALLOWED_USERS` doesn't work in this mode, because there's no trusted header.

### 8. Updating

```sh
pct push <CTID> recipehelper-web-v2.0.1.zip /root/recipehelper-web-v2.0.1.zip   # host
sudo recipehelper-update /root/recipehelper-web-v2.0.1.zip                     # CT
```

It shows `v2.0.0 → v2.0.1` and asks before going ahead (`-y` skips the question). Then it:

1. stops the app
2. backs up the data (`backups/…-pre-update.db`) and the current app (`/opt/recipehelper/rollback/`)
3. installs the new version and starts it
4. checks `/healthz` for the new version number

If that check fails, it **rolls back automatically**: the previous code and the pre-update data are
put back and started again. The failed code and data file are kept for inspection, never deleted.
There's deliberately no "upload an update" button in the web app, because that would mean running
code as root.

### 9. Everyday operations

| What | Command (CT) |
|---|---|
| Status | `systemctl status recipehelper` |
| Logs (live) | `journalctl -u recipehelper -f` |
| Restart (after changing settings) | `systemctl restart recipehelper` |
| Health | `curl -s localhost:8080/healthz` → `{"status":"ok","version":"2.0.0",…}` |
| Version | `cat /opt/recipehelper/app/recipehelper/__init__.py` or the footer of any page |
| Terminal menu | `recipehelper-cli` |
| Back up now | web: More → Backups → *Back up now*, or `cd /opt/recipehelper/app && set -a && . /etc/recipehelper/recipehelper.env && runuser -u recipehelper -- /opt/recipehelper/venv/bin/python -m recipehelper.manage backup manual` |
| Settings | `nano /etc/recipehelper/recipehelper.env`, then restart |

**Troubleshooting**

| Symptom | Fix |
|---|---|
| Service fails with `status=226/NAMESPACE` | Turn on **nesting** for the container (Options → Features), restart the CT. |
| `tailscale up` fails with a TUN / `/dev/net/tun` error | The two lines from step 2 are missing from `/etc/pve/lxc/<CTID>.conf`. Add them with the CT stopped. |
| "This form expired" on every save | Cookies aren't kept. On plain `http://` set `SECURE_COOKIES=false`. On `https://` keep it `true`. Restart. |
| Dates are a day off / backups named with the wrong time | Set `TIMEZONE=` (e.g. `America/New_York`) in the env file, and `timedatectl set-timezone …` in the CT. Restart. |
| Phone can't open the address | Is the phone signed in to Tailscale? Does `tailscale serve status` show the mapping? Does `curl localhost:8080/healthz` work in the CT? |
| "Not allowed" page | Your Tailscale login isn't in `ALLOWED_USERS`, or you're using plain http (no trusted header). |
| "Your data file can't be opened" page | The app refused to touch an unreadable file. `systemctl stop recipehelper`, then `mv /var/lib/recipehelper/recipes.db /var/lib/recipehelper/recipes.db.broken`, then `cp /var/lib/recipehelper/backups/<newest good>.db /var/lib/recipehelper/recipes.db`, then `chown recipehelper: /var/lib/recipehelper/recipes.db`, then `systemctl start recipehelper`. |
| `install.sh` / update fails at "pip install" | The CT needs internet access to `pypi.org` and `files.pythonhosted.org` while installing or updating (not while running). |
| "database is locked" in the log | Something held a long write (e.g. a manual `sqlite3` session). Close it. The app waits up to 15 s before giving up. |

### 10. Optional: keep the data on a host dataset

To keep data outside the container (e.g. on ZFS), stop the CT and on the **host**:

```sh
mkdir -p /tank/recipehelper
pct set <CTID> -mp0 /tank/recipehelper,mp=/var/lib/recipehelper
```

In an unprivileged CT, user IDs are shifted by **+100000** on the host. If `id -u recipehelper` in the CT
prints `999`, the host owner must be `100999`:

```sh
chown -R 100999:100999 /tank/recipehelper && chmod 750 /tank/recipehelper
```

Note: Proxmox's own backups (`vzdump`) **don't include bind mounts**. The `backup=1` option only applies
to storage-backed volume mount points. Back up the dataset yourself (e.g. ZFS snapshots), or use a
volume mount point with `backup=1` instead.

**What the container needs to reach:** Debian/Ubuntu mirrors and `pypi.org` / `files.pythonhosted.org`
(install and updates only), plus Tailscale (`*.tailscale.com`). The app itself makes no outside requests.

---

## Data, backups, import and export

* **One file:** `/var/lib/recipehelper/recipes.db` (SQLite, schema version 2 in `PRAGMA user_version`).
  1-x files are upgraded automatically after a `pre-migrate-v2` backup.
* **Every save is one transaction**, so a crash can't leave half a change. A file that isn't a readable
  database is never overwritten.
* **Automatic backups** before the first change each day and before every import, restore and update.
  They're listed, downloadable and restorable under More → Backups. By default none are ever deleted.
  Set `BACKUP_KEEP=30` to keep only the newest 30 automatic ones. Manual and pre-update backups are
  never pruned.
* **Undo:** More → History shows every change with who made it. *Undo* reverses the latest one, and
  pressing it again steps further back. Undoing an import or restore puts back the backup made just
  before it.
* **Import** (More → Import), always previewed first:
  * *Bakes*: one row per bake. Columns `Date`, `Recipe`, `Rating`, `Servings`, `Notes`, plus one column
    per ingredient. A `planned: <ingredient>` column holds planned amounts, and a `Hydration` column is
    ignored because the app works it out.
  * *Recipes*: one row per ingredient. Columns `Recipe`, `Servings`, `Unit`, `Ingredient`, `Amount`
    (whole batch) or `Per serving`, `Notes`.
  * Headers match whatever their capitals, spacing and punctuation. Unknown columns are reported, not
    fatal, and you can remap any column in the preview.
  * Tab, comma and semicolon separators are all handled, as are quoted and multi-line cells,
    `1,234.5` / `1.234,5`, `%`, currency symbols, and dates such as `2026-11-05`, `11/05/2026`,
    `Nov 5, 2026` or spreadsheet serial numbers.
  * Blank rows and Total/Average rows are skipped. Problems are listed by line number.
  * Duplicates (same recipe, date and amounts, or the same recipe name) can be skipped, updated or added
    anyway.
  * JSON: this app's export (any schema version up to 2), or the original script's `recipes.json`.
* **Export** (More → Export): everything as JSON (re-importable), bakes as CSV (one row per bake), and
  recipes as CSV (one row per ingredient).
