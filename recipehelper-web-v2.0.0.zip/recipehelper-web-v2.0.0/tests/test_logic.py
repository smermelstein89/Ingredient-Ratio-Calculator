"""The ported calculations, checked against hand-worked examples, the numbers
the 1-x terminal app printed, and a verbatim copy of the original optimizer."""
import random

import pytest

from recipehelper import logic

RATIOS = {"bread flour": 500.0, "water": 350.0, "salt": 10.0}  # 1000/700/20 for 2 servings


def original_optimize(ratios, use_sdd, sdd, target=None, available=None):
    """Release 1-1 optimize_recipe(), with input() replaced by arguments."""
    if target is not None:
        servings = target
        amounts = {k: v * servings for k, v in ratios.items()}
        warnings = []
        if use_sdd:
            amounts, warnings = logic.apply_sdd(amounts, sdd)
        return servings, amounts, warnings
    finite = {k: v for k, v in available.items() if v != float("inf")}
    if not finite:
        servings = 1.0
        amounts = {k: v * servings for k, v in ratios.items()}
        warnings = []
        if use_sdd:
            amounts, warnings = logic.apply_sdd(amounts, sdd)
    elif len(finite) == 1:
        ing, val = next(iter(finite.items()))
        servings = val / ratios[ing]
        amounts = {k: v * servings for k, v in ratios.items()}
        warnings = []
        if use_sdd:
            if ing == "sdd":
                scale = sdd / max(1e-9, sdd)
                amounts = {k: v * scale for k, v in amounts.items()}
            amounts, warnings = logic.apply_sdd(amounts, sdd)
    else:
        servings = min(available[k] / ratios[k] for k in ratios)
        amounts = {k: v * servings for k, v in ratios.items()}
        warnings = []
        if use_sdd:
            amounts, warnings = logic.apply_sdd(amounts, sdd)
    return servings, amounts, warnings


def test_target_servings_hand_worked():
    s, a, w = logic.compute_plan(RATIOS, target_servings=3)
    assert s == 3 and a == {"bread flour": 1500, "water": 1050, "salt": 30} and w == []
    assert logic.hydration(a) == pytest.approx(70.0)


def test_maximize_hand_worked():
    avail = {"bread flour": 600, "water": float("inf"), "salt": 15}
    s, a, _ = logic.compute_plan(RATIOS, available=avail)
    assert s == pytest.approx(1.2)                     # 600/500 = 1.2 < 15/10 = 1.5
    assert a == pytest.approx({"bread flour": 600, "water": 420, "salt": 12})
    assert logic.limiting_ingredient(RATIOS, avail, s) == "bread flour"


def test_maximize_nothing_limits_is_one_serving():
    s, a, _ = logic.compute_plan(RATIOS, available={})
    assert s == 1.0 and a == RATIOS
    assert logic.limiting_ingredient(RATIOS, {}, s) is None


def test_sdd_numbers_match_terminal_output():
    # 1-x printed "Hydration: 69.0%" for 3 servings + 100 g discard.
    _, a, w = logic.compute_plan(RATIOS, True, 100, target_servings=3)
    assert a == {"bread flour": 1450, "water": 1000, "salt": 30, "sdd": 100}
    assert round(logic.hydration(a), 1) == 69.0 and w == []


def test_sdd_maximize_matches_terminal_output():
    # 1-x printed "Servings: 0.8" and "Hydration: 68.0%" (flour 400, sdd 50).
    s, a, _ = logic.compute_plan(RATIOS, True, 50, available={"bread flour": 400})
    assert f"{s:.4g}" == "0.8" and round(logic.hydration(a), 1) == 68.0


def test_sdd_warnings():
    _, a, w = logic.compute_plan(RATIOS, True, 5000, target_servings=1)
    assert a["bread flour"] == 0 and a["water"] == 0
    assert w == ["SDD exceeds flour; flour reduced to 0", "SDD exceeds liquid; liquid reduced to 0"]


def test_zero_per_serving_ingredient_does_not_crash():
    r = {"flour": 100.0, "seeds": 0.0}
    s, a, _ = logic.compute_plan(r, available={"flour": 250, "seeds": 10})
    assert s == 2.5 and a["seeds"] == 0


@pytest.mark.parametrize("seed", range(200))
def test_same_numbers_as_original(seed):
    rnd = random.Random(seed)
    names = rnd.sample(["bread flour", "water", "salt", "milk", "yeast", "sugar", "rye flour"],
                       rnd.randint(1, 5))
    ratios = {n: round(rnd.uniform(0.5, 600), 3) for n in names}
    use_sdd = rnd.random() < 0.5
    sdd = round(rnd.uniform(0, 300), 2) if use_sdd else 0
    if rnd.random() < 0.4:
        target = round(rnd.uniform(0.1, 10), 3)
        assert logic.compute_plan(dict(ratios), use_sdd, sdd, target_servings=target) == \
            original_optimize(dict(ratios), use_sdd, sdd, target=target)
    else:
        avail = {n: (float("inf") if rnd.random() < 0.4 else round(rnd.uniform(0, 3000), 1))
                 for n in ratios}
        assert logic.compute_plan(dict(ratios), use_sdd, sdd, available=avail) == \
            original_optimize(dict(ratios), use_sdd, sdd, available=avail)


def test_hydration_rules_kept_from_original():
    assert logic.hydration({"salt": 10}) is None
    assert logic.hydration({"bread flour": 0, "water": 10}) is None
    # water + milk both count as liquid
    assert logic.hydration({"flour": 500, "water": 300, "whole milk": 50}) == 70
    # Q4 (LOG.md): only the FIRST flour is the denominator - kept as in 1-x.
    assert logic.hydration({"bread flour": 400, "rye flour": 100, "water": 350}) == 87.5


def test_compare_attempt_matches_terminal_output():
    # 1-x printed for this bake: "water: 750  (+50, +7.1%)", "honey: 10  (extra)",
    # "Not used: salt", "(vs recipe scaled to 2 servings)"
    a = {"amounts": {"bread flour": 1000, "water": 750, "honey": 10}, "servings": None}
    label, rows, skipped = logic.compare_attempt(a, RATIOS)
    assert label == "recipe scaled to 2 servings"
    water = next(r for r in rows if r["name"] == "water")
    assert f"{water['diff']:+.4g}" == "+50" and f"{water['pct']:+.1f}" == "+7.1"
    assert next(r for r in rows if r["name"] == "honey")["extra"]
    assert skipped == ["salt"]


def test_reference_amounts_cases():
    planned = {"amounts": {"water": 1}, "planned": {"water": 2}}
    assert logic.reference_amounts(planned, RATIOS) == ({"water": 2}, "planned")
    by_servings = {"amounts": {"water": 1}, "servings": 3}
    ref, label = logic.reference_amounts(by_servings, RATIOS)
    assert ref["water"] == 1050 and label == "recipe scaled to 3 servings"
    assert logic.reference_amounts({"amounts": {"salt": 5}}, RATIOS) == (None, None)


def test_rating_summary_ties_go_to_earliest():
    bakes = [{"rating": 4}, {"rating": None}, {"rating": 5}, {"rating": 5}]
    avg, best = logic.rating_summary(bakes)
    assert avg == pytest.approx(14 / 3) and best == 3
    assert logic.rating_summary([{"rating": None}]) == (None, None)


def test_bake_key_and_formatting():
    k1 = logic.bake_key("Bread ", "2026-11-01", {"Water": 700.004, "flour": 1000})
    k2 = logic.bake_key("bread", "2026-11-01", {"water": 700, "Flour": 1000.0})
    assert k1 == k2
    assert logic.fmt_amount(1000.0) == "1000" and logic.fmt_amount(1/3) == "0.3333"
    assert logic.prefill(333.3333) == "333.33" and logic.prefill(1000.0) == "1000"
