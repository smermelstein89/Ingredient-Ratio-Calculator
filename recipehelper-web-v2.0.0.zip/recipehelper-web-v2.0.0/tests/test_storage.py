import os
import sqlite3

import pytest

from recipehelper.config import Config
from recipehelper.storage import (SCHEMA_VERSION, Conflict, DataError, InvalidData, NotFound,
                                  Store)

V1_SCHEMA = """
CREATE TABLE recipes (id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE,
    servings REAL NOT NULL CHECK (servings > 0));
CREATE TABLE recipe_ingredients (recipe_id INTEGER NOT NULL REFERENCES recipes(id) ON DELETE CASCADE,
    position INTEGER NOT NULL, name TEXT NOT NULL, per_serving REAL NOT NULL CHECK (per_serving >= 0),
    PRIMARY KEY (recipe_id, name));
CREATE TABLE attempts (id INTEGER PRIMARY KEY, recipe_id INTEGER NOT NULL REFERENCES recipes(id) ON DELETE CASCADE,
    baked_on TEXT NOT NULL, servings REAL, rating INTEGER CHECK (rating BETWEEN 1 AND 5),
    notes TEXT NOT NULL DEFAULT '', hydration REAL, from_plan INTEGER NOT NULL DEFAULT 0);
CREATE TABLE attempt_ingredients (attempt_id INTEGER NOT NULL REFERENCES attempts(id) ON DELETE CASCADE,
    position INTEGER NOT NULL, name TEXT NOT NULL, actual REAL, planned REAL, PRIMARY KEY (attempt_id, name));
INSERT INTO recipes VALUES (1, 'Bread', 2);
INSERT INTO recipe_ingredients VALUES (1, 0, 'bread flour', 500), (1, 1, 'water', 350);
INSERT INTO attempts VALUES (1, 1, '2026-11-01', 2, 4, 'ok', 71.4, 1);
INSERT INTO attempt_ingredients VALUES (1, 0, 'bread flour', 980, 1000), (1, 1, 'water', 700, 700);
"""


def make_v1(path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    c = sqlite3.connect(path)
    c.executescript(V1_SCHEMA)
    c.close()


def test_fresh_database(store, cfg):
    with store.conn() as c:
        assert c.execute("PRAGMA user_version").fetchone()[0] == SCHEMA_VERSION
    assert store.health() == {"recipes": 0, "bakes": 0}
    assert store.list_backups() == []


def test_upgrades_a_1x_database_after_backup(cfg):
    make_v1(cfg.db_path)
    s = Store(cfg)
    s.init()
    assert [b["reason"] for b in s.list_backups()] == ["pre-migrate-v2"]
    r = s.recipe_by_name("Bread")
    assert r["unit"] == "g" and r["rev"] == 1 and r["ingredients"] == {"bread flour": 500, "water": 350}
    a = s.attempts_for_recipe(1)[0]
    assert a["planned"] == {"bread flour": 1000, "water": 700} and a["hydration"] == 71.4
    # The backup is the untouched 1-x file.
    old = sqlite3.connect(os.path.join(cfg.backup_dir, s.list_backups()[0]["name"]))
    assert old.execute("PRAGMA user_version").fetchone()[0] == 0
    s.init()  # running again changes nothing
    assert len(s.list_backups()) == 1


def test_never_overwrites_a_file_it_cannot_read(cfg):
    os.makedirs(cfg.data_dir, exist_ok=True)
    with open(cfg.db_path, "wb") as f:
        f.write(b"this is not a database" * 100)
    before = open(cfg.db_path, "rb").read()
    with pytest.raises(DataError):
        Store(cfg).init()
    assert open(cfg.db_path, "rb").read() == before


def test_refuses_a_newer_schema(cfg):
    os.makedirs(cfg.data_dir, exist_ok=True)
    c = sqlite3.connect(cfg.db_path)
    c.execute("CREATE TABLE recipes (id INTEGER)")
    c.execute("PRAGMA user_version = 99")
    c.commit()
    c.close()
    with pytest.raises(DataError, match="newer version"):
        Store(cfg).init()


def test_transactions_are_all_or_nothing(store, bread):
    with pytest.raises(RuntimeError):
        with store.tx() as c:
            c.execute("UPDATE recipes SET name = 'Changed'")
            raise RuntimeError("power cut")
    assert store.recipe(bread)["name"] == "Bread"


def test_daily_backup_once_per_day(store, bread):
    daily = [b for b in store.list_backups() if b["reason"] == "daily"]
    assert len(daily) == 1   # made before the first change of the day
    store.create_recipe("Rolls", 4, {"flour": 100}, "t")
    store.create_recipe("Pizza", 4, {"flour": 100}, "t")
    assert len([b for b in store.list_backups() if b["reason"] == "daily"]) == 1


def test_backups_are_never_pruned_by_default(store, bread):
    for _ in range(5):
        store.backup("pre-import")
    assert len(store.list_backups()) == 6


def test_backup_keep_prunes_only_automatic_backups(cfg, store, bread):
    cfg.backup_keep = 2
    store.backup("manual")
    for _ in range(4):
        store.backup("pre-import")
    reasons = [b["reason"] for b in store.list_backups()]
    assert reasons.count("manual") == 1
    assert len([r for r in reasons if r in ("pre-import", "daily")]) == 2


def test_restore_and_undo_restore(store, bread):
    name = store.backup("manual")
    store.create_recipe("Rolls", 4, {"flour": 100}, "t")
    safety = store.restore(name, "t")
    assert store.find_recipe_id("Rolls") is None and safety.endswith("pre-restore.db")
    store.undo_last("t")
    assert store.find_recipe_id("Rolls") is not None


def test_restore_rejects_bad_names_and_bad_files(store, cfg):
    with pytest.raises(NotFound):
        store.restore("../../etc/passwd", "t")
    bad = os.path.join(cfg.backup_dir, "recipes-20260101-000000-manual.db")
    with open(bad, "wb") as f:
        f.write(b"junk")
    with pytest.raises(InvalidData):
        store.restore("recipes-20260101-000000-manual.db", "t")


def test_edit_conflicts_are_detected(store, bread):
    store.update_recipe(bread, "Bread", 2, {"bread flour": 500}, "alice", expected_rev=1)
    with pytest.raises(Conflict) as e:
        store.update_recipe(bread, "Bread", 3, {"bread flour": 1}, "bob", expected_rev=1)
    assert e.value.current["rev"] == 2
    store.update_recipe(bread, "Bread", 3, {"bread flour": 1}, "bob", expected_rev=1, force=True)
    assert store.recipe(bread)["servings"] == 3


def test_undo_walks_back_every_kind_of_change(store, bread):
    aid = store.create_attempt(bread, {"date": "2026-11-01", "amounts": {"bread flour": 1000}, "rating": 3}, "t")
    store.update_attempt(aid, {"date": "2026-11-02", "amounts": {"bread flour": 900}, "rating": 5}, "t")
    store.update_recipe(bread, "Loaf", 4, {"bread flour": 250}, "t")
    store.delete_recipe(bread, "t")
    assert store.health() == {"recipes": 0, "bakes": 0}
    store.undo_last("t")   # delete
    assert store.health() == {"recipes": 1, "bakes": 1}
    store.undo_last("t")   # recipe edit, bakes kept
    r = store.recipe(bread)
    assert r["name"] == "Bread" and r["servings"] == 2 and store.health()["bakes"] == 1
    store.undo_last("t")   # bake edit
    a = store.attempt(aid)
    assert a["date"] == "2026-11-01" and a["rating"] == 3 and a["amounts"] == {"bread flour": 1000}
    store.undo_last("t")   # bake create
    store.undo_last("t")   # recipe create
    assert store.health() == {"recipes": 0, "bakes": 0}
    with pytest.raises(NotFound):
        store.undo_last("t")
    assert {h["who"] for h in store.history()} == {"t", "test"}


def test_names_are_unique_ignoring_case(store, bread):
    with pytest.raises(InvalidData):
        store.create_recipe("  bread ", 1, {"x": 1}, "t")


def test_sorting_uses_real_values(store):
    a = store.create_recipe("A", 1, {"flour": 100, "water": 9.5}, "t")     # 9.5% hydration
    b = store.create_recipe("B", 1, {"flour": 100, "water": 70}, "t")
    c = store.create_recipe("C", 1, {"salt": 1}, "t")              # no flour: no hydration
    store.create_attempt(a, {"date": "2026-02-01", "amounts": {"flour": 100, "water": 9.5}, "rating": 5}, "t")
    store.create_attempt(b, {"date": "2026-10-01", "amounts": {"flour": 100, "water": 70}, "rating": 2}, "t")
    store.create_attempt(c, {"date": "2026-09-30", "amounts": {"salt": 1}}, "t")
    rows, _ = store.bake_list(sort="hydration", desc=True)
    assert [r["recipe"] for r in rows] == ["B", "A", "C"]     # numeric; empty last
    rows, _ = store.bake_list(sort="hydration", desc=False)
    assert [r["recipe"] for r in rows] == ["A", "B", "C"]     # empty still last
    rows, _ = store.bake_list(sort="date", desc=True)
    assert [r["baked_on"] for r in rows] == ["2026-10-01", "2026-09-30", "2026-02-01"]
    rows, total = store.bake_list(min_rating=4)
    assert total == 1 and rows[0]["recipe"] == "A"
    rows, total = store.bake_list(unrated=True)
    assert [r["recipe"] for r in rows] == ["C"]
    rows, total = store.recipe_list(sort="rating", desc=True, per_page=2, page=1)
    assert total == 3 and [r["name"] for r in rows] == ["A", "B"]
    rows, _ = store.recipe_list(sort="rating", desc=True, per_page=2, page=2)
    assert [r["name"] for r in rows] == ["C"]
    rows, _ = store.recipe_list(q="b")
    assert [r["name"] for r in rows] == ["B"]
    rows, _ = store.bake_list(q="%")       # LIKE wildcards are matched literally
    assert rows == []


def test_settings_and_undo(store):
    store.set_settings({"bakes_sort": "rating", "bogus": "x"}, "t")
    assert store.settings()["bakes_sort"] == "rating" and "bogus" not in store.settings()
    store.undo_last("t")
    assert store.settings()["bakes_sort"] == "-date"


def test_export_csv(store, bread):
    store.create_attempt(bread, {"date": "2026-11-01", "amounts": {"bread flour": 980, "yeast": 7},
                                 "planned": {"bread flour": 1000}, "rating": 4, "notes": "hi"}, "t")
    lines = store.export_bakes_csv().splitlines()
    assert lines[0] == "id,date,recipe,rating,servings,hydration,notes,bread flour,yeast,planned: bread flour"
    # flour but no water/milk = 0% hydration, as in 1-x
    assert lines[1] == "1,2026-11-01,Bread,4,,0,hi,980,7,1000"
    assert store.export_recipes_csv().splitlines()[1] == "Bread,2,g,bread flour,1000,500,"
