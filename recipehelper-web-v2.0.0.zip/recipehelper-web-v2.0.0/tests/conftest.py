import itertools
import os
import re
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from recipehelper.config import Config  # noqa: E402
from recipehelper.storage import Store  # noqa: E402

_ids = itertools.count()


@pytest.fixture
def cfg(tmp_path):
    return Config(data_dir=str(tmp_path / "data"), timezone="America/New_York")


@pytest.fixture
def store(cfg):
    s = Store(cfg)
    s.init()
    return s


@pytest.fixture
def bread(store):
    """The 1-x test recipe: 1000 flour / 700 water / 20 salt for 2 servings."""
    return store.create_recipe("Bread", 2, {"bread flour": 500, "water": 350, "salt": 10}, "test")


@pytest.fixture
def app(cfg):
    from recipehelper.web import create_app
    a = create_app(cfg)
    a.testing = True
    return a


@pytest.fixture
def client(app):
    return app.test_client()


def csrf(client):
    html = client.get("/settings").get_data(as_text=True)
    return re.search(r'name="csrf_token" value="([^"]+)"', html).group(1)


def post(client, url, data=None, **kw):
    """POST a form the way a browser would: CSRF token and a fresh form id."""
    data = dict(data or {})
    data.setdefault("csrf_token", csrf(client))
    data.setdefault("form_id", f"f{next(_ids)}")
    return client.post(url, data=data, **kw)
