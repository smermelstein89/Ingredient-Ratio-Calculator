import json
from datetime import date

import pytest

from recipehelper import importer


@pytest.mark.parametrize("raw,expected", [
    ("1,234.5", 1234.5), ("1.234,5", 1234.5), ("$12", 12), ("75%", 75), ("980 g", 980),
    ("1,5", 1.5), ("1,234", 1234), ("  700 ", 700), ("(5)", -5), ("€3,50", 3.5),
    ("1 234", 1234), ("", None),
])
def test_parse_number(raw, expected):
    assert importer.parse_number(raw) == expected


def test_parse_number_decimal_comma_mode():
    assert importer.parse_number("1,234", decimal_comma=True) == 1.234


@pytest.mark.parametrize("raw", ["8:34:29", "abc", "1.2.3"])
def test_parse_number_rejects(raw):
    with pytest.raises(ValueError):
        importer.parse_number(raw)


def test_parse_duration():
    assert importer.parse_duration("8:34:29") == 8 * 3600 + 34 * 60 + 29
    assert importer.parse_duration("34:29") == 34 * 60 + 29


@pytest.mark.parametrize("raw,us,expected", [
    ("2026-11-05", True, date(2026, 11, 5)),
    ("2026/11/05", True, date(2026, 11, 5)),
    ("11/05/2026", True, date(2026, 11, 5)),
    ("11/05/2026", False, date(2026, 5, 11)),
    ("25/11/2026", True, date(2026, 11, 25)),      # can only be day-first
    ("5.11.2026", True, date(2026, 11, 5)),        # dots mean day-first
    ("11/5/26", True, date(2026, 11, 5)),
    ("Nov 5, 2026", True, date(2026, 11, 5)),
    ("5 November 2026", True, date(2026, 11, 5)),
    ("Thursday, November 5th, 2026", True, date(2026, 11, 5)),
    ("5-Nov-2026", True, date(2026, 11, 5)),
    ("2026-11-05 14:30:00", True, date(2026, 11, 5)),
    ("45658", True, date(2025, 1, 1)),             # spreadsheet serial number
])
def test_parse_date(raw, us, expected):
    assert importer.parse_date(raw, us=us) == expected


@pytest.mark.parametrize("raw", ["", "13/13/2026", "soon", "2026-02-30"])
def test_parse_date_rejects(raw):
    with pytest.raises(ValueError):
        importer.parse_date(raw)


@pytest.mark.parametrize("raw,expected", [
    ("4", 4), ("4/5", 4), ("★★★★", 4), ("****", 4), ("4 stars", 4), ("4.0", 4), ("", None), ("-", None)])
def test_parse_rating(raw, expected):
    assert importer.parse_rating(raw) == expected


@pytest.mark.parametrize("raw", ["4.5", "6", "0", "good"])
def test_parse_rating_rejects(raw):
    with pytest.raises(ValueError):
        importer.parse_rating(raw)


def test_delimiters_and_multiline_headers():
    assert importer.detect_delimiter("a\tb\tc\n1\t2\t3") == "\t"
    assert importer.detect_delimiter("a,b,c\n1,2,3") == ","
    assert importer.detect_delimiter("a;b;c\n1,5;2;3") == ";"
    d, headers, rows = importer.read_table('Date\t"Bread\nflour (g)"\tWater\n2026-11-01\t1000\t700\n\n')
    assert d == "\t" and headers == ["Date", "Bread flour (g)", "Water"]
    assert rows == [(3, ["2026-11-01", "1000", "700"])]  # header spans lines 1-2


def test_header_matching_ignores_case_space_punctuation():
    assert importer.normalize_header("  Rating (1–5) ") == "rating 1 5"
    assert importer._match("RECIPE-NAME", importer.BAKE_ALIASES) == "recipe"
    assert importer.ingredient_from_header("Bread flour (g)") == "Bread flour"
    assert importer.ingredient_from_header("planned: Water") == "Water"


SHEET = (
    "DATE\tRecipe Name\tBread Flour (g)\tWater\tSalt\tHydration %\tRating (1–5)\tNotes\tMystery\n"
    "11/01/2026\tbread\t1,000\t700\t20\t70%\t4/5\tGood rise\tblue\n"
    "\t\t\t\t\t\t\t\t\n"
    "Nov 3, 2026\tBread\t980\t720\t\t73.5%\t★★★★★\tBest yet\tred\n"
    "2026-11-04\tCake\t500\t300\t\t\t3\t\t\n"
    "2026-11-05\tBread\tlots\t700\t\t\t9\t\t\n"
    "Total\t\t2480\t1720\t\t\t\t\t\n"
)


def job(text, kind="auto", mode="skip"):
    return {"kind": kind, "text": text, "data": None, "mode": mode, "us_dates": True,
            "mapping": None, "default_recipe": ""}


def test_paste_preview_bakes(store, bread):
    pv = importer.build_preview(store, job(SHEET))
    assert pv["kind"] == "bakes" and pv["delimiter"] == "tab"
    fields = {c["header"]: c["field"] for c in pv["columns"]}
    assert fields["DATE"] == "date" and fields["Recipe Name"] == "recipe"
    assert fields["Bread Flour (g)"] == "ingredient" and fields["Rating (1–5)"] == "rating"
    assert fields["Hydration %"] == "ignore" and fields["Mystery"] == "ignore"
    assert pv["unknown"] == ["Mystery"]
    by_line = {r["line"]: r for r in pv["rows"]}
    assert by_line[2]["status"] == "add"
    assert by_line[4]["status"] == "add"
    assert "no recipe called “Cake”" in by_line[5]["reason"]
    assert by_line[6]["status"] == "error" and "lots" in by_line[6]["reason"] and "rating" in by_line[6]["reason"]
    assert by_line[7]["status"] == "skip" and "summary" in by_line[7]["reason"]
    assert pv["counts"] == {"add": 2, "update": 0, "skip": 1, "error": 2}
    first = pv["actions"][0]["data"]
    # ingredient names map onto the recipe's own spelling; hydration is recomputed later
    assert first["amounts"] == {"bread flour": 1000, "water": 700, "salt": 20}
    assert first["recipe"] == "Bread" and first["rating"] == 4 and first["date"] == "2026-11-01"
    assert store.health()["bakes"] == 0          # nothing written by a preview


def test_paste_import_then_duplicates(store, bread):
    pv = importer.build_preview(store, job(SHEET))
    counts, safety = store.apply_import(pv["actions"], "test", "paste")
    assert counts["bakes added"] == 2 and safety.endswith("-pre-import.db")
    b = store.attempts_for_recipe(bread)
    assert b[0]["hydration"] == 70.0 and b[1]["hydration"] == pytest.approx(73.5)
    again = importer.build_preview(store, job(SHEET))
    assert again["counts"]["add"] == 0 and again["counts"]["skip"] == 3
    upd = importer.build_preview(store, job(SHEET, mode="update"))
    assert upd["counts"]["update"] == 2
    add = importer.build_preview(store, job(SHEET, mode="add"))
    assert add["counts"]["add"] == 2


def test_old_paste_with_missing_columns_still_imports(store, bread):
    text = "Date,Recipe,Bread flour,Water\n2026-10-01,Bread,1000,700\n"
    pv = importer.build_preview(store, job(text))
    assert pv["counts"]["add"] == 1 and pv["actions"][0]["data"]["rating"] is None


def test_mapping_can_be_fixed_and_default_recipe(store, bread):
    text = "When,Flour,Water\n2026-10-01,1000,700\n"
    pv = importer.build_preview(store, job(text))
    assert pv["errors"]                      # no Date / Recipe column recognised
    j = job(text)
    j["mapping"] = ["date", "ingredient", "ingredient"]
    j["default_recipe"] = "Bread"
    pv = importer.build_preview(store, j)
    assert not pv["errors"] and pv["counts"]["add"] == 1


def test_recipes_long_format(store):
    text = ("Recipe;Servings;Unit;Ingredient;Amount\n"
            "Focaccia;1;g;Flour;500\n;;;Water;400\n;;;Olive oil;30,5\n"
            "Rolls;0;g;Flour;400\n"
            "Pizza;4;g;Flour;\n")
    pv = importer.build_preview(store, job(text))
    assert pv["kind"] == "recipes" and pv["delimiter"] == "semicolon"
    ok = [r for r in pv["rows"] if r["status"] == "add"]
    assert len(ok) == 1 and pv["counts"]["error"] == 2
    data = pv["actions"][0]["data"]
    assert data["ingredients"] == {"Flour": 500, "Water": 400, "Olive oil": 30.5}
    store.apply_import(pv["actions"], "test", "paste")
    assert store.recipe_by_name("focaccia")["servings"] == 1


def test_json_original_script_format(store):
    legacy = {"Bread": {"servings": 2, "ingredients": {"flour": 500, "water": 350},
                        "attempts": [{"date": "2026-10-01", "amounts": {"flour": 1000, "water": 700},
                                      "rating": 4, "notes": "ok", "hydration": 70.0},
                                     {"date": "next tuesday", "amounts": {"flour": 1}}]}}
    j = {"kind": "json", "data": json.dumps(legacy), "mode": "skip", "us_dates": True}
    pv = importer.build_preview(store, j)
    assert pv["format"] == "original script’s recipes.json"
    assert pv["counts"] == {"add": 2, "update": 0, "skip": 0, "error": 1}
    assert "line" not in str(pv["rows"][2]["line"])
    store.apply_import(pv["actions"], "test", "recipes.json")
    assert store.health() == {"recipes": 1, "bakes": 1}


def test_json_export_roundtrip(store, bread, cfg, tmp_path):
    from recipehelper.config import Config
    from recipehelper.storage import Store
    store.create_attempt(bread, {"date": "2026-11-01", "amounts": {"bread flour": 980, "water": 700},
                                 "planned": {"bread flour": 1000, "water": 700}, "rating": 5,
                                 "notes": "x"}, "t")
    exported = json.dumps(store.export_data())
    other = Store(Config(data_dir=str(tmp_path / "other")))
    other.init()
    pv = importer.build_preview(other, {"kind": "json", "data": exported, "mode": "skip", "us_dates": True})
    other.apply_import(pv["actions"], "t", "export.json")

    def strip(d):
        for r in d["recipes"]:
            r.pop("id"), r.pop("created_at"), r.pop("updated_at")
            for b in r["bakes"]:
                b.pop("id"), b.pop("created_at"), b.pop("updated_at")
        return d["recipes"]
    assert strip(other.export_data()) == strip(store.export_data())
    # importing the same export again changes nothing
    pv2 = importer.build_preview(other, {"kind": "json", "data": exported, "mode": "skip", "us_dates": True})
    assert pv2["counts"]["add"] == 0


def test_json_rejects_unknown_files(store):
    for bad in ["[1,2]", '{"recipes": [], "schema_version": 9}', "not json"]:
        pv = importer.build_preview(store, {"kind": "json", "data": bad, "mode": "skip"})
        assert pv["errors"] and not pv["can_import"]


def test_csv_export_reimports(store, bread):
    store.create_attempt(bread, {"date": "2026-11-01", "amounts": {"bread flour": 1000, "water": 700},
                                 "rating": 4, "notes": "a, b"}, "t")
    csv_text = store.export_bakes_csv()
    pv = importer.build_preview(store, job(csv_text, mode="skip"))
    assert pv["counts"]["skip"] == 1 and pv["counts"]["error"] == 0
    rec = importer.build_preview(store, job(store.export_recipes_csv(), mode="skip"))
    assert rec["kind"] == "recipes" and rec["counts"]["skip"] == 1


def test_jobs_are_saved_and_tokens_checked(cfg):
    j = importer.new_job(cfg, "auto", "paste", text="a,b\n1,2")
    assert importer.load_job(cfg, j["token"])["text"] == "a,b\n1,2"
    with pytest.raises(KeyError):
        importer.load_job(cfg, "../../etc/passwd")
    importer.drop_job(cfg, j["token"])
    with pytest.raises(KeyError):
        importer.load_job(cfg, j["token"])
