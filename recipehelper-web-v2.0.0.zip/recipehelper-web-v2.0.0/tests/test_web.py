import json
import os
import re

import pytest

from conftest import csrf, post
from recipehelper import __version__
from recipehelper.config import Config


def store_of(app):
    return app.extensions["recipehelper"]["store"]


def make_bread(client):
    r = post(client, "/recipes/new", {"name": "Bread", "servings": "2", "unit": "g",
                                      "ing_name": ["bread flour", "water", "salt", ""],
                                      "ing_amount": ["1000", "700", "20", ""]})
    assert r.status_code == 302
    return int(r.headers["Location"].rsplit("/", 1)[1])


PAGES = ["/", "/list", "/list?view=bakes", "/add", "/recipes/new", "/reports", "/more",
         "/settings", "/history", "/import", "/help"]


@pytest.mark.parametrize("url", PAGES)
def test_pages_load_empty(client, url):
    assert client.get(url).status_code == 200


def test_pages_load_with_data(client):
    rid = make_bread(client)
    aid = int(post(client, "/bakes/new", {"recipe": rid, "date": "2026-11-01", "amt_0": "1000",
                                          "amt_1": "700", "rating": "4"}).headers["Location"].rsplit("/", 1)[1])
    for url in PAGES + [f"/recipes/{rid}", f"/recipes/{rid}/edit", f"/recipes/{rid}/plan",
                        f"/bakes/{aid}", f"/bakes/{aid}/edit", f"/bakes/new?recipe={rid}",
                        f"/recipes/{rid}/delete", f"/bakes/{aid}/delete", "/reports?recipe=1&sort=-rating"]:
        assert client.get(url).status_code == 200, url


def test_healthz(client):
    make_bread(client)
    j = client.get("/healthz").get_json()
    assert j == {"status": "ok", "version": __version__, "recipes": 1, "bakes": 0, "records": 1}


def test_security_headers(client):
    r = client.get("/")
    csp = r.headers["Content-Security-Policy"]
    assert "default-src 'self'" in csp and "script-src 'self'" in csp and "http" not in csp
    assert r.headers["X-Frame-Options"] == "DENY" and r.headers["X-Content-Type-Options"] == "nosniff"
    html = r.get_data(as_text=True)
    assert "style=" not in html and "onclick" not in html and "<script>" not in html


def test_no_template_uses_inline_style_or_script():
    root = os.path.join(os.path.dirname(__file__), "..", "recipehelper", "templates")
    for name in os.listdir(root):
        text = open(os.path.join(root, name), encoding="utf-8").read()
        assert " style=" not in text and "onclick=" not in text and "<script>" not in text, name


def test_csrf_is_required(client):
    r = client.post("/recipes/new", data={"name": "X", "servings": "1"})
    assert r.status_code == 400 and b"form expired" in r.data
    assert store_of(client.application).health()["recipes"] == 0


def test_cross_site_post_is_blocked(client):
    r = post(client, "/recipes/new", {"name": "X", "servings": "1", "ing_name": "a", "ing_amount": "1"},
             headers={"Sec-Fetch-Site": "cross-site"})
    assert r.status_code == 403


def test_double_submit_saves_once(client):
    tok = csrf(client)
    data = {"csrf_token": tok, "form_id": "same", "name": "Bread", "servings": "2",
            "ing_name": ["flour"], "ing_amount": ["1000"]}
    assert client.post("/recipes/new", data=data).status_code == 302
    r = client.post("/recipes/new", data=data)
    assert r.status_code == 302
    assert store_of(client.application).health()["recipes"] == 1


def test_recipe_validation_is_per_field(client):
    r = post(client, "/recipes/new", {"name": "", "servings": "zero",
                                      "ing_name": ["flour", "flour", "yeast", ""],
                                      "ing_amount": ["1000", "1", "abc", "5"]})
    html = r.get_data(as_text=True)
    assert r.status_code == 400
    assert 'id="err-name"' in html and 'id="err-servings"' in html
    assert "“abc” isn&#39;t a number" in html and "flour is listed twice" in html
    assert "Add the ingredient&#39;s name" in html
    assert 'value="abc"' in html     # input kept


def test_edit_recipe_keeps_exact_values_and_detects_conflicts(client):
    rid = make_bread(client)
    store = store_of(client.application)
    # A per-serving value that doesn't survive rounding through a form.
    store.update_recipe(rid, "Bread", 3, {"bread flour": 1000 / 3, "water": 700 / 3}, "t")
    page = client.get(f"/recipes/{rid}/edit").get_data(as_text=True)
    rev = re.search(r'name="rev" value="(\d+)"', page).group(1)
    totals = re.findall(r'name="ing_amount" value="([^"]*)"', page)
    r = post(client, f"/recipes/{rid}/edit", {"name": "Bread", "servings": "3", "unit": "g", "rev": rev,
                                              "ing_name": ["bread flour", "water"], "ing_amount": totals[:2]})
    assert r.status_code == 302
    assert store.recipe(rid)["ingredients"]["bread flour"] == 1000 / 3
    stale = post(client, f"/recipes/{rid}/edit", {"name": "Bread 2", "servings": "3", "rev": rev,
                                                  "ing_name": ["flour"], "ing_amount": ["1"]})
    assert stale.status_code == 409 and b"Someone else changed" in stale.data
    assert store.recipe(rid)["name"] == "Bread"


def test_plan_then_log_keeps_planned_amounts_exact(client):
    rid = make_bread(client)
    page = client.get(f"/recipes/{rid}/plan?go=1&mode=target&target=1&use_sdd=1&sdd=33.333").get_data(as_text=True)
    assert "Sourdough discard" in page
    planned = re.search(r'name="planned" value="([^"]+)"', page).group(1).replace("&#34;", '"')
    form = client.get(f"/bakes/new?recipe={rid}&planned=" + planned).get_data(as_text=True)
    values = dict(re.findall(r'name="(amt_\d+)" value="([^"]*)"', form))
    values.update({"recipe": rid, "planned": planned, "date": "2026-11-01", "rating": "5"})
    r = post(client, "/bakes/new", values)
    assert r.status_code == 302
    a = store_of(client.application).attempt(int(r.headers["Location"].rsplit("/", 1)[1]))
    assert a["amounts"] == a["planned"] and a["amounts"]["sdd"] == 33.333
    bake = client.get(r.headers["Location"]).get_data(as_text=True)
    assert "Compared with planned" in bake and "✓ same" in bake


def test_plan_maximize_and_errors(client):
    rid = make_bread(client)
    html = client.get(f"/recipes/{rid}/plan?go=1&mode=max&have_0=600&have_2=15").get_data(as_text=True)
    assert "1.2 servings" in html and "Limited by bread flour" in html and "70.0%" in html
    html = client.get(f"/recipes/{rid}/plan?go=1&mode=target&target=").get_data(as_text=True)
    assert "Enter servings" in html


def test_bake_validation_edit_and_delete(client):
    rid = make_bread(client)
    r = post(client, "/bakes/new", {"recipe": rid, "date": "", "amt_0": "-1"})
    assert r.status_code == 400 and b"Pick the date" in r.data and b"negative" in r.data
    r = post(client, "/bakes/new", {"recipe": rid, "date": "2026-11-05", "amt_0": "1000", "amt_1": "750",
                                    "extra_name": ["honey", ""], "extra_amount": ["10", ""],
                                    "rating": "2", "notes": "Too slack"})
    aid = int(r.headers["Location"].rsplit("/", 1)[1])
    html = client.get(f"/bakes/{aid}").get_data(as_text=True)
    assert "recipe scaled to 2 servings" in html and "▲ +50" in html and "+ extra" in html
    assert "Not used: salt" in html and "75.0%" in html
    page = client.get(f"/bakes/{aid}/edit").get_data(as_text=True)
    rev = re.search(r'name="rev" value="(\d+)"', page).group(1)
    r = post(client, f"/bakes/{aid}/edit", {"date": "2026-11-06", "amt_0": "1000", "amt_1": "700",
                                            "extra_name": ["honey"], "extra_amount": ["10"],
                                            "rating": "4", "rev": rev})
    assert r.status_code == 302
    a = store_of(client.application).attempt(aid)
    assert a["date"] == "2026-11-06" and a["hydration"] == 70.0 and a["amounts"]["honey"] == 10
    assert post(client, f"/bakes/{aid}/delete").status_code == 302
    assert client.get(f"/bakes/{aid}").status_code == 404


def test_delete_recipe_and_one_click_undo(client):
    rid = make_bread(client)
    post(client, "/bakes/new", {"recipe": rid, "date": "2026-11-01", "amt_0": "1000"})
    r = post(client, f"/recipes/{rid}/delete", follow_redirects=True)
    html = r.get_data(as_text=True)
    assert "Deleted “Bread”" in html and ">Undo<" in html
    post(client, "/history/undo", {"next": "/"})
    s = store_of(client.application)
    assert s.health() == {"recipes": 1, "bakes": 1}
    hist = client.get("/history").get_data(as_text=True)
    assert "Undid: Deleted recipe “Bread” and its 1 bake" in hist and "undone" in hist


def test_list_sorting_filters_and_pages(client, app):
    s = store_of(app)
    rid = make_bread(client)
    for i in range(30):
        s.create_attempt(rid, {"date": f"2026-10-{i + 1:02d}", "amounts": {"bread flour": 1000, "water": 600 + i * 5},
                               "rating": (i % 5) + 1}, "t")
    html = client.get("/list?view=bakes").get_data(as_text=True)
    assert "page 1 of 2" in html and html.index("2026-10-30") < html.index("2026-10-29")
    html = client.get("/list?view=bakes&sort=hydration").get_data(as_text=True)
    assert 'aria-sort="ascending"' in html and html.index("2026-10-01") < html.index("2026-10-02")
    assert "sort=-hydration" in html     # clicking again reverses
    html = client.get("/list?view=bakes&min_rating=5&page=1").get_data(as_text=True)
    assert "6 bakes" in html
    html = client.get("/list?view=bakes&sort=-date&page=2").get_data(as_text=True)
    assert "2026-10-05" in html and "2026-10-30" not in html


def test_default_sort_from_settings(client):
    make_bread(client)
    post(client, "/settings", {"recipes_sort": "-bakes", "bakes_sort": "date", "default_unit": "oz"})
    html = client.get("/list").get_data(as_text=True)
    assert 'aria-sort="descending"' in html
    assert 'value="oz"' in client.get("/recipes/new").get_data(as_text=True)


def test_import_through_the_web(client):
    make_bread(client)
    text = "Date\tRecipe\tBread flour\tWater\tRating\n2026-11-01\tBread\t1000\t700\t4\nTotal\t\t1000\t700\t\n"
    r = post(client, "/import", {"how": "paste", "kind": "auto", "text": text})
    assert r.status_code == 302
    url = r.headers["Location"]
    html = client.get(url).get_data(as_text=True)
    assert "1 to add" in html and "summary row" in html
    s = store_of(client.application)
    assert s.health()["bakes"] == 0
    r = post(client, url, {"action": "confirm", "mode": "skip", "kind": "bakes", "dates": "us",
                           "ncols": "5", "map_0": "date", "map_1": "recipe", "map_2": "ingredient",
                           "map_3": "ingredient", "map_4": "rating"})
    assert r.status_code == 302 and s.health()["bakes"] == 1
    assert any(b["reason"] == "pre-import" for b in s.list_backups())
    assert client.get(url, follow_redirects=True).request.path == "/import"   # job is gone


def test_import_json_upload(client):
    import io
    legacy = {"Rolls": {"servings": 4, "ingredients": {"flour": 100, "milk": 60},
                        "attempts": [{"date": "2026-10-01", "amounts": {"flour": 400, "milk": 250}, "rating": 5}]}}
    r = post(client, "/import", {"how": "file", "kind": "auto",
                                 "file": (io.BytesIO(json.dumps(legacy).encode()), "recipes.json")},
             content_type="multipart/form-data")
    url = r.headers["Location"]
    assert "original script" in client.get(url).get_data(as_text=True)
    post(client, url, {"action": "confirm", "mode": "skip"})
    assert store_of(client.application).health() == {"recipes": 1, "bakes": 1}


def test_exports_and_backups(client):
    make_bread(client)
    j = json.loads(client.get("/export/recipehelper.json").data)
    assert j["schema_version"] == 2 and j["recipes"][0]["name"] == "Bread"
    assert client.get("/export/bakes.csv").headers["Content-Disposition"].startswith("attachment")
    post(client, "/backups/new")
    s = store_of(client.application)
    name = next(b["name"] for b in s.list_backups() if b["reason"] == "manual")
    r = client.get(f"/backups/{name}")
    assert r.status_code == 200 and r.data[:15] == b"SQLite format 3"
    assert client.get("/backups/..%2F..%2Fetc%2Fpasswd").status_code == 404
    post(client, "/recipes/new", {"name": "Extra", "servings": "1", "ing_name": "a", "ing_amount": "1"})
    post(client, f"/backups/{name}/restore")
    assert s.find_recipe_id("Extra") is None


def test_manifest_and_icons(client):
    m = json.loads(client.get("/manifest.webmanifest").data)
    assert m["display"] == "standalone"
    for icon in m["icons"]:
        assert client.get(icon["src"]).status_code == 200


def test_allowed_users(tmp_path):
    from recipehelper.web import create_app
    cfg = Config(data_dir=str(tmp_path / "d"), allowed_users=["me@example.com"])
    c = create_app(cfg).test_client()
    ok = c.get("/", headers={"Tailscale-User-Login": "Me@Example.com"})
    assert ok.status_code == 200 and b"Signed in as me@example.com" in ok.data
    assert c.get("/", headers={"Tailscale-User-Login": "else@example.com"}).status_code == 403
    assert c.get("/").status_code == 403
    # the header is only trusted from localhost (tailscale serve), not from the network
    remote = c.get("/", headers={"Tailscale-User-Login": "me@example.com"},
                   environ_base={"REMOTE_ADDR": "100.64.0.9"})
    assert remote.status_code == 403
    assert c.get("/healthz").status_code == 200


def test_unreadable_data_shows_help_and_changes_nothing(tmp_path):
    from recipehelper.web import create_app
    cfg = Config(data_dir=str(tmp_path / "d"))
    os.makedirs(cfg.data_dir)
    with open(cfg.db_path, "wb") as f:
        f.write(b"garbage" * 50)
    c = create_app(cfg).test_client()
    r = c.get("/")
    assert r.status_code == 503 and b"can't be opened" in r.data and b"backups" in r.data
    assert c.get("/healthz").get_json()["status"] == "error"
    assert open(cfg.db_path, "rb").read() == b"garbage" * 50


def test_terminal_and_web_share_history(client, app, tmp_path, monkeypatch):
    from recipehelper import cli
    s = store_of(app)
    inputs = iter(["Rolls", "4", "flour", "400", ""])
    monkeypatch.setattr("builtins.input", lambda prompt="": next(inputs))
    cli.create_recipe(s)
    assert "Rolls" in client.get("/list").get_data(as_text=True)
    assert s.history()[0]["who"] == "terminal"
