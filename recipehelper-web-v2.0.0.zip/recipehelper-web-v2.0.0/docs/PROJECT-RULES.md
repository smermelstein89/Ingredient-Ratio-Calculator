# Proposed Project instructions (from v2.0.0)

The Project's current instructions assume one source file (`<main-file>`), `-<major>-<iteration>` release
names and `docs/NOTES.md`. On 2026-11-22 you chose the self-hosted web app template ("spec wins, keep
SQLite"), so those three things no longer fit. Paste the text below over the Project instructions in
claude.ai to make them match. Only sections 1–3 and 5 change. Your non-negotiables are kept word for
word, with Recipe Helper's own hard requirements added.

---

Project Operating Instructions — Recipe Helper

The workspace is temporary and may be wiped between sessions. The Claude Project's shared files are the
only durable source of truth. Follow these procedures every session.

1. File Structure and Authority

* Working tree: the contents of the newest release zip — `recipehelper/` (package), `wsgi.py`, `deploy/`,
  `tests/`, `requirements.txt`, `.env.example`, `README.md`, `LOG.md`, `docs/`. These are the only files you
  may edit.
* Releases: `releases/recipehelper-web-vX.Y.Z.zip` (semantic versions) are immutable, validated
  snapshots. Older history: `releases/recipehelper-1-1.py`, `releases/recipehelper-1-2.py`. Never edit,
  overwrite, or delete releases. Bump the version for every completed change (patch for fixes, minor for
  features, major for breaking changes).
* Log: `LOG.md` has five sections: Open questions (Q1…, each with the default in use), Answered,
  Decisions (D1…), Changes (one entry per version, newest first), Suggestions (S1…).
* Documentation: `README.md` and applicable files in `docs/`.
* Git: tracks session changes but is temporary. It is not a substitute for Project synchronization.
* Authority: Claude Project shared files always take precedence over workspace copies.

2. Start of Every Session

1. Copy all releases, `README.md`, `LOG.md` and `docs/` from the Project.
2. Unzip the highest-numbered release into the workspace as the working tree.
3. Verify the working tree matches that release and that its `recipehelper/__init__.py` version matches
   the zip name. If essential files are missing or inconsistent, stop and ask.
4. Run `git init`, `git add -A`, and commit a baseline:
   `Rebuild from Project (session YYYY-MM-DD): releases <first>..<last>`
5. Run `pytest -q` and confirm it passes before changing anything.
6. Read the whole of `LOG.md`, especially Open questions, Decisions and Suggestions.
7. Review the existing implementation and tests before making changes.

3. Making Changes

* Work on agreed-upon tasks. A direct user request authorizes new work outside the log.
* Don't introduce features, redesigns, refactoring, or dependencies outside the agreed scope on your own.
* Edit the working tree only. Never edit existing releases.
* Preserve existing functionality unless explicitly instructed otherwise.
* If requirements are ambiguous or conflict with established decisions, ask before proceeding.
* Validation (a successful check prints nothing, or only the pass summary):
  `python3 -m py_compile recipehelper/*.py wsgi.py`, `bash -n deploy/install.sh deploy/recipehelper-update`,
  and `pytest -q` (all pass). Add or update tests for every change.
* Test affected functionality and check for regressions. Fix failures before releasing.
* Review the final diff for unintended or unrelated changes.
* Only after validation passes:
  1. Bump `__version__` in `recipehelper/__init__.py`.
  2. Add the version's entry at the top of Changes in `LOG.md`, update "Last updated / Current version",
     and move answered questions to Answered.
  3. Update documentation affected by the change.
  4. Build `releases/recipehelper-web-vX.Y.Z.zip` (one top folder `recipehelper-web-vX.Y.Z/`, no caches).
  5. Commit the working tree, release, `LOG.md` and related documentation together.

Use imperative Git commit messages. One logical change per commit.

4. Non-Negotiable Requirements

* Data lives in one SQLite file. Schema changes go through a versioned upgrade (`PRAGMA user_version`)
  that backs up first, and old data files must keep working.
* The app never overwrites a data file it can't read.
* Every write is one transaction. Imports, restores and updates are backed up first.
* Security: CSRF on every form. Content-Security-Policy with no outside sources and no inline
  script/style. `Tailscale-User-Login` is trusted only on connections from localhost. Bind to
  127.0.0.1 by default.
* Updates go only through `recipehelper-update` with automatic rollback. No in-app code upload.
* Before rebuilding or resetting a live system, create a date-stamped archive of existing data.
* Never automatically delete archives or backups (`BACKUP_KEEP` stays 0 unless the user sets it).
* Never destroy or overwrite user data without explicit authorization.
* Never include personal contact details in code, requests, or payloads unless explicitly requested.
* Never claim something was tested, backed up, or completed without verification.
* Never silently weaken security or bypass project requirements.

If a request conflicts with these rules, stop and obtain user approval.

5. End of Every Session

1. Verify the working tree matches the new release zip.
2. Copy the new release zip to the Project.
3. Copy the updated `LOG.md`, `README.md` and all changed documentation.
4. Verify the Project's highest release matches the working tree (compare SHA-256).
5. Confirm the version, changes, tests performed, and remaining work (open questions).

The Project isn't synchronized until the files are verified. Report any synchronization failures
explicitly.

6. Interrupted Sessions

Never release incomplete or untested work. If stopping mid-task, preserve incomplete changes separately
when possible and document what changed, what remains, and which tests passed or failed. Never represent
incomplete work as the latest stable release.

7. When Unsure

Ask before proceeding if files are missing, requirements conflict, data loss is possible, live systems
may be affected, or the requested behavior is unclear. Never guess or silently change established
decisions.

Priority: protect user data, preserve working functionality, maintain release history, and deliver
verified changes.
